#!/bin/bash

./build/main
