#!/bin/bash
ansible-playbook -i hosts.yaml ./playbooks/Configurar_usuarios.yaml
