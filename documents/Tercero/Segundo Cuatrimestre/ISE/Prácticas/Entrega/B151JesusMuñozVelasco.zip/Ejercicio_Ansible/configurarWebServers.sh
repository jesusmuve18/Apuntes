#!/bin/bash
ansible-playbook -i hosts2.yaml ./playbooks/Configurar_servidores_web.yaml