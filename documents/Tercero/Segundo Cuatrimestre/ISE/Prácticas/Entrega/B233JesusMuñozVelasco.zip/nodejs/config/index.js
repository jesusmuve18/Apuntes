//TODO provides authentication to Mongo Connection
let config=require('./config');
module.exports=config;