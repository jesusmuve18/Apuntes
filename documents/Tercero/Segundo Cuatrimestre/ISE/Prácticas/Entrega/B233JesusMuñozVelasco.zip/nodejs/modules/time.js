module.exports.nowInSeconds=function(){
    return Math.round(Date.now() / 1000);
}