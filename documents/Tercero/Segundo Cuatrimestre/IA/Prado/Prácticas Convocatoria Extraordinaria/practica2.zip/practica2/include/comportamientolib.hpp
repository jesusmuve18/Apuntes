#ifndef COMPORTAMIENTOLIB
#define COMPORTAMIENTOLIB

#include "comportamientos/comportamiento.hpp"

#include "../Comportamientos_Jugador/rescatador.hpp"
#include "../Comportamientos_Jugador/excursionista.hpp"
#include "../Comportamientos_Jugador/vandalo.hpp"
#include "../Comportamientos_Jugador/auxiliar.hpp"



#endif
