#ifndef CABEZA_PERRO_H
#define CABEZA_PERRO_H

#include "obj3dlib.hpp"

class CabezaPerro : public CuboObj3D {
private:
  /* data */
public:
  CabezaPerro();
  ~CabezaPerro();

};

#endif
