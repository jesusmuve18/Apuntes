#include "../Comportamientos_Jugador/auxiliar.hpp"
#include <iostream>
#include "motorlib/util.h"

Action ComportamientoAuxiliar::think(Sensores sensores)
{
	Action accion = IDLE;

	switch (sensores.nivel)
	{
	case 0:
		// accion = ComportamientoAuxiliarNivel_0 (sensores);
		break;
	case 1:
		// accion = ComportamientoAuxiliarNivel_1 (sensores);
		break;
	case 2:
		// accion = ComportamientoAuxiliarNivel_2 (sensores);
		break;
	case 3:
		// accion = ComportamientoAuxiliarNivel_3 (sensores);
		break;
	case 4:
		// accion = ComportamientoAuxiliarNivel_4 (sensores);
		break;
	}

	return accion;
}

int ComportamientoAuxiliar::interact(Action accion, int valor)
{
	return 0;
}

Action ComportamientoAuxiliar::ComportamientoAuxiliarNivel_0(Sensores sensores)
{
	// El comportamiento de seguir un camino hasta encontrar un puesto base.
}

Action ComportamientoAuxiliar::ComportamientoAuxiliarNivel_1(Sensores sensores)
{
}

Action ComportamientoAuxiliar::ComportamientoAuxiliarNivel_2(Sensores sensores)
{
}

Action ComportamientoAuxiliar::ComportamientoAuxiliarNivel_3(Sensores sensores)
{
}

Action ComportamientoAuxiliar::ComportamientoAuxiliarNivel_4(Sensores sensores)
{
}

// Nuevo para el Examen Convocatoria Extraordinaria

void AnularMatrizAux(vector<vector<unsigned char>> &m)
{
	for (int i = 0; i < m[0].size(); i++)
	{
		for (int j = 0; j < m.size(); j++)
		{
			m[i][j] = 0;
		}
	}
}

void ComportamientoAuxiliar::VisualizaPlan(const estadoA &st, const list<Action> &plan)
{
	AnularMatrizAux(mapaConPlan);
	estadoA cst = st;

	auto it = plan.begin();
	while (it != plan.end())
	{
		switch (*it)
		{
		case WALK:
			switch (cst.orientacion)
			{
			case 0:
				cst.fila--;
				break;
			case 1:
				cst.fila--;
				cst.columna++;
				break;
			case 2:
				cst.columna++;
				break;
			case 3:
				cst.fila++;
				cst.columna++;
				break;
			case 4:
				cst.fila++;
				break;
			case 5:
				cst.fila++;
				cst.columna--;
				break;
			case 6:
				cst.columna--;
				break;
			case 7:
				cst.fila--;
				cst.columna--;
				break;
			}
			mapaConPlan[cst.fila][cst.columna] = 2;
			break;
		case TURN_SR:
			cst.orientacion = (cst.orientacion + 1) % 8;
			break;
		}
		it++;
	}
}

void ComportamientoAuxiliar::SituarSensorEnMapa(Sensores sensores)
{
	mapaResultado[sensores.posF][sensores.posC] = sensores.superficie[0];
	mapaCotas[sensores.posF][sensores.posC] = sensores.cota[0];

	int pos = 1;
	switch (sensores.rumbo)
	{
	case 0:
		for (int j = 1; j < 4; j++)
		{
			for (int i = -j; i <= j; i++)
			{
				mapaResultado[sensores.posF - j][sensores.posC + i] = sensores.superficie[pos];
				mapaCotas[sensores.posF - j][sensores.posC + i] = sensores.cota[pos];
				pos++;
			}
		}
		break;
	case 1:
		mapaResultado[sensores.posF - 1][sensores.posC] = sensores.superficie[1];
		mapaResultado[sensores.posF - 1][sensores.posC + 1] = sensores.superficie[2];
		mapaResultado[sensores.posF][sensores.posC + 1] = sensores.superficie[3];
		mapaResultado[sensores.posF - 2][sensores.posC] = sensores.superficie[4];
		mapaResultado[sensores.posF - 2][sensores.posC + 1] = sensores.superficie[5];
		mapaResultado[sensores.posF - 2][sensores.posC + 2] = sensores.superficie[6];
		mapaResultado[sensores.posF - 1][sensores.posC + 2] = sensores.superficie[7];
		mapaResultado[sensores.posF][sensores.posC + 2] = sensores.superficie[8];
		mapaResultado[sensores.posF - 3][sensores.posC] = sensores.superficie[9];
		mapaResultado[sensores.posF - 3][sensores.posC + 1] = sensores.superficie[10];
		mapaResultado[sensores.posF - 3][sensores.posC + 2] = sensores.superficie[11];
		mapaResultado[sensores.posF - 3][sensores.posC + 3] = sensores.superficie[12];
		mapaResultado[sensores.posF - 2][sensores.posC + 3] = sensores.superficie[13];
		mapaResultado[sensores.posF - 1][sensores.posC + 3] = sensores.superficie[14];
		mapaResultado[sensores.posF][sensores.posC + 3] = sensores.superficie[15];
		mapaCotas[sensores.posF - 1][sensores.posC] = sensores.cota[1];
		mapaCotas[sensores.posF - 1][sensores.posC + 1] = sensores.cota[2];
		mapaCotas[sensores.posF][sensores.posC + 1] = sensores.cota[3];
		mapaCotas[sensores.posF - 2][sensores.posC] = sensores.cota[4];
		mapaCotas[sensores.posF - 2][sensores.posC + 1] = sensores.cota[5];
		mapaCotas[sensores.posF - 2][sensores.posC + 2] = sensores.cota[6];
		mapaCotas[sensores.posF - 1][sensores.posC + 2] = sensores.cota[7];
		mapaCotas[sensores.posF][sensores.posC + 2] = sensores.cota[8];
		mapaCotas[sensores.posF - 3][sensores.posC] = sensores.cota[9];
		mapaCotas[sensores.posF - 3][sensores.posC + 1] = sensores.cota[10];
		mapaCotas[sensores.posF - 3][sensores.posC + 2] = sensores.cota[11];
		mapaCotas[sensores.posF - 3][sensores.posC + 3] = sensores.cota[12];
		mapaCotas[sensores.posF - 2][sensores.posC + 3] = sensores.cota[13];
		mapaCotas[sensores.posF - 1][sensores.posC + 3] = sensores.cota[14];
		mapaCotas[sensores.posF][sensores.posC + 3] = sensores.cota[15];
		break;
	case 2:
		for (int j = 1; j < 4; j++)
		{
			for (int i = -j; i <= j; i++)
			{
				mapaResultado[sensores.posF + i][sensores.posC + j] = sensores.superficie[pos];
				mapaCotas[sensores.posF + i][sensores.posC + j] = sensores.cota[pos];
				pos++;
			}
		}
		break;
	case 3:
		mapaResultado[sensores.posF][sensores.posC + 1] = sensores.superficie[1];
		mapaResultado[sensores.posF + 1][sensores.posC + 1] = sensores.superficie[2];
		mapaResultado[sensores.posF + 1][sensores.posC] = sensores.superficie[3];
		mapaResultado[sensores.posF][sensores.posC + 2] = sensores.superficie[4];
		mapaResultado[sensores.posF + 1][sensores.posC + 2] = sensores.superficie[5];
		mapaResultado[sensores.posF + 2][sensores.posC + 2] = sensores.superficie[6];
		mapaResultado[sensores.posF + 2][sensores.posC + 1] = sensores.superficie[7];
		mapaResultado[sensores.posF + 2][sensores.posC] = sensores.superficie[8];
		mapaResultado[sensores.posF][sensores.posC + 3] = sensores.superficie[9];
		mapaResultado[sensores.posF + 1][sensores.posC + 3] = sensores.superficie[10];
		mapaResultado[sensores.posF + 2][sensores.posC + 3] = sensores.superficie[11];
		mapaResultado[sensores.posF + 3][sensores.posC + 3] = sensores.superficie[12];
		mapaResultado[sensores.posF + 3][sensores.posC + 2] = sensores.superficie[13];
		mapaResultado[sensores.posF + 3][sensores.posC + 1] = sensores.superficie[14];
		mapaResultado[sensores.posF + 3][sensores.posC] = sensores.superficie[15];

		mapaCotas[sensores.posF][sensores.posC + 1] = sensores.cota[1];
		mapaCotas[sensores.posF + 1][sensores.posC + 1] = sensores.cota[2];
		mapaCotas[sensores.posF + 1][sensores.posC] = sensores.cota[3];
		mapaCotas[sensores.posF][sensores.posC + 2] = sensores.cota[4];
		mapaCotas[sensores.posF + 1][sensores.posC + 2] = sensores.cota[5];
		mapaCotas[sensores.posF + 2][sensores.posC + 2] = sensores.cota[6];
		mapaCotas[sensores.posF + 2][sensores.posC + 1] = sensores.cota[7];
		mapaCotas[sensores.posF + 2][sensores.posC] = sensores.cota[8];
		mapaCotas[sensores.posF][sensores.posC + 3] = sensores.cota[9];
		mapaCotas[sensores.posF + 1][sensores.posC + 3] = sensores.cota[10];
		mapaCotas[sensores.posF + 2][sensores.posC + 3] = sensores.cota[11];
		mapaCotas[sensores.posF + 3][sensores.posC + 3] = sensores.cota[12];
		mapaCotas[sensores.posF + 3][sensores.posC + 2] = sensores.cota[13];
		mapaCotas[sensores.posF + 3][sensores.posC + 1] = sensores.cota[14];
		mapaCotas[sensores.posF + 3][sensores.posC] = sensores.cota[15];
		break;
	case 4:
		for (int j = 1; j < 4; j++)
		{
			for (int i = -j; i <= j; i++)
			{
				mapaResultado[sensores.posF + j][sensores.posC - i] = sensores.superficie[pos];
				mapaCotas[sensores.posF + j][sensores.posC - i] = sensores.cota[pos];
				pos++;
			}
		}
		break;
	case 5:
		mapaResultado[sensores.posF + 1][sensores.posC] = sensores.superficie[1];
		mapaResultado[sensores.posF + 1][sensores.posC - 1] = sensores.superficie[2];
		mapaResultado[sensores.posF][sensores.posC - 1] = sensores.superficie[3];
		mapaResultado[sensores.posF + 2][sensores.posC] = sensores.superficie[4];
		mapaResultado[sensores.posF + 2][sensores.posC - 1] = sensores.superficie[5];
		mapaResultado[sensores.posF + 2][sensores.posC - 2] = sensores.superficie[6];
		mapaResultado[sensores.posF + 1][sensores.posC - 2] = sensores.superficie[7];
		mapaResultado[sensores.posF][sensores.posC - 2] = sensores.superficie[8];
		mapaResultado[sensores.posF + 3][sensores.posC] = sensores.superficie[9];
		mapaResultado[sensores.posF + 3][sensores.posC - 1] = sensores.superficie[10];
		mapaResultado[sensores.posF + 3][sensores.posC - 2] = sensores.superficie[11];
		mapaResultado[sensores.posF + 3][sensores.posC - 3] = sensores.superficie[12];
		mapaResultado[sensores.posF + 2][sensores.posC - 3] = sensores.superficie[13];
		mapaResultado[sensores.posF + 1][sensores.posC - 3] = sensores.superficie[14];
		mapaResultado[sensores.posF][sensores.posC - 3] = sensores.superficie[15];

		mapaCotas[sensores.posF + 1][sensores.posC] = sensores.cota[1];
		mapaCotas[sensores.posF + 1][sensores.posC - 1] = sensores.cota[2];
		mapaCotas[sensores.posF][sensores.posC - 1] = sensores.cota[3];
		mapaCotas[sensores.posF + 2][sensores.posC] = sensores.cota[4];
		mapaCotas[sensores.posF + 2][sensores.posC - 1] = sensores.cota[5];
		mapaCotas[sensores.posF + 2][sensores.posC - 2] = sensores.cota[6];
		mapaCotas[sensores.posF + 1][sensores.posC - 2] = sensores.cota[7];
		mapaCotas[sensores.posF][sensores.posC - 2] = sensores.cota[8];
		mapaCotas[sensores.posF + 3][sensores.posC] = sensores.cota[9];
		mapaCotas[sensores.posF + 3][sensores.posC - 1] = sensores.cota[10];
		mapaCotas[sensores.posF + 3][sensores.posC - 2] = sensores.cota[11];
		mapaCotas[sensores.posF + 3][sensores.posC - 3] = sensores.cota[12];
		mapaCotas[sensores.posF + 2][sensores.posC - 3] = sensores.cota[13];
		mapaCotas[sensores.posF + 1][sensores.posC - 3] = sensores.cota[14];
		mapaCotas[sensores.posF][sensores.posC - 3] = sensores.cota[15];
		break;

	case 6:
		for (int j = 1; j < 4; j++)
		{
			for (int i = -j; i <= j; i++)
			{
				mapaResultado[sensores.posF - i][sensores.posC - j] = sensores.superficie[pos];
				mapaCotas[sensores.posF - i][sensores.posC - j] = sensores.cota[pos];
				pos++;
			}
		}
		break;
	case 7:
		mapaResultado[sensores.posF][sensores.posC - 1] = sensores.superficie[1];
		mapaResultado[sensores.posF - 1][sensores.posC - 1] = sensores.superficie[2];
		mapaResultado[sensores.posF - 1][sensores.posC] = sensores.superficie[3];
		mapaResultado[sensores.posF][sensores.posC - 2] = sensores.superficie[4];
		mapaResultado[sensores.posF - 1][sensores.posC - 2] = sensores.superficie[5];
		mapaResultado[sensores.posF - 2][sensores.posC - 2] = sensores.superficie[6];
		mapaResultado[sensores.posF - 2][sensores.posC - 1] = sensores.superficie[7];
		mapaResultado[sensores.posF - 2][sensores.posC] = sensores.superficie[8];
		mapaResultado[sensores.posF][sensores.posC - 3] = sensores.superficie[9];
		mapaResultado[sensores.posF - 1][sensores.posC - 3] = sensores.superficie[10];
		mapaResultado[sensores.posF - 2][sensores.posC - 3] = sensores.superficie[11];
		mapaResultado[sensores.posF - 3][sensores.posC - 3] = sensores.superficie[12];
		mapaResultado[sensores.posF - 3][sensores.posC - 2] = sensores.superficie[13];
		mapaResultado[sensores.posF - 3][sensores.posC - 1] = sensores.superficie[14];
		mapaResultado[sensores.posF - 3][sensores.posC] = sensores.superficie[15];

		mapaCotas[sensores.posF][sensores.posC - 1] = sensores.cota[1];
		mapaCotas[sensores.posF - 1][sensores.posC - 1] = sensores.cota[2];
		mapaCotas[sensores.posF - 1][sensores.posC] = sensores.cota[3];
		mapaCotas[sensores.posF][sensores.posC - 2] = sensores.cota[4];
		mapaCotas[sensores.posF - 1][sensores.posC - 2] = sensores.cota[5];
		mapaCotas[sensores.posF - 2][sensores.posC - 2] = sensores.cota[6];
		mapaCotas[sensores.posF - 2][sensores.posC - 1] = sensores.cota[7];
		mapaCotas[sensores.posF - 2][sensores.posC] = sensores.cota[8];
		mapaCotas[sensores.posF][sensores.posC - 3] = sensores.cota[9];
		mapaCotas[sensores.posF - 1][sensores.posC - 3] = sensores.cota[10];
		mapaCotas[sensores.posF - 2][sensores.posC - 3] = sensores.cota[11];
		mapaCotas[sensores.posF - 3][sensores.posC - 3] = sensores.cota[12];
		mapaCotas[sensores.posF - 3][sensores.posC - 2] = sensores.cota[13];
		mapaCotas[sensores.posF - 3][sensores.posC - 1] = sensores.cota[14];
		mapaCotas[sensores.posF - 3][sensores.posC] = sensores.cota[15];
		break;
	}
}


