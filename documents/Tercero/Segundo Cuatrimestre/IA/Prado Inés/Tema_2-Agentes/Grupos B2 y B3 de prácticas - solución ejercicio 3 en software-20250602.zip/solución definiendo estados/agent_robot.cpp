#include "agent_robot.h"
#include "environment.h"
#include <iostream>
#include <cstdlib>
#include <vector>
#include <utility>

using namespace std;

// -----------------------------------------------------------
Agent::ActionType Agent::Think()
{
	int accion = 0;
	
	/* ESCRIBA AQUI SUS REGLAS */
	switch(ESTADO_){
	   case Q0: 
	     accion = q0();
	     break;
	   case Q1:
	     accion = q1();
	     break;
	   case Q2:
	     accion = q2();	   
	     break;
	   case Q3:
	     accion = q3();
	     break;   
	}

	return static_cast<ActionType> (accion);
}

Agent::ActionType Agent::q0(){
   ActionType accion = actIDLE;
   if(!CNY70_){
      accion = actFORWARD;
      ESTADO_ = Q0;
   }
   else{
      accion = actTURN_L;
      ESTADO_ = Q1;
   }   
   return accion;
}

Agent::ActionType Agent::q1(){
   ActionType accion = actTURN_L;
   ESTADO_ = Q2;
   return accion;
}

Agent::ActionType Agent::q2(){
   ActionType accion = actIDLE;
   if(!CNY70_){
      accion = actFORWARD;
      dimension++;
      ESTADO_ = Q2;
   }
   else{
      ESTADO_ = Q3;	   
   }

   return accion;
}

Agent::ActionType Agent::q3(){
   ActionType accion = actIDLE;
   ESTADO_ = Q3;
   return accion;
}

// -----------------------------------------------------------
void Agent::Perceive(const Environment &env)
{
	CNY70_ = env.isFrontier();
	BUMPER_ = env.isBump();
}
// -----------------------------------------------------------
string ActionStr(Agent::ActionType accion)
{
	switch (accion)
	{
	case Agent::actFORWARD: return "FORWARD";
	case Agent::actTURN_L: return "TURN LEFT";
	case Agent::actTURN_R: return "TURN RIGHT";
	case Agent::actBACKWARD: return "BACKWARD";
	case Agent::actPUSH: return "PUSH";
	case Agent::actIDLE: return "IDLE";
	default: return "???";
	}
}
