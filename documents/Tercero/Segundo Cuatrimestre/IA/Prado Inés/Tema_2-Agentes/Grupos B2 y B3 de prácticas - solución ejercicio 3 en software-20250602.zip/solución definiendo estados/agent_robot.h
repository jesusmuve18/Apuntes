#ifndef AGENT__
#define AGENT__

#include <string>
#include <iostream>
using namespace std;

// -----------------------------------------------------------
//				class Agent
// -----------------------------------------------------------
class Environment;
class Agent
{
public:
	Agent(){
		CNY70_=false;
		BUMPER_=false;
		ESTADO_ = Q0;
		dimension = 0;
	}

	enum ActionType
	{
	    actFORWARD,
	    actTURN_L,
	    actTURN_R,
		actBACKWARD,
		actPUSH,
		actIDLE
	};

	enum Estado{
		Q0,
		Q1,
		Q2,
		Q3
	};

	void Perceive(const Environment &env);
	ActionType Think();

private:
	bool CNY70_;
	bool BUMPER_;
	Estado ESTADO_;
	int dimension;

	ActionType q0();
	ActionType q1();
	ActionType q2();
	ActionType q3();
};

string ActionStr(Agent::ActionType);

#endif
