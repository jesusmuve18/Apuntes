/****************************************************************************/
//	FUNDAMENTOS DE PROGRAMACI�N			TEMA_1				EJERCICIO_39
/****************************************************************************/
/*
	Jes�s Mu�oz Velasco 					Grupo:A2

	Explicaci�n del programa:
	
	Dados 2 lados de un tri�ngulo y el �ngulo que conforman calcula el �rea
	de dicho tri�ngulo.
	
	Entradas: Medidas de los 2 lados y �ngulo que forman
	
	Salidas: �rea del tri�ngulo
	
*/
/****************************************************************************/
#include<iostream>
#include<cmath>
using namespace std;
/****************************************************************************/
int main()
{
	//Declaraci�n de datos
	
	const double PI=3.14159265359;
	const double GRADOS_A_RAD=(PI/180);		//factor de conversi�n
	
	double lado1, lado2, angulo;
	double area;
	
	//Entrada
	
	cout<<"Longitud del lado 1 (m): ";
	cin>>lado1;
	cout<<"Longitud del lado 2 (m): ";
	cin>>lado2;
	cout<<"Angulo que forman los 2 lados dados (grados): ";
	cin>>angulo;
	
	//C�lculos
	
	angulo=angulo*GRADOS_A_RAD;  //Convierto los grados en radianes
	
	area=(0.5*lado1*lado2*sin(angulo)); //Aplico la f�rmula dada
	
	//Salidas
	
	cout<<endl;
	cout<<"El area de ese triangulo es de "<<area<<" metros cuadrados";
	
	return 0;
}
