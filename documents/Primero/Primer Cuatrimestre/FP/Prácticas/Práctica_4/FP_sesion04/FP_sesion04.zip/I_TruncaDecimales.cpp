/****************************************************************************/
//	FUNDAMENTOS DE PROGRAMACI�N			TEMA_1				EJERCICIO_36
/****************************************************************************/
/*
	Jes�s Mu�oz Velasco 					Grupo:A2

	Explicaci�n del programa:
	
	Lee un n�mero real r y un n�mero entero n y	trunqua r a tantas cifras 
	decimales como indique n. El resultado se almacena en una variable 
	diferente.
	
	Entradas:  r y n
	
	Salidas:	r truncado
	
*/
/****************************************************************************/
#include<iostream>
#include<cmath>
#include<iomanip>
#include<string.h>
using namespace std;
/****************************************************************************/
int main()
{
	cout.setf(ios::fixed);
	
	//Declaraci�n de datos
	
	long double r,r_trunc;
	
	string s_entera;
	int p_entera;
	int cifras; //Numero de cifras de la parte entera de r
	
	int n;
	
	//Entradas
	
	cout<<"Numero real: ";
	cin>>r;
	cout<<"Numero de cifras decimales: ";
	cin>>n;
	
	//C�lculos
	/*En primer lugar multiplico r por 10 elevado a n para desplazar la coma 
	tantos lugares a la derecha como indique n. De este modo tendr� todas 
	las cifras que quiero conservar en la parte entera del n�mero.
	Desecho las cifras decimales con el casting (int)<valor> y vuelvo a 
	desplazar la coma n posiciones a la izquierda dividiendo entre 10 elevado 
	a n.*/
	
	r_trunc=((int)(r*pow(10.0,n)))/(pow(10.0,n));
	
	/* La siguiente operaci�n que har� ser� para mostrar por pantalla de la 
	forma m�s �ptima el resultado. Para ello usar� las funciones setw()
	y setprecision().
	
	El argumento de la funci�n setw() ser� el resultado de sumar el n�mero
	de cifras de la parte entera m�s el punto m�s el n�mero de cifras de la 
	parte decimal. Estos 2 �ltimos valores los conozco ya q el punto ocupa 
	1 espacio y la parte decimal ocupa n espacios. 
	Para calcular el n�mero de cifras enteras convertir� el n�mero real en 
	entero asign�ndolo a un int. Despu�s convertir� ese n�mero en una variable
	de tipo string y contar� el n�mero de caracteres.
	
	El argumento de la funci�n setprecision() ser� el propio n.
	*/
	
	p_entera=r;
	s_entera=to_string(p_entera);
	cifras=s_entera.length();	 
	
	//Salidas
	
	cout<<endl;
	cout<<"Numero truncado: "<<setw(cifras+n+1)<<setprecision(n)<<r_trunc;
	
	return 0;
}
