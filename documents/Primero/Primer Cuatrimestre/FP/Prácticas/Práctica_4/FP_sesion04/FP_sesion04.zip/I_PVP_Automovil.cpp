/****************************************************************************/
//	FUNDAMENTOS DE PROGRAMACI�N			TEMA_1				EJERCICIO_33
/****************************************************************************/
/*
	Jes�s Mu�oz Velasco 					Grupo:A2

	Explicaci�n del programa:
	
	El precio final de un autom�vil para un comprador es la suma total del 
	costo del veh�culo, del porcentaje de ganancia de dicho vendedor y del 
	I.V.A. Dise�ar un algoritmo para obtener el precio final de un autom�vil 
	sabiendo que el porcentaje de ganancia de este vendedor es del 20 % y el 
	I.V.A. aplicable es del 16 %.
	
	Entradas:  precio inicial del coche
	
	Salidas: precio final del coche
	
*/
/****************************************************************************/
#include<iostream>
using namespace std;
/****************************************************************************/
int main()
{
	//Declaraci�n de datos
	
	const double IVA=0.16; 		//Porcentaje en tanto por 1
	const double GANANCIA=0.2;  //Porcentaje en tanto por 1
	
	double p_inicial;
	double p_final;
	
	//Entrada
	
	cout<<"Costo del vehiculo (de fabrica): ";
	cin>>p_inicial;
	
	//C�lculos (suma total del costo, del porcentaje de ganancia  y del I.V.A)
	
	p_final=(p_inicial+(p_inicial*GANANCIA)+(p_inicial*IVA));
	
	//Salidas
	
	cout<<"El precio final de venta sera de "<<p_final<<" euros";
	
	return 0;
}
