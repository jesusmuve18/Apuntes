/****************************************************************************/
//	FUNDAMENTOS DE PROGRAMACI�N			TEMA_1				EJERCICIO_42
/****************************************************************************/
/*
	Jes�s Mu�oz Velasco 					Grupo:A2

	Explicaci�n del programa:
	
	Lee un n�mero entero (original) y construye otro a partir de �l (nuevo) 
	intercambiando la primera y la �ltima cifra. Despu�s indicar� si la 
	primera cifra de original es igual, mayor o menor que la �ltima del mismo 
	valor (h�galo comparando original y nuevo).
	(No puede usar ninguna estructura/operador condicional)
	
	Entradas:  N�mero original.
	
	Salidas: N�mero nuevo intercambiando la primera y la �ltima cifra del 
			 original.
			 Si es mayor menor o igual que el anterior.
	
*/
/****************************************************************************/
#include<iostream>
#include<string.h>
using namespace std;
/****************************************************************************/
int main()
{
	
	//Declaraci�n de datos
	
	int original;
	int nuevo;
	string s_original,s_nuevo; //Las utilizar� para el intercambio de cifras
	bool igual, mayor, menor;
	int longitud_original; //Va a ser igual que la longitud del nuevo
	
	int c1_orig,c1_nuevo; //Primera cifra de cada n�mero
		
	//Entrada
	
	cout<<"Numero entero: ";
	cin>>original;
	
	//C�lculos
	
	s_original=to_string(original);
	s_nuevo=s_original; //Primero las igualo para despues intercambiar cifras
	longitud_original=s_original.length();
	s_nuevo.at(0)=s_nuevo.at(longitud_original-1);// Cambio la primera cifra
	s_nuevo.at(longitud_original-1)=s_original.at(0); //Cambio la ultima cifra
	nuevo=stoi(s_nuevo);
	
	c1_orig=((s_original.at(0))-'0'); 	//convierto los char a enteros
	c1_nuevo=((s_nuevo.at(0))-'0');		//desplaz�ndolos en la tabla ASCII
	
	igual=(c1_orig==c1_nuevo);
	mayor=(c1_orig>c1_nuevo);
	menor=(c1_orig<c1_nuevo);
	
	
	//Salidas
	
	cout<<"El numero nuevo es: "<<nuevo;
	cout<<boolalpha<<endl;	//hago que se muestre en pantalla true o false	
	cout<<"\tEs "<<c1_orig<<"="<<c1_nuevo<<"? :"<<igual<<endl;
	cout<<"\tEs "<<c1_orig<<">"<<c1_nuevo<<"? :"<<mayor<<endl;
	cout<<"\tEs "<<c1_orig<<"<"<<c1_nuevo<<"? :"<<menor<<endl;
	
	return 0;
}
