/****************************************************************************/
//	FUNDAMENTOS DE PROGRAMACI�N			TEMA_1				EJERCICIO_32
/****************************************************************************/
/*
	Jes�s Mu�oz Velasco 					Grupo:A2

	Explicaci�n del programa:
	
	Escribid una expresi�n l�gica que sea verdadera si una variable de tipo 
	car�cter llamada letra es una letra may�scula y falso en otro caso.
	
	Escribid una expresi�n l�gica que sea verdadera si una variable de tipo 
	entero llamada	edad es mayor o igual que 18 y menor que 67.
	
	Escribid una expresi�n l�gica que nos informe cuando un a�o es bisiesto.
	(Los a�os bisiestos son aquellos que o bien son divisibles por 4 pero no 
	por 100, o bien son	divisibles por 400.)
	
	Escribid una expresi�n l�gica que nos informe si el valor de una variable 
	double llamada distancia es menor que la constante LIMITE.
	
	Usad una variable l�gica que registre si el valor de una variable int es 
	menor que otra, otra que informe si son iguales y otra que informe si es 
	mayor. (Aseg�rese que s�lo una, y s�lo una de las tres trendr� el valor 
	true.)
	
	Entradas:  
	
	1) Caracter en may�scula o min�scula
	2) Edad
	3) A�o
	4) Distancia
	5) 2 n�meros enteros
	
	Salidas:
	
	1) Si el caracter est� en may�scula: true
	2) Si la edad es 18<=edad<67 : true
	3) Si el a�o es bisiesto: true
	4) Si la distancia es menor que LIMITE: true
	5) Si el primer n�mero es menor que el segundo: true
	   Si el primer n�mero es igual que el segundo: true
	   Si el primer n�mero es mayor que el segundo: true
	   Si solo se da una de las 3 condiciones anteriores: true
	
	
*/
/****************************************************************************/
#include<iostream>
using namespace std;
/****************************************************************************/
int main()
{
	
		
	bool mayuscula;
	char caracter;
	
	const int EDAD_MINIMA=18,EDAD_MAXIMA=67;
	bool edad_correcta;
	int edad;
	
	bool bisiesto;
	int year;
	
	const double LIMITE=500;
	bool d_correcta;
	double distancia;
	
	bool menor,iguales,mayor;
	int num1,num2;
	bool funciona;
	
	
	//Entrada
	
	cout<<"Caracter: ";
	cin>>caracter;
	cout<<"Edad: ";
	cin>>edad;
	cout<<" _"<<endl;
	cout<<"Ano: ";
	cin>>year;
	cout<<"Distancia: ";
	cin>>distancia;
	cout<<"\r\b(La distancia limite es "<<LIMITE<<")"<<endl;
	cout<<"Primer numero: ";
	cin>>num1;
	cout<<"Segundo numero: ";
	cin>>num2;
	
	
	//C�lculos
	//Traducci�n de las expresiones l�gicas a lenguaje c++
	mayuscula=(caracter==toupper(caracter));
	edad_correcta=((edad>=EDAD_MINIMA)&&(edad<EDAD_MAXIMA));
	bisiesto=((((year%4)==0)&&((year%100!=0)))||(year%400==0));
	d_correcta=(distancia<LIMITE);
	menor=(num1<num2);
	iguales=(num1==num2);
	mayor=(num1>num2);
	funciona=((menor&& !iguales && !mayor)	  //Comprueba que solo se cumple 
			|| (!menor&& iguales && !mayor)   //una de las condiciones
			|| (!menor&& !iguales && mayor));
	
	
	//Salidas
	
	cout<<endl;
	cout<<"El caracter esta en mayuscula: "<<boolalpha<<mayuscula<<endl;
	cout<<"La edad es mayor o igual a "<<EDAD_MINIMA<<" y menor que "
		<<EDAD_MAXIMA<<": "<<edad_correcta<<endl;
	cout<<"    _"<<endl,
	cout<<"El ano es bisiesto: "<<bisiesto<<endl;
	cout<<"La distancia es menor que "<<LIMITE<<": "<<d_correcta<<endl;
	cout<<"El numero "<<num1<<" es menor que "<<num2<<": "<<menor<<endl;
	cout<<"El numero "<<num1<<" es igual que "<<num2<<": "<<iguales<<endl;
	cout<<"El numero "<<num1<<" es mayor que "<<num2<<": "<<mayor<<endl;
	cout<<"(El ultimo apartado funciona: "<<funciona<<")";
	
	
	return 0;
}
