/****************************************************************************/
//	FUNDAMENTOS DE PROGRAMACI�N			TEMA_1				EJERCICIO_28
/****************************************************************************/
/*
	Jes�s Mu�oz Velasco 					Grupo:A2

	Explicaci�n del programa:
	
	Lee un entero representando la clave y un car�cter en may�cula. El 
	programa codificar� el car�cter seg�n la clave introducida y lo mostrar� 
	por pantalla. (Funciona para todos los caracteres a excepci�n de la '�')
	
	Entradas:  Clave y caracter a codificar
	
	Salidas:	Caracter codificado
	
*/
/****************************************************************************/
#include<iostream>
using namespace std;
/****************************************************************************/
int main()
{
	//Declaraci�n de datos

	const int INTERVALO=('Z'-'A'+1);//le sumo 1 ya que es un intervalo cerrado
		
	int clave;
	char c_inicial,c_cod;  //Caracter a codificar y codificado respectivamente

	
	//Entradas
	
	cout<<"Clave: ";
	cin>>clave;
	cout<<"Caracter a codificar: ";
	cin>>c_inicial;
	
	//C�lculos
	
	/* El intervalo en el que trabajaremos es ('Z'-'A') por lo que tendremos 
	que hacer que el caracter codificado se mantenga en �l
	
	Para ello primero desplazaremos el caracter seg�n la clave y para
	introducirlo en el intervalo le restaremos el valor inicial del intervalo
	('A').
	Despu�s calcularemos el m�dulo con respecto al intervalo y nos dar� su 
	posici�n dentro del intervalo.
	Para devolverlo a su posici�n de la tabla ASCII le sumaremos el valor 
	inicial del intervalo ('A')
	*/
	
	c_cod=((c_inicial+clave-'A')%INTERVALO)+'A';
		
	//Salidas
	
	cout<<"Caracter codificado: "<<c_cod;
	
	return 0;
}
