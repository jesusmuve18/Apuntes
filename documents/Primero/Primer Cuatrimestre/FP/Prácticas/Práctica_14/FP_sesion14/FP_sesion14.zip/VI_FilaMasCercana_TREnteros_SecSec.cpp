/****************************************************************************/
//	FUNDAMENTOS DE PROGRAMACI�N			RELACI�N_VI				EJERCICIO_60
/****************************************************************************/
/*
	Jes�s Mu�oz Velasco 					Grupo:A2

	Enunciado:
	
	Reescribir el ejercicio 51 (fila m�s cercana de un conjunto de filas 
	preseleccionadas) usando la clase TablaRectangularEnteros que emplea una 
	secuencia de secuencias de enteros como dato privado.
	
	Emplear la misma funci�n main que se us� para la soluci�n propuesta usando 
	la clase que empela una matriz cl�sica como dato privado. Si no ha tenido 
	que cambiar nada, la clase est� bien construida.

*/
/****************************************************************************/
#include<iostream>
#include<cmath>
using namespace std;
/****************************************************************************/
//Declaraci�n de constantes globales

/****************************************************************************/
//Declaraci�n de tipos de datos

/****************************************************************************/
//Declaraci�n de Clases/Objetos

class SecuenciaEnteros 
{

private:

    static const int TAMANIO = 4; // N�m.casillas disponibles
    int vector_privado[TAMANIO];

    // PRE: 0<=total_utilizados<TAMANIO

    int total_utilizados; // N�m.casillas ocupadas

public:

    /***********************************************************************/
    // Constructor sin argumentos

    SecuenciaEnteros (void) : total_utilizados (0)
    {}
    
    //Constructor con argumentos 
    
    SecuenciaEnteros(string cadena)
    {
    	total_utilizados=cadena.length();
    	
    	for(int i=0; i<total_utilizados ; i++)
    	{
    		vector_privado[i]=(cadena.at(i)-'0');
		}
	}
	
	//Constructor con argumentos
	
	SecuenciaEnteros(int entero)
	{
		int aux;
		int cifras=0;
			
		aux=entero;
		
		while(aux>0) //Cuento el n�mero de cifras que tiene el n�mero
		{
			cifras++;
			aux/=10;
		}
		
		total_utilizados=cifras;
		
		aux=entero;
		
		for(int i=0; i<cifras; i++) //Introduzco cada cifra en su posici�n
		{
			vector_privado[i]=(aux/(pow(10,cifras-1-i)));
			aux-=vector_privado[i]*pow(10,cifras-1-i);
		}
	}
	
	/***********************************************************************/
	//Actualiza la secuencia con un numero dado separandolo en cifras
	
	void SetSecuencia(int entero)
	{
		int aux;
		int cifras=0;
			
		aux=entero;
		
		while(aux>0) //Cuento el n�mero de cifras que tiene el n�mero
		{
			cifras++;
			aux/=10;
		}
		
		total_utilizados=cifras;
		
		aux=entero;
		
		for(int i=0; i<cifras; i++) //Introduzco cada cifra en su posici�n
		{
			vector_privado[i]=(aux/(pow(10,cifras-1-i)));
			aux-=vector_privado[i]*pow(10,cifras-1-i);
		}
	}
	
    /***********************************************************************/
    // Devuelve el n�mero de casillas ocupadas

    int TotalUtilizados (void)
    {
        return (total_utilizados);
    }

    /***********************************************************************/
    // Devuelve el n�mero de casillas disponibles

    int Capacidad (void)
    {
        return (TAMANIO);
    }

    /***********************************************************************/
    // "Vac�a" completamente la secuencia

	void EliminaTodos()
	{
		total_utilizados = 0;
	}

    /***********************************************************************/
    // A�ade un elemento ("nuevo") al vector.
    // PRE: total_utilizados < TAMANIO
    // 		La adici�n se realiza si hay alguna casilla disponible.
    // 		El nuevo elemento se coloca al final del vector.
    // 		Si no hay espacio, no se hace nada.

    void Aniade (int nuevo)
    {
        if (total_utilizados < TAMANIO){
            vector_privado[total_utilizados] = nuevo;
            total_utilizados++;
        }
    }

    /***********************************************************************/
    // Devuelve el elemento de la casilla "indice"
    // PRE: 0 <= indice < total_utilizados

    int Elemento (int indice)
    {
        return (vector_privado[indice]);
    }

    /***********************************************************************/
    // Cambia el contenido de la casilla "indice" por el valor "nuevo"
    // PRE: 0 <= indice < total_utilizados

   void Modifica (int indice, int nuevo)
   {
		if ((indice >= 0) && (indice < total_utilizados))
			vector_privado[indice] = nuevo;
   }


    /***********************************************************************/
    // Eliminar el car�cter de la posici�n dada por "indice".
    // Realiza un borrado f�sico (desplazamiento y sustituci�n).
    // PRE: 0 <= indice < total_utilizados

    void Elimina (int indice)
    {
        if ((indice >= 0) && (indice < total_utilizados)) {

            int tope = total_utilizados-1; // posic. del �ltimo

            for (int i = indice ; i < tope ; i++)
                vector_privado[i] = vector_privado[i+1];

            total_utilizados--;
        }
    }
 

    /***********************************************************************/
    // Inserta el car�cter "nuevo" en la posici�n dada por "indice".
    // Desplaza todos los caracteres una posici�n a la derecha antes de 
	// copiar en "indice" en valor "nuevo".
	// PRE: 0 <= indice < total_utilizados
    // PRE: total_utilizados < TAMANIO
    // 		La inseerci�n se realiza si hay alguna casilla disponible.
    // 		Si no hay espacio, no se hace nada.
    
	void Inserta (int indice, int valor_nuevo)
	{
        if ((indice >= 0) && (indice < total_utilizados) 
		    && (total_utilizados < TAMANIO)) {
		
			for (int i = total_utilizados ; i > indice ; i--)
				vector_privado[i] = vector_privado[i-1];
			
			vector_privado[indice] = valor_nuevo;
			total_utilizados++;		
		}
	}
   
    /***********************************************************************/    
    /***********************************************************************/
    // Compone un string con todos los caracteres que est�n
    // almacenados en la secuencia y lo devuelve.
    //Tiene el separador por defecto con posibildad de modificarlo
    
    string ToString(string separador=",")
    {
        string cadena;

        for (int i=0; i<total_utilizados; i++)
        {
        	cadena += to_string(vector_privado[i]);
        	
        	if(i<total_utilizados-1)
        	{
        		cadena+=separador;
			}
		}
            

        return (cadena);
    }
	
	/***********************************************************************/
	//Elimina el n�mero dado todas las veces que aparece en la secuencia
	
	void EliminaOcurrencias (int a_borrar)
	{
		int posicion=0;
		while(posicion<total_utilizados)
		{
			if(vector_privado[posicion]==a_borrar)
			{
				Elimina(posicion);
			}
			else
			{
				posicion++;
			}
		}
	}
	
	
	/***********************************************************************/
	//M�todo de ordenaci�n por Selecci�n o Selection Sort
	
	void OrdenaSeleccion()
	{
		for (int izda = 0 ; izda < total_utilizados ; izda++) 
		{
			// Calcular el m�nimo entre "izda" y "total_utilizados"-1
			int minimo = vector_privado[izda]; // Valor del m�nimo
			
			int pos_min = izda; // Posici�n del m�nimo
			
			for (int i = izda + 1; i < total_utilizados ; i++)
			{
				if (vector_privado[i] < minimo) // Nuevo m�nimo
				{
					minimo = vector_privado[i];
					pos_min = i;
				}
				
			}
			
			// Intercambiar los valores guardados en "izda" y "pos_min"
			int intercambia = vector_privado[izda];
			vector_privado[izda] = vector_privado[pos_min];
			vector_privado[pos_min] = intercambia;	
			
		}

	}
	
	/***********************************************************************/
	//M�todo de ordenaci�n por Inserci�n o Insertion Sort
	
	void OrdenaInsercion()
	{
		for (int izda=1; izda<total_utilizados; izda++)
		{
			// "a_insertar" es el valor que se va a insertar en
			// subvector izquierdo. Este subvector est� ordenado y
			// comprende las posiciones entre 0 e "izda"-1
			
			int a_insertar=vector_privado[izda];
			
			// Se busca la posici�n en la zona ordenada y al mismo tiempo
			// se van desplazando hacia la derecha los valores mayores
			
			int i=izda;
			
			while ((i>0) && (a_insertar<vector_privado[i-1])) 
			{
				
				// Desplazar a la derecha los valores mayores que "a_insertar"
				vector_privado[i] = vector_privado[i-1]; 
				i--;
			}
			
			vector_privado[i]=a_insertar; // Copiar -insertar- en el "hueco"
		}

	}
	
	/***********************************************************************/
	//M�todo de ordenaci�n por Intercambio Directo o Burbuja (Bubble Sort)
	//Primera Aproximaci�n: 
	
	void OrdenaIntercambio()
	{
		for (int izquierda = 0; izquierda<total_utilizados; izquierda++) 
		{
			for (int i = total_utilizados-1 ; i > izquierda ; i--)
			{
				if (vector_privado[i] < vector_privado[i-1]) // Intercambiar
				{	
					int intercambia = vector_privado[i];
					vector_privado[i] = vector_privado[i-1];
					vector_privado[i-1] = intercambia;
				}
			}		
		}	
	}
	
	/***********************************************************************/
	//M�todo de ordenaci�n por Intercambio Directo o Burbuja (Bubble Sort)
	//Segunda Aproximaci�n: 
	
	void OrdenaIntercambioMejorado()
	{
		bool cambio=true; // Para obligar a entrar al ciclo
		
		for (int izda=0; izda<total_utilizados && cambio;izda++)
		{
			// En cada pasada iniciamos "cambio" a false.
			// Se pondr� a true si y solo si hay alg�n intercambio
			
			cambio=false;
			
			for(int i=total_utilizados-1; i>izda ;i--)
			{
				if(vector_privado[i]<vector_privado[i-1])	// Intercambiar
				{ 
					int intercambia=vector_privado[i];
					vector_privado[i]=vector_privado[i-1];
					vector_privado[i-1]=intercambia;
					
					// Se ha hecho un intercambio.
					// Se obliga a una nueva iteraci�n del ciclo externo.
					
					cambio=true;
				}	
			}
		}	
	}
	
	/***********************************************************************/
	//M�todo de comparaci�n entre 2 enteros que devuelve el mayor de los 2
	
	int NuevoOrden_Mayor (int a, int b)
	{
		const char NUM_INICIO='9';
		
		string num1=to_string(a);
		string num2=to_string(b);
		
		int mayor;
		
		bool acabar=false;
		char num_a_contar=NUM_INICIO;
		
		int contador1=0;
		int contador2=0;
		
		while(!acabar)
		{
			//Reseteo los contadores para cada numero a contar
			contador1=0;
			contador2=0;
			
			for(int i=0; i<num1.length(); i++) //Cuento las apariciones en num1
			{
				if(num1.at(i)==num_a_contar)
				{
					contador1++;
				}
			}
			
			for(int i=0; i<num2.length(); i++) //Cuento las apariciones en num2
			{
				if(num2.at(i)==num_a_contar)
				{
					contador2++;
				}
			}
			
			if(contador1>contador2)//El mayor ser� el que tenga m�s apariciones
			{
				mayor=stoi(num1);
				acabar=true;
			}
			else
			{
				if(contador1<contador2)
				{
					mayor=stoi(num2);
					acabar=true;
				}
				else
				{
					if(num_a_contar>0)
					{
						num_a_contar--;
					}
					else
					{
						mayor=stoi(num1);
						acabar=true;
					}
				}
			}
		}
		return mayor;
	}
	
	/***********************************************************************/
	//M�todo de ordenaci�n por Selecci�n o Selection Sort
	
	void OrdenaSeleccion_NuevoOrden()
	{
		for (int izda = 0 ; izda < total_utilizados ; izda++) 
		{
			// Calcular el m�nimo entre "izda" y "total_utilizados"-1
			int minimo = vector_privado[izda]; // Valor del m�nimo
			
			int pos_min = izda; // Posici�n del m�nimo
			
			for (int i = izda + 1; i < total_utilizados ; i++)
			{
				if (NuevoOrden_Mayor(vector_privado[i], minimo)==minimo) 
				{											// Nuevo m�nimo
					minimo = vector_privado[i];
					pos_min = i;
				}
				
			}
			
			// Intercambiar los valores guardados en "izda" y "pos_min"
			int intercambia = vector_privado[izda];
			vector_privado[izda] = vector_privado[pos_min];
			vector_privado[pos_min] = intercambia;	
			
		}

	}
	
	/***********************************************************************/
	//M�todo de ordenaci�n por Inserci�n o Insertion Sort
	
	void OrdenaInsercion_NuevoOrden()
	{
		for (int izda=1; izda<total_utilizados; izda++)
		{
			// "a_insertar" es el valor que se va a insertar en
			// subvector izquierdo. Este subvector est� ordenado y
			// comprende las posiciones entre 0 e "izda"-1
			
			int a_insertar=vector_privado[izda];
			
			// Se busca la posici�n en la zona ordenada y al mismo tiempo
			// se van desplazando hacia la derecha los valores mayores
			
			int i=izda;
			
			while ((i>0)&&(NuevoOrden_Mayor(vector_privado[i-1],a_insertar)
														==vector_privado[i-1]))
			{
				
				// Desplazar a la derecha los valores mayores que "a_insertar"
				vector_privado[i] = vector_privado[i-1]; 
				i--;
			}
			
			vector_privado[i]=a_insertar; // Copiar -insertar- en el "hueco"
		}

	}
	
	/***********************************************************************/
	//M�todo de ordenaci�n por Intercambio Directo o Burbuja (Bubble Sort)
	//Primera Aproximaci�n: 
	
	void OrdenaIntercambio_NuevoOrden()
	{
		for (int izquierda = 0; izquierda<total_utilizados; izquierda++) 
		{
			for (int i = total_utilizados-1 ; i > izquierda ; i--)
			{
				if (NuevoOrden_Mayor(vector_privado[i], vector_privado[i-1])
					==vector_privado[i-1]) // Intercambiar
				{	
					int intercambia = vector_privado[i];
					vector_privado[i] = vector_privado[i-1];
					vector_privado[i-1] = intercambia;
				}
			}		
		}	
	}
	
	/***********************************************************************/
	//M�todo de ordenaci�n por Intercambio Directo o Burbuja (Bubble Sort)
	//Segunda Aproximaci�n: 
	
	void OrdenaIntercambioMejorado_NuevoOrden()
	{
		bool cambio=true; // Para obligar a entrar al ciclo
		
		for (int izda=0; izda<total_utilizados && cambio;izda++)
		{
			// En cada pasada iniciamos "cambio" a false.
			// Se pondr� a true si y solo si hay alg�n intercambio
			
			cambio=false;
			
			for(int i=total_utilizados-1; i>izda ;i--)
			{
				if(NuevoOrden_Mayor(vector_privado[i], vector_privado[i-1])
					==vector_privado[i-1])	// Intercambiar
				{ 
					int intercambia=vector_privado[i];
					vector_privado[i]=vector_privado[i-1];
					vector_privado[i-1]=intercambia;
					
					// Se ha hecho un intercambio.
					// Se obliga a una nueva iteraci�n del ciclo externo.
					
					cambio=true;
				}	
			}
		}	
	}
	
};

class TablaRectangularEnteros 						//Secuencia de secuencias
{
	
private:
	
	static const int NUM_FILS=100; 	//Filas reservadas
	
	// (NUM_COlS = TAMANIO de SecuenciaEnteros)
	static const int NUM_COLS=4; 	//Columnas reservadas 
	
	SecuenciaEnteros vector_privado[NUM_FILS];
	
	//PRE: 0 <= filas_utilizadas <= NUM_FILS
	// PRE: 0 <= cols_utilizadas <= NUM_COLS

	
	int filas_utilizadas; 	//Filas utilizadas	
	int cols_utilizadas; 	//Columnas utilizadas
	
public:
	
	/*********************************************************************/
	//Constructor sin argumentos
	
	TablaRectangularEnteros(void):
		filas_utilizadas(0),
		cols_utilizadas(0)
	{}
	
	/*********************************************************************/
	//Constructores con argumentos
	
	// Recibe "numero_de_columnas" que indica el n�mero de
	// columnas que deben tener TODAS las filas.
	// PRE: numero_de_columnas <= NUM_COLS
	
	TablaRectangularEnteros(int num_columnas):
		filas_utilizadas(0),
		cols_utilizadas(num_columnas)
	{}
	
	
	// Recibe "primera_fila" (una secuencia de enteros).
	// El n�mero de elementos de la secuencia es el valor que se
	// usar� como "cols_utilizadas"
	// PRE: primera_fila.TotalUtilizados() <= NUM_COLS
	
	TablaRectangularEnteros (SecuenciaEnteros primera_fila):
		filas_utilizadas(0),
		cols_utilizadas (primera_fila.TotalUtilizados())
	{
		Aniade(primera_fila); // Actualiza "filas_utilizadas"
	}
	
	/*********************************************************************/
	/*********************************************************************/
	//Devuelve la capacidad de las filas 
	
	int CapacidadFilas(void)
	{
		return NUM_FILS;
	}
	
	/*********************************************************************/
	//Devuelve la capacidad de las columnas 
	
	int CapacidadColumnas(void)
	{
		return NUM_COLS;
	}
	
	/*********************************************************************/
	//Devuelve las filas utilizadas
	
	int FilasUtilizadas(void)
	{
		return filas_utilizadas;
	}
	
	/*********************************************************************/
	//Devuelve las columnas utilizadas
	
	int ColumnasUtilizadas(void)
	{
		return cols_utilizadas;
	}
	
	/*********************************************************************/
	//Devuelve el elemento dada su posici�n (fila y columna)
	// PRE: 0 <= fila < filas_utilizadas
	// PRE: 0 <= columna < cols_utilizadas
	
	int Elemento(int fila, int columna)
	{
		return (vector_privado[fila].Elemento(columna));
	}
	
	/*********************************************************************/
	//Devuelve una fila en forma de secuencia de enteros
	// PRE: 0 <= indice_fila < NUM_FILS
	
	SecuenciaEnteros Fila(int indice_fila)
	{
		return (vector_privado[indice_fila]);
	}
	
	/*********************************************************************/
	//Devuelve una columna en forma de secuencia de enteros
	// PRE: 0 <= indice_columna < NUM_COLS
	
	SecuenciaEnteros Columna(int indice_columna)
	{
		SecuenciaEnteros secuencia;
		
		//Fijo la columna y voy variando la fila
		for(int i=0; i<filas_utilizadas; i++)
		{
			secuencia.Aniade(vector_privado[i].Elemento(indice_columna));
		}
		
		return (secuencia);
	}
	
	/*********************************************************************/
	/*********************************************************************/
	// A�ade una secuencia de enteros como una nueva fila
	// PRE: fila.TotalUtilizados() == cols_utilizadas
	// PRE: filas_utilizadas < NUM_FILS
	
	void Aniade(SecuenciaEnteros fila_nueva)
	{
		int numero_cols_fila=fila_nueva.TotalUtilizados();
		
		
		if ((filas_utilizadas<NUM_FILS)&&(numero_cols_fila==NUM_COLS)) 
		{
			vector_privado[filas_utilizadas]=fila_nueva;
			filas_utilizadas++;
		}

	}
	
	/*********************************************************************/
	// Elimina una fila completa (un objeto "SecuenciaCaracteres").
	// PRE: 0 <= num_fila < TotalUtilizados()
	
	void EliminaFila (int indice_fila)
	{
		if ((0<=indice_fila) && (indice_fila <=filas_utilizadas)) 
		{
			// "Desplazar" las filas hacia posiciones bajas.
			// En la posici�n "num_fila" se copia la que est�
			// en la siguiente ("num_fila"+1), ... y en la posici�n
			// "total_utilizados"-2 se copia la de "total_utilizados"-1.
			
			for (int fil=indice_fila; fil<filas_utilizadas-1; fil++)
			{
				vector_privado[fil]=vector_privado[fil+1];	
			}
		
			filas_utilizadas--; // Actualizar el tama�o de la tabla.
		}
	}

	/*********************************************************************/
	//"Elimina" todos los elementos de la tabla
	
	void EliminaTodos(void)
	{
		filas_utilizadas=0;
		cols_utilizadas=0;
	}
	
	/*********************************************************************/
	//Consulta si la tabla est� vac�a
	
	bool EstaVacia (void)
	{
		return (filas_utilizadas || cols_utilizadas);
	}
	
	/*********************************************************************/
	//Comprueba si es igual a otra tabla rectangular
	
	bool EsIgual (TablaRectangularEnteros otra)
	{
		bool iguales=true;
		
		//Si las dimensiones no coinciden ya son diferentes
		
		if(cols_utilizadas!=otra.ColumnasUtilizadas() || 
		   				filas_utilizadas!=otra.FilasUtilizadas())
		{
			iguales=false;
		}
		else 
		{
			//Compruebo elemento a elemento que sean iguales
			
			for(int fila=0; fila<filas_utilizadas;fila++)//Recorro filas
			{
				for(int col=0; col<cols_utilizadas;col++)//Recorro columnas
				{
					if(Elemento(fila,col)!=otra.Elemento(fila,col))
					{
						iguales=false;
					}
				}
			}
		}		
		
		return iguales;	
	}
	
	/*********************************************************************/
	/*********************************************************************/
	//Devuelve la tabla en formato string
	//Tiene el separador por defecto con posibildad de cambiarlo
	//Se lee puede agregar un margen a la izquierda
	
	string ToString(string separador=" ", int margen=0)
	{
		string cadena;
		string str_margen;
		
		if(margen>0)
		{
			for(int i=0; i<margen; i++)
			{
				str_margen+=" ";
			}
		}
		
		for(int fila=0; fila<filas_utilizadas; fila++)// recorro filas
		{
			cadena+=str_margen+Fila(fila).ToString(separador)+"\n";
		}
		
		return cadena;
	}
	
	/*********************************************************************/
	/*********************************************************************/
	// Devuelve el �ndice de la fila que m�s se parezca a un vector dado
	// referencia de enteros buscando en las filas dadas por el vector
	// filas_a_comparar. La similitud vendr� dada por la distancia eucl�dea
	// entre ambos vectores
	
	int FilaSimilarMasCercana(SecuenciaEnteros referencia, 
							  SecuenciaEnteros filas_a_comparar )
	{
		int distancia_minima=-1; //Le doy un valor negativo para que 
								 //cualquiera que calcule sea mayor
		int indice_fila;
		
		
		for(int i=0; i<filas_a_comparar.TotalUtilizados(); i++)
		{
			int diferencia_coordenadas;
			int suma_cuadrados=0;
			int distancia_aux;
			
			
			for(int j=0; j<referencia.TotalUtilizados(); j++)
			{
				//Calculo la distancia a cada vector
				diferencia_coordenadas+=
						Fila(filas_a_comparar.Elemento(i)).Elemento(j)
					  - referencia.Elemento(j);
					  
				suma_cuadrados+=pow(diferencia_coordenadas,2);
					
			}
			
			distancia_aux=sqrt(suma_cuadrados);
			
			if(distancia_aux<=distancia_minima)
			{
				distancia_minima=distancia_aux;
				indice_fila=filas_a_comparar.Elemento(i);
			}
			
		}
		
		return indice_fila;
		
	}
};

/****************************************************************************/
/****************************************************************************/
int main()
{
	//Declaraci�n de Datos
	
	TablaRectangularEnteros tabla1;
	
	SecuenciaEnteros referencia("2811");
	SecuenciaEnteros filas_a_comparar("0245");
	
	//Relleno la tabla con vectores
	tabla1.Aniade(SecuenciaEnteros("3108"));
	tabla1.Aniade(SecuenciaEnteros("4515"));
	tabla1.Aniade(SecuenciaEnteros("5717"));
	tabla1.Aniade(SecuenciaEnteros("7961"));
	tabla1.Aniade(SecuenciaEnteros("4955"));
	tabla1.Aniade(SecuenciaEnteros("2822"));
	tabla1.Aniade(SecuenciaEnteros("7325"));
	
	int fila_similar=tabla1.FilaSimilarMasCercana(referencia,filas_a_comparar);
	
	
	//Salidas 
	
	cout<<"Tabla generada:"<<endl;
	
	cout<<endl;
	cout<<tabla1.ToString(" ",8);
	cout<<endl;
	
	cout<<"Vector Referencia: "<<referencia.ToString(",")<<endl;
	cout<<"Filas a comparar: "<<filas_a_comparar.ToString(",")<<endl;
	
	cout<<endl;
	cout<<"El metodo FilaSimilarMasCercana devuelve: "<<fila_similar<<endl;
	
	cout<<"La fila "<<fila_similar<<" es: "
		<<tabla1.Fila(fila_similar).ToString()<<endl;
		

	return 0;
}

