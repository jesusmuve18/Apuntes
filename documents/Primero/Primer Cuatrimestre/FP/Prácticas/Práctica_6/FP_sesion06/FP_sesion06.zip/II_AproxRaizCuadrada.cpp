/****************************************************************************/
//	FUNDAMENTOS DE PROGRAMACI�N			RELACI�N_II				EJERCICIO_82
/****************************************************************************/
/*
	Jes�s Mu�oz Velasco 					Grupo:A2
	
		Pueden emplearse aproximaciones num�ricas para evitar el c�lculo con 
		la funci�n sqrt. Por ejemplo, en 
		https://www.youtube.com/watch?v=sOSdi9z8S6E puede ver un m�todo muy 
		sencillo. Implem�ntelo para el c�lculo de la raiz cuadrada de datos 
		double.	
		
		Implemente a continuaci�n una estimaci�n basada en la 
		proporcionalidad entre tri�ngulos. Se trata de aproximar la funci�n 
		y =raiz(x) por rectas entre los tramos determinados por los valores 
		con raices exactas. Por ejemplo, en la figura 12.A mostramos la 
		funci�n y =raiz(x) y remarcamos sobre el eje x los valores con raices 
		exactas (0, 1, 4, 9 y 16) y en el eje y los valores de las raices 
		exactas (0, 1, 2, 3 y 4). En la figura 12.B unimos los puntos 
		(x, raiz(x)) que verifican que x tiene raiz exacta.
		
		Si tomamos un segmento cualquiera en el eje x y lo vemos con detalle 
		observar� que hay una regi�n triangular bien delimitada. Por ejemplo 
		en la regi�n entre x = 1 y x = 4 puede ver el tri�ngulo delimitado por 
		los puntos (1, 1), (4, 1) y (4, 2) (figura 13.A). Por ser estrictos 
		se trata del tri�ngulo delimitado por los puntos (1,raiz(1)), 
		(4,raiz(1)) y (4,raiz(4))
		
		La raiz de un valor x entre 1 y 4 se puede calcular geom�tricamente. 
		En la figura 13.B mostramos c�mo se calcula la raiz cuadrada de x =3.5. 
		Observe que el tri�ngulo delimitado por (1,raiz(1)), (3.5,raiz(1)) y 
		(3.5,raiz(3.5)) (tri�ngulo amarillo) es equivalente al delimitado por 
		los puntos (1,raiz(1)), (4,raiz(1)) y (4,raiz(4)) (tri�ngulo azul).
	
		Calcule la raiz cuadrada de un n�mero real positivo usando esta 
		aproximaci�n.
	
		Finalmente muestre una tabla comparativa en la que se muestren los 
		valores estimados por los dos m�todos y por la funci�n sqrt para 
		valores de x desde 0 a 16, con saltos de 0.5. �Puede extraer alguna 
		conclusi�n de esta tabla? �Puede proponer un m�todo de estimaci�n 
		mejor -m�s ajustado al verdadero valor- que los dos implementados?
	
*/
/****************************************************************************/
#include<iostream>
#include<cmath>
#include<iomanip>
using namespace std;
/****************************************************************************/
int main()
{
	
	//Declaraci�n de datos
	
	const double SALTO=0.5;
	const double LIMITE=16; //N�mero hasta el que se calcular ra�ces
	
	double x; //Numero al que aplicar la ra�z cuadrada
	int dif_abajo, dif_arriba; 	//Los utilizar� para elegir el 
								//valor cuya raiz este mas cercana
	int dif_abajo_p2, dif_arriba_p2;//El cuadrado de las magnitudes anteriores					
	int min_dif; //Valor cuyo cuadrado se aproxima m�s a x
	double resultado_1, resultado_2, resultado_3; 
	bool condicion, datos_ok;
	int contador;
	double error_1, error_2;
	double h1, x1, h2, x2; 

	
	//Entradas
	
	cout<<"Calculadora de raices cuadradas:"<<endl;
	cout<<"Valor sobre el que calcular: ";
	cin>>x;
		
	cout<<"  -------------------------------------------------------- "<<endl;
	cout<<" |   x  |    Metodo 1    |     Metodo 2     |   sqrt(x)   |"<<endl;
	cout<<" |--------------------------------------------------------|"<<endl;
	
	
	
	//C�lculos
	datos_ok=(x>=0);
	
	if(datos_ok)
	{
		///M�todo 1:
		
		contador=0;
		condicion=true; //para entrar al bucle de una forma �nica
		while(condicion)
		{
			if((contador*contador)<x)
			{
				dif_abajo=contador;
			}
			else
			{
				dif_arriba=contador;
				condicion=false;
			}
			contador++;
		}
		
		dif_abajo_p2=dif_abajo*dif_abajo;
		dif_arriba_p2=dif_arriba*dif_arriba;
		
		if((x-dif_abajo_p2)>=(dif_arriba_p2-x))
		{
			min_dif=dif_arriba;
		}
		else
		{
			min_dif=dif_abajo;
		}
		
		resultado_1=min_dif+((x-(min_dif*min_dif))/(min_dif*2.0));
		
		/********************************************************************/	
		
		//M�todo 2:
		
		dif_abajo_p2=dif_abajo*dif_abajo;
		dif_arriba_p2=dif_arriba*dif_arriba;
		
		h1 = dif_arriba_p2-dif_abajo_p2;
		x1 = dif_arriba-dif_abajo;
		h2 = x-dif_abajo_p2;
		x2;
		
		x2=((h2*x1)/h1);
		
		resultado_2= x2 + dif_abajo;
		
		resultado_3=sqrt(x);
		
		
		error_1=abs(resultado_1-resultado_3); //Aplicando teor�a de errores 
		error_2=abs(resultado_2-resultado_3); //para saber cual es m�s preciso
		
		//Salidas
		
		cout<<" | "<<x<<"\t|   "
			<<resultado_1<<"   \t |     "
			<<resultado_2<<"\t    |  "
			<<resultado_3<<"\t  | ";
		if(error_1!=0 || error_2!=0)
		{
			if(error_1<error_2)
				cout<<"  Error 1: "<<error_1<<" *"<<" \t Error 2: "<<error_2;
			else
				cout<<"  Error 1: "<<error_1<<"   \t Error 2: "<<error_2<<" *";
		}
		else
		{
			cout<<"  La raiz es exacta";
		}
		cout<<endl;	
	}
	
	
	/************************************************************************/	
	/************************************************************************/	
	//Desarrollo del resto de la tabla
	
	dif_abajo=0; //Por si no encuentra uno para evitar errores (en el 0 , 0.5)
	
	for(x=0; x<=LIMITE; x+=SALTO)
	{
		//M�todo 1:
		
		contador=0;
		condicion=true;
		
		while(condicion)
		{
			if((contador*contador)<x)
			{
				dif_abajo=contador;
			}
			else
			{
				dif_arriba=contador;
				condicion=false;
			}
			contador++;
		}
		
		dif_abajo_p2=dif_abajo*dif_abajo;
		dif_arriba_p2=dif_arriba*dif_arriba;
		
		if((x-dif_abajo_p2)>=(dif_arriba_p2-x))
		{
			min_dif=dif_arriba;
		}
		else
		{
			min_dif=dif_abajo;
		}
		
		resultado_1=min_dif+((x-(min_dif*min_dif))/(min_dif*2.0));
				
		/********************************************************************/
		/*El valor estar� en el intervalo (dif_abajo,dif_arriba) que ser�n los 
		  valores sobre los que se crear� el tri�ngulo:
		                                    
		  						       		 __ 
		  					     /|			  |
		  					   /  |   __	  |
		     				 /	  |     |	  |
						   / |	  |	    |	  |				
			             /	 |	  |	    |	  | 		
			           /	 |	  |	    |	  |	h1		
			         /		 |	  |	    | h2  |			
			       /		 |    |	    |	  |	
		         /			 |	  |	    |	  |					
			   /			 |	  |	    |     |					
			 /__a			 |	  |	    |     |			
		   /___|_____________|____|	  __|   __|			
		   
		   |_________________|    
		   			x2
		   |______________________|
		  	          x1
		  	          
		Bas�ndonos en la simetr�a de tri�ngulos sabemos que:
		
		tg(a)=h1/x1; y adem�s tg(a)=h2/x2; ==>   h1/x1=h2/x2;
		
		h1= dif_arriba_p2-dif_abajo_p2  
		h2= x-dif_abajo_p2
		x1= dif_arriba-dif_abajo
		x2= resultado-dif_abajo
		
		despejando x2 que es donde se encuentra el resultado:
		
		     h2*x1
		x2= ______;
		      h1
		     
		 y despejando por �ltimo el resultado:
		 
		 resultado= x2 + dif_abajo
		*/
		
		//M�todo 2:
		
		
		
		h1 = dif_arriba_p2-dif_abajo_p2;
		x1 = dif_arriba-dif_abajo;
		h2 = x-dif_abajo_p2;
		x2;
		
		x2=((h2*x1)/h1);
		
		resultado_2= x2 + dif_abajo;
		
		resultado_3=sqrt(x);
		
		error_1=abs(resultado_1-resultado_3); //Aplicando teor�a de errores 
		error_2=abs(resultado_2-resultado_3); //para saber cual es m�s preciso
		
		//Salidas
		
		cout<<" | "<<x<<"\t|   "
			<<resultado_1<<"   \t |     "
			<<resultado_2<<"\t    |  "
			<<resultado_3<<"\t  | ";
		if(error_1!=0 || error_2!=0)
		{
			if(error_1<error_2)
				cout<<"  Error 1: "<<error_1<<" *"<<" \t Error 2: "<<error_2;
			else
				cout<<"  Error 1: "<<error_1<<"   \t Error 2: "<<error_2<<" *";
		}
		else
		{
			cout<<"  La raiz es exacta";
		}
		cout<<endl;
		//Con el s�mbolo '*' doy a conocer de manera visual el resultado m�s 
		//peque�o de los errores, es decir, el m�todo m�s preciso (entre 1 y 2)	
		
	}
	
	cout<<"  --------------------------------------------------------"<<endl;   
	
	if(!datos_ok)
	{
		cout<<"El valor introducido no era valido"<<endl;
	}
	
	return 0;
}
/* CONCLUSIONES:
	Con el primer m�todo los resultados siempre son ligeramente superiores al 
	real mientras que por el segundo m�todo los valores resultan ligeramente
	inferiores pero ninguno demuestra ser sistem�ticamente m�s preciso que 
	otro.
	Un m�todo m�s preciso sin duda ser�a la media de los resultados calculados
	por el m�todo 1 y por el 2 ya que el error ser�a menor.
*/
