/****************************************************************************/
//	FUNDAMENTOS DE PROGRAMACI�N			RELACI�N_II				EJERCICIO_1
/****************************************************************************/
/*
	Jes�s Mu�oz Velasco 					Grupo:A2
	
	Explicaci�n del programa:
	
	Escribir un programa que muestre la representaci�n binaria de un n�mero 
	entero (positivo o cero) expresado en base 10.
	El programa pedir� el n�mero decimal que se va a convertir y calcular� su 
	representaci�n binaria sobre un dato string (los bits que conforman la 
	representaci�n binaria del n�mero ser�n caracteres '0' � '1').
	
	El programa pedir� en primer lugar el n�mero de bits (llam�mosle n) que 
	tendr�n los valores binarios con los que se va a trabajar. Dado n los 
	n�meros enteros que se admitir�n estar�n comprendidos entre 0 y 2^(n - 1)
	(todos ellos pueden representarse estrictamente con n bits o menos).
	
	(NOTA: el n�mero de bits del resultado siempre ser� n (si fuera necesario 
	se rellenar�n con '0' a la izquierda del primer '1')
	
	Entradas: N�mero en decimal
	
	Salidas: N�mero en binario (representado con n d�gitos)
	
*/
/****************************************************************************/
#include<iostream>
#include<string.h>
#include<cmath>
using namespace std;
/****************************************************************************/
int main()
{
	
	//Declaraci�n de datos
	
	const int BASE=2;
	
	int decimal;
	string binario;
	int n; //N�mero de cifras para la representacion
	int contador=2;
	bool decimal_ok, n_ok, datos_ok;
	
	//Entradas
	
	cout<<"Numero en decimal: ";
	cin>>decimal;
	
	cout<<"Numero de cifras para la representacion: ";
	cin>>n;
	
	//C�lculos
	
	decimal_ok=decimal>=0;
	n_ok=n>0;
	datos_ok=( decimal_ok && n_ok);
	
	if(datos_ok)
	{
		if(decimal<=(pow(BASE,n)))
		{
			for(int i=0; i<n; i++)
			{
				binario.push_back('0');
			}
			
			int cociente,resto;
			cociente=decimal;
			
			if(cociente!=1)
			{
				while(cociente!=1)
				{
					cociente=cociente/BASE;
					resto=cociente%BASE;
					binario.at(binario.length()-contador)=(resto+'0');
					contador++;
				}
			}
			else
				binario.at(0)='1';
			
		}
		
		//Salidas
		if(decimal<=(pow(BASE,n)))
			cout<<"La representacion en binario es: "<<binario<<endl;
		else
			cout<<"No hay suficientes bits para su representacion"<<endl;
	}
	else
	{
		if(!decimal_ok)
			cout<<"Numero entero positivo no valido"<<endl;
		else
			cout<<"Numero de cifras para la representacion no valido"<<endl;
	}
		
	
		
	return 0;
}
/*EXPLICACI�N:
	El programa lee el n�mero en decimal y el n�mero de d�gitos, n. Despu�s
	relleno una string llamada binario (que ser� finalmente el resultado) con
	ceros, ya que esa ser�a la representaci�n del 0 en binario con n bits.
	
	Despu�s ir� siguiendo el m�todo de la divisi�n para pasar el n�mero 
	a binario sustituyendo en la cadena algunos 0 por 1 de modo que al final 
	quedar� la cadena con el n�mero en binario en su sitio y el resto lleno 
	de ceros como se pide en el enunciado.
	*/
