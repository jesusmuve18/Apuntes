/****************************************************************************/
//	FUNDAMENTOS DE PROGRAMACI�N			RELACI�N_II				EJERCICIO_1
/****************************************************************************/
/*
	Jes�s Mu�oz Velasco 					Grupo:A2
	
	Explicaci�n del programa:
	
	Escribid un programa calcule CDF(x) para un valor de x dado. El programa 
	debe pedir los par�metros que definen una funci�n gaussiana (esperanza
	y desviaci�n t�pica) y 	el valor de la abscisa,	x, para el que se va a 
	calcular CDF(x).
	
	Entradas: mu, sigma y x
	
	Salidas: CDF(x) para los par�metros indicados.
	
*/
/****************************************************************************/
#include<iostream>
#include<cmath>
using namespace std;
/****************************************************************************/
int main()
{
	
	//Declaraci�n de datos
	
	const double SALTO= 0.000001;			//Cuanto menor sea, m�s precisi�n  
											//tendr� el resultado
	const double PI=3.14159265359;
	const double CTE=10; 	//Valor que utilizo para darle un valor inicial a 
							//"-infinito" (cuanto mayor sea, m�s preciso ser�
							//el resultado)									
	
	 double mu; //Esperanza o media
	 double sigma;	//Desviaci�n t�pica
	 double cdf=0;
	 double x_aux, x_final;
	 double g_aux;
	 bool datos_ok;
	
	//Entradas
	
	cout<<"Esperanza: ";
	cin>>mu;
	cout<<"Desviacion Tipica: ";
	cin>>sigma;
	cout<<"Valor de x: ";
	cin>>x_final;
	
	
	//C�lculos
	
	datos_ok=(sigma>=0);
	
	if(datos_ok)
	{
		for(x_aux=(mu-(CTE*sigma)) ; x_aux<=x_final ; x_aux+=SALTO)
		{
			g_aux=(exp(-0.5*pow ((x_aux-mu)/sigma,2))/(sigma*sqrt(2*PI)))*SALTO;
			cdf+=g_aux;
		}
		/*Al ser el c�lculo de un �rea lo aproximar� a la suma de areas de 
		"rectangulitos" que tendr�n de ancho el denominado SALTO y de alto el 
		valor de la funci�n en el punto. Al ser rect�ngulos el �rea se 
		calcular� como base*altura de modo que el rect�ngulo en el punto x1 
		ser�:
				area=g(1)*SALTO, siendo g(1) la gaussiana en el punto.
		*/
		
		//Salidas
		
		cout<<"La CDF de una variable cualquiera Normal("<<mu<<","<<sigma
			<<") en "<<"x = "<<x_final<<" es: "<<endl;
		cout<<"\t"<<cdf<<endl;
	}
	else
		cout<<"Valor de desviacion tipica no valido"<<endl;
	
	return 0;
}
