/****************************************************************************/
//	FUNDAMENTOS DE PROGRAMACI�N			RELACI�N_II				EJERCICIO_49
/****************************************************************************/
/*
	Jes�s Mu�oz Velasco 					Grupo:A2
	
	Dise�ar un programa para jugar a adivinar un n�mero. El programa generar� 
	un n�mero aleatorio (entre MIN y MAX) y el usuario tendr� que adivinarlo. 
	En cada jugada el jugador introducir� un valor y el el juego indicar� si 
	el n�mero introducido por el jugador est� por encima o por debajo del 
	n�mero a adivinar.
	
	Como reglas de parada considerad que el usuario: 1) haya acertado, � 2) 
	no quiera seguir jugando, y en este caso usad un valor especial 
	(TERMINADOR) para abandonar.

	Entradas: N�meros (intentando adivinar el n�mero secreto)
	
	Salidas: -Si el n�mero introducido es mayor o menor que la inc�gnita
			 -Si se ha ganado o no
	
*/
/****************************************************************************/
#include<iostream>
#include<ctime>
#include<cstdlib>
using namespace std;
/****************************************************************************/
int main()
{
	
	//Declaraci�n de datos
	
	const int TERMINADOR=0;	
	const int MIN = 1;
	const int MAX = 100;
	const int NUM_VALORES = MAX-MIN + 1; // N�m. de valores posibles
	
	time_t t;
	srand(time(&t)); 	// Inicializa generador de n�ms. aleatorios
						// con el reloj del sistema (hora actual)
						
	int incognita; 	// N�mero aleatorio que se genera
	int numero;		// N�mero que se introduce para adivinar la inc�gnita
	
	bool victoria=false;	//Indica si se ha adivinado la inc�gnita	
	
	incognita = (rand() % NUM_VALORES) + MIN;
	
	//Entradas y c�lculos
	
	cout<<"Intenta adivinar en numero secreto: "<<endl;
	cout<<"Si quieres dejar de jugar pulsa el "<<TERMINADOR<<endl;
	
	do
	{
		cout<<">";
		cin>>numero;
		if(numero!=TERMINADOR)
		{
			if(numero<incognita)
			{
				cout<<"La incognita es mayor"<<endl;
			}
			if(numero>incognita)
			{
				cout<<"La incognita es menor"<<endl;
			}
		}
		if(numero==incognita)
		{
			victoria=true;
		}
		
		cout<<endl;
		
	} while(numero!=incognita && numero!=TERMINADOR);
			
	
	//Salidas
	
	if(victoria==true)
	{
		cout<<"Enhorabuena has acertado la incognita"<<endl;
	}
	else
	{
		cout<<"Vaya, parece que te has rendido"<<endl;
	}
	
	
	
	return 0;
}
/* EXPLICACI�N:
	Una vez generado el n�mero aleatorio se van pidiendo n�meros. Entre cada 
	lectura de datos el programa compara el n�mero introducido con el n�mero
	oculto e indica si es mayor o menor. 
	Hay 2 maneras de salir de este bucle:
	-Pulsando la tecla TERMINADOR. En este caso el juego indicar� que el 
	 jugador se ha rendido.
	-Adivinando el n�mero secreto. En este caso el juego indicar� la victoria.
	 
*/
