/****************************************************************************/
//	FUNDAMENTOS DE PROGRAMACI�N			RELACI�N_VI				EJERCICIO_20
/****************************************************************************/
/*
	Jes�s Mu�oz Velasco 					Grupo:A2

	Enunciado:
	
	 (Examen Conv. Extraordinaria Febrero 2022) Un pal�ndromo es una secuencia 
	 que se lee igual de izquierda a derecha que de derecha a izquierda. Se 
	 pide que defina un m�todo que calcule y devuelva el pal�ndromo de mayor 
	 longitud contenido en una secuencia. Dicho pal�ndromo siempre existe y 
	 ser� un objeto de la clase SecuenciaCaracteres.
	 
	SecuenciaCaracteres MayorPalindromoContenido (void);
	
	Si hay varios con la misma longitud, tiene libertad para elegir cu�l de 
	ellos devolver.
	
	Por ejemplo, el mayor pal�ndromo contenido en CABBADE es la subsecuencia 
	ABBA, mientras que el mayor pal�ndromo contenido en ABCDEF es cualquiera 
	de las subsecuencias de tama�o 1, por ejemplo A. El mayor pal�ndromo 
	contenido en ABBA es la subsecuencia ABBA, y el mayor pal�ndromo en 
	gAAtySHHSvvABCCBAfh es la subsecuencia ABCCBA.


	Salidas: Secuencia generada y pal�ndromo de mayor longitud

*/
/****************************************************************************/
#include<iostream>
using namespace std;

/****************************************************************************/
//Declaraci�n de Clases/Objetos

class SecuenciaCaracteres {

private:

    static const int TAMANIO = 50; // N�m.casillas disponibles
    char vector_privado[TAMANIO];

    // PRE: 0<=total_utilizados<TAMANIO

    int total_utilizados; // N�m.casillas ocupadas

public:

    /***********************************************************************/
    // Constructor sin argumentos

    SecuenciaCaracteres (void) : total_utilizados (0)
    {}
    
    //Constructor con argumentos 
    
    SecuenciaCaracteres(string cadena)
    {
    	total_utilizados=cadena.length();
    	
    	for(int i=0; i<total_utilizados ; i++)
    	{
    		vector_privado[i]=cadena.at(i);
		}
	}
	
	/***********************************************************************/
	//Actualiza la secuencia con una cadena dada
	SetSecuencia(string cadena)
	{
		total_utilizados=cadena.length();
    	
    	for(int i=0; i<total_utilizados ; i++)
    	{
    		vector_privado[i]=cadena.at(i);
		}
	}
	
    /***********************************************************************/
    // Devuelve el n�mero de casillas ocupadas

    int TotalUtilizados (void)
    {
        return (total_utilizados);
    }

    /***********************************************************************/
    // Devuelve el n�mero de casillas disponibles

    int Capacidad (void)
    {
        return (TAMANIO);
    }

    /***********************************************************************/
    // "Vac�a" completamente la secuencia

	void EliminaTodos()
	{
		total_utilizados = 0;
	}

    /***********************************************************************/
    // A�ade un elemento ("nuevo") al vector.
    // PRE: total_utilizados < TAMANIO
    // 		La adici�n se realiza si hay alguna casilla disponible.
    // 		El nuevo elemento se coloca al final del vector.
    // 		Si no hay espacio, no se hace nada.

    void Aniade (char nuevo)
    {
        if (total_utilizados < TAMANIO){
            vector_privado[total_utilizados] = nuevo;
            total_utilizados++;
        }
    }

    /***********************************************************************/
    // Devuelve el elemento de la casilla "indice"
    // PRE: 0 <= indice < total_utilizados

    char Elemento (int indice)
    {
        return (vector_privado[indice]);
    }

    /***********************************************************************/
    // Cambia el contenido de la casilla "indice" por el valor "nuevo"
    // PRE: 0 <= indice < total_utilizados

   void Modifica (int indice, char nuevo)
   {
		if ((indice >= 0) && (indice < total_utilizados))
			vector_privado[indice] = nuevo;
   }


    /***********************************************************************/
    // Eliminar el car�cter de la posici�n dada por "indice".
    // Realiza un borrado f�sico (desplazamiento y sustituci�n).
    // PRE: 0 <= indice < total_utilizados

    void Elimina (int indice)
    {
        if ((indice >= 0) && (indice < total_utilizados)) {

            int tope = total_utilizados-1; // posic. del �ltimo

            for (int i = indice ; i < tope ; i++)
                vector_privado[i] = vector_privado[i+1];

            total_utilizados--;
        }
    }
 

    /***********************************************************************/
    // Inserta el car�cter "nuevo" en la posici�n dada por "indice".
    // Desplaza todos los caracteres una posici�n a la derecha antes de 
	// copiar en "indice" en valor "nuevo".
	// PRE: 0 <= indice < total_utilizados
    // PRE: total_utilizados < TAMANIO
    // 		La inseerci�n se realiza si hay alguna casilla disponible.
    // 		Si no hay espacio, no se hace nada.
    
	void Inserta (int indice, char valor_nuevo)
	{
        if ((indice >= 0) && (indice < total_utilizados) 
		    && (total_utilizados < TAMANIO)) {
		
			for (int i = total_utilizados ; i > indice ; i--)
				vector_privado[i] = vector_privado[i-1];
			
			vector_privado[indice] = valor_nuevo;
			total_utilizados++;		
		}
	}
   
    /***********************************************************************/
    // Compone un string con todos los caracteres que est�n
    // almacenados en la secuencia y lo devuelve.

    string ToString()
    {
        string cadena;

        for (int i=0; i<total_utilizados; i++)
            cadena = cadena + vector_privado[i];

        return (cadena);
    }
	
	/***********************************************************************/
	void EliminaOcurrencias (char caracter)
	{
		int posicion=0;
		while(posicion<total_utilizados)
		{
			if(vector_privado[posicion]==caracter)
			{
				Elimina(posicion);
			}
			else
			{
				posicion++;
			}
		}
	}
	/***********************************************************************/
	/***********************************************************************/
	//Devuelve una subsecuencia dada la posicion del primer elemento y la 
	//longitud que debera tener la subsecuencia
	//PRE: posicion_inicial+longitud <= total_utilizados
	
	string Subsecuencia(int posicion_inicial, int longitud)
	{
		string subsecuencia;
		
		for(int i=posicion_inicial; i<posicion_inicial+longitud; i++)
		{
			subsecuencia+=vector_privado[i];
		}
		
		return subsecuencia;
	}
	
	/***********************************************************************/
	//Verifica si una cadena es pal�ndroma
	
	bool EsPalindromo(string cadena)
	{
		
		string cadena_invertida;
		bool palindromo=false;
		
		
		for(int i=1; i<=cadena.length(); i++)
		{
			cadena_invertida+=cadena[cadena.length()-i];
		}
		
		if(cadena==cadena_invertida)
		{
			palindromo=true;
		}
		
		return palindromo;
		
	}
	/***********************************************************************/
	//Devuelve el pal�ndromo de mayor longitud de la secuencia
	
	string Palindromo_mayor_longitud ()
	{
		string mayor_palindromo;
		
		for(int longitud=1; longitud<=total_utilizados; longitud++)
		{
			for(int posicion_inicial=0; 
			   posicion_inicial<=total_utilizados-longitud; posicion_inicial++)
			{
				
				if(EsPalindromo(Subsecuencia(posicion_inicial,longitud)))
				{
					/*Dado que la longitud es un par�metro que toma valores 
					  cada vez mayores o iguales al anterior, cualquier nuevo
					  pal�ndromo que encuentre ser� de longitud mayor o igual a
					  la anterior y lo guardar� como el mayor */
					
					mayor_palindromo=Subsecuencia(posicion_inicial,longitud);
				}
				
			}
			
		}
		
		return mayor_palindromo;
	}
};

/****************************************************************************/
/****************************************************************************/
int main()
{
	//Declaraci�n de Datos

	
	SecuenciaCaracteres MayorPalindromoContenido ("gAAtySHHSvvABCCBAfh");

	//Salidas
	
	cout<<"Secuencia generada: |"<<MayorPalindromoContenido.ToString()<<"|"
		<<endl;
		
	cout<<"Palindromo contenido de mayor longitud: "
		<<"|"<<MayorPalindromoContenido.Palindromo_mayor_longitud()<<"|"<<endl;

	return 0;
	
}

