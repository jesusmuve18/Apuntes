/****************************************************************************/
//	FUNDAMENTOS DE PROGRAMACI�N			RELACI�N_V				EJERCICIO_8
/****************************************************************************/
/*
	Jes�s Mu�oz Velasco 					Grupo:A2
	
	Enunciado:
	
	Recuperad el ejercicio 30 de la Relaci�n de Problemas III sobre la funci�n 
	gaussiana. En vez de trabajar con funciones, plantead la soluci�n con una 
	clase.
	
	Debe dise�ar la clase teniendo en cuenta que la funci�n matem�tica 
	gaussiana viene determinada un�vocamente por el valor de la esperanza y la 
	desviaci�n, es decir, son estos dos par�metros lo que distinguen a una 
	funci�n gaussiana de otra.
	
	Recuerde a�adir un m�todo ToString para la clase. Sugerimos el siguiente 
	formato: si g es N(0, 1) y el objeto g representa a esa funci�n, la 
	ejecuci�n de g.ToString() devolver� la cadena N (0.000000, 1.000000).
	
	Entradas: mu y sigma
	
	Salidas: gaussiana(x) y CDF(x) calculado de dos formas diferentes
	
*/
/****************************************************************************/
#include<iostream>
#include<cmath>
#include<iomanip>
using namespace std;

const double PI=3.141592;
const double B_LENGTH=6;
const double B[]={ 0.2316419, 0.319381530, -0.356563782, 1.781477937 
				          -1.821255978, 1.330274429 };
				         
const double SALTO=0.25; //Distancia entre 2 valores consecutivos de x


/****************************************************************************/
/****************************************************************************/
class Gaussiana
{
	private:
		double mu;     //Esperanza
		double sigma;  //Desviaci�n
	public:
		Gaussiana (double esperanza, double desviacion):
			mu(esperanza), sigma(desviacion) {};
		
		double Calculo(double x)
		{
			return (exp(-0.5*pow ((x-mu)/sigma,2))/(sigma*sqrt(2*PI)));
		}
		
		double Cdf_1(double x)
		{
			//Declaraci�n de Datos
			
			double cdf=0;
			double x_final=x;
			
			
			//C�lculos (Desarrollo de la integral por sumatoria)
			
			for(double x_aux=(mu-(3*sigma)) ; x_aux<=x_final ; x_aux+=SALTO)
			{
				cdf+=Calculo(x_aux)*SALTO;
			}
			
			
			//Salida de la funci�n
			return cdf;
		
		}
		
		double Cdf_2(double x)
		{
			//Declaraci�n de Datos
			
			
			
			double cdf,w;
			double abs_x=fabs(x);
			double segundo_termino=1; //Inicializo con el neutro del producto
			
			double t;
			
			
			//C�lculos (Aproximaci�n num�rica)
			
			t=(1.0/(1+(B[0]*abs_x)));
			
			for(int i=1; i<B_LENGTH ; i++)
			{
				segundo_termino*=B[i]*pow(t,i);
			}

			
			w=1-(Calculo(abs_x)*segundo_termino);
	
			
			if(x>=0)
			{
				cdf=w;
			}
			else
			{
				cdf=1-w;
			}
			
			
			//Salida de la funci�n
			return cdf;
		}
		
		string ToString()
		{
			return ("N ("+to_string(mu)+" , "+to_string(sigma)+")");
		}
};

/****************************************************************************/
/****************************************************************************/
int main()
{
	
	//Programa de prueba de la funci�n
	
	cout.setf(ios::fixed);
	cout.setf(ios::showpoint);
	
	
	//Declaraci�n de datos
	
	double esperanza, desviacion, x;
	double x_min, x_max;
	
	
	//Entradas
	
	cout<<"Esperanza o media: ";
	cin>>esperanza;
	
	do //Filtro de la desviaci�n (tiene que ser positiva)
	{
		cout<<"Desviacion tipica: ";
		cin>>desviacion;	
	} while(desviacion<=0);
	
	
	
	//C�lculos
	
	Gaussiana g(esperanza,desviacion); //Genero un objeto con el constructor
	
	x_min=(esperanza-(3*desviacion));
	x_max=(esperanza+(3*desviacion));

	
	
	//Salidas
	
	cout<<endl;
	cout<<"Funcion: "<<g.ToString()<<endl;
	
	
	cout<<endl;
	cout<<" --------------------------------------------------------- "<<endl;
	cout<<"|           |              |             CDF(x)           |"<<endl;
	cout<<"|     x     | gaussiana(x) |------------------------------|"<<endl;
	cout<<"|           |              |    Metodo 1   |   Metodo 2   |"<<endl;
	cout<<"|-----------|--------------|---------------|--------------|"<<endl;


	for(double x=x_min;x<=x_max;x+=SALTO)
	{
		cout<<"|  ";
		cout<<setw(6)<<setprecision(2)<<x;
		cout<<"   | ";
		cout<<setw(12)<<setprecision(10)<<g.Calculo(x);
		cout<<" | ";
		cout<<setw(13)<<setprecision(11)<<g.Cdf_1(x);
		cout<<" | ";
		cout<<setw(12)<<setprecision(10)<<g.Cdf_2(x);
		cout<<" |"<<endl;
	}
	cout<<" --------------------------------------------------------- "<<endl;

	
	return 0;
}
