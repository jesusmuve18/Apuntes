/****************************************************************************/
//	FUNDAMENTOS DE PROGRAMACI�N			RELACI�N_V				EJERCICIO_7
/****************************************************************************/
/*
	Jes�s Mu�oz Velasco 					Grupo:A2
	
	Enunciado:
	
	Recuperar las clases escritas en el ejercicio 6 de esta misma Relaci�n de 
	Problemas. Escribir un programa que lea las coordenadas que definen un 
	rect�ngulo y calcule y muestre una serie de datos de tipo Circunferencia, 
	todas centrada en en el punto de corte de las diagonales del rect�ngulo.
	
	Las circunferencias en las que estamos interesadas ser�n todas las 
	circunferencias inscritas en el rect�ngulo. Para ello comience con una 
	circunferencia de radio radio=0.5 y vaya incrementando su valor 0.25 en 
	cada iteraci�n.
	
	Muestre cu�ntas circunferencias se han generado y a continuaci�n, sus 
	propiedades. Por ejemplo, dado el rect�ngulo de la figura 40, los objetos 
	Circunferencia que nos interesan son tres (la circunferencia con trazo 
	discontinuo no se guardar� porque no est� inscrita en el rect�ngulo).
	
	Entradas: Puntos extremos de la diagonal de un rect�ngulo
	
	Salidas: N�mero de posibles circunferencias inscritas en el rect�ngulo
			 dado y sus caracter�sticas
	
*/
/****************************************************************************/
#include<iostream>
#include<cmath>
using namespace std;

/****************************************************************************/
//Declaraci�n de constantes globales

const double RADIO_INICIAL=0.5;
const double SALTO_RADIO=0.25;
const double PI=3.14159265359;

/****************************************************************************/
//Declaraci�n de tipos de datos (struct)

struct Punto2D 
{
	double x; //abscisas
	double y; //ordenadas
};

/****************************************************************************/
//Declaraci�n de Clases/Objetos (struct)

class Rectangulo
{
	private:
		
		Punto2D punto_1; //coordenadas de uno de los v�rtices del rect�ngulo
		Punto2D punto_2; //coordenadas del punto opuesto con respecto a la 
					     //diagonal del punto_1
					     
	public:
		
		//Constructor sin par�metros
		//PRE: punto1.x, punto1.y, punto2.x, punto2.y >=0
		Rectangulo(){}; 
		
		//Constructor con par�metros
		//PRE: punto1.x, punto1.y, punto2.x, punto2.y >=0
		Rectangulo(Punto2D punto1, Punto2D punto2):
			punto_1(punto1),
			punto_2(punto2) {};
			
		
		//C�lculo del centro del rect�ngulo (cruce de diagonales)															
		Punto2D Centro()
		{
			Punto2D centro; //Dato que devolver� la funci�n
			
			double base=abs(punto_1.x-punto_2.x);
			double altura=abs(punto_1.y-punto_2.y);
			
			centro.x=min(punto_1.y,punto_2.y)+(base/2);
			centro.y=min(punto_1.x,punto_2.x)+(altura/2);
			
			return centro;
		}

		//C�lculo de la base del rect�ngulo									
		double Base()
		{
			return abs(punto_1.x-punto_2.x);	
		}
		
		//C�lculo de la altura del rect�ngulo
		double Altura()
		{
			return abs(punto_1.y-punto_2.y);	
		}
		
		string ToString()
		{
			string str;
			
			str="Punto 1: ("+to_string(punto_1.x)+" , "+to_string(punto_1.y)
				+")\nPunto 2: ("+to_string(punto_2.x)+" , "
				+to_string(punto_2.y)+")";
				
			return str;
		}
};

class Circunferencia
{
	private:
		
		Punto2D centro; //coordenadas del centro de la circunferencia
		double radio;
		
	public:
		
		//Constructor con 1 par�metro
		Circunferencia(Punto2D centro):centro(centro), radio(RADIO_INICIAL){};
		
		//Constructor con 2 par�metros
		Circunferencia(Punto2D centro, double radio):
			centro(centro), 
			radio(radio) {};
		
		//C�lculo del �rea
		double Area()
		{
			return (PI*radio*radio);
		}
		
		//Incremento del radio
		void Aumenta(double incremento)
		{
			radio+=incremento;
		}
		
		string ToString()
		{
			string str;
			str="\tCentro: ("+to_string(centro.x)+" , "+to_string(centro.x)+
				")\n\tRadio: "+to_string(radio)+" unidades";
			return str;
		}
		
		double Diametro()
		{
			return 2*radio;
		}
	
};

/****************************************************************************/
/*****************************************************************************
  	Funci�n: Lee decimal dependiendo de las condiciones que este debe tener
  			 para ser considerado v�lido
	Par�metros: T�tulo o etiqueta a modo de petici�n
	Devuelve: El entero en formato double
............................................................................*/
double LeeReal(string titulo)
{
	//#define MOSTRAR_ERROR
	
	string lectura;
	string caracteres_inicio="+-1234567890.";
	string caracteres_resto="1234567890.";
	string caracteres_una_vez=".";
	
	bool todo_ok;


	do
	{
		do
		{
			cout<<titulo;
			getline(cin,lectura);
			
			string aux;
			
			for(int i=0; i<lectura.length(); i++) //Le quito los espacios
			{
				if(lectura.at(i)!=' ')
				{
					aux+=lectura.at(i);
				}
			}
			
			lectura=aux;	
			
		} while(lectura.empty()); //Mientras no haya caracteres
	
		
		todo_ok=true;
		
		bool caracter_correcto;
		int siguiente_caracter=0;
		
		if(lectura.length()>1) //Si hay mas de un caracter
		{
			//Compruebo el primer caracter

			for(int i=0; i<caracteres_inicio.length(); i++)
			{
				if(lectura.at(0)==caracteres_inicio.at(i))
				{
					caracter_correcto=true;
				}
			}
			
			if(!caracter_correcto)
			{
				todo_ok=false;
				
				#ifdef MOSTRAR_ERROR
					
				cout<<"Caracter inicio incorrecto"<<endl;
				
				#endif
			}	
			
			siguiente_caracter=1;
		}
		
		
		//Compruebo el resto de caracteres

		
		for(int i=siguiente_caracter; i<lectura.length(); i++)
		{
			caracter_correcto=false;
			
			for(int j=0; j<caracteres_resto.length(); j++)
			{
				if(lectura.at(i)==caracteres_resto.at(j))
				{
					caracter_correcto=true;
				}
			}
			
			if(!caracter_correcto)
			{
				todo_ok=false;
				
				#ifdef MOSTRAR_ERROR
				
				cout<<"Caracter "<<i+1<<" incorrecto"<<endl;
				
				#endif
			}
			
		}	
		
		//Compruebo si hay caracteres repetidos que no deber�an
		
		int contador=0;
		
		for(int j=0; j<caracteres_una_vez.length(); j++)
		{
			contador=0;
			
			for(int i=0; i<lectura.length(); i++)
			{
				if(lectura.at(i)==caracteres_resto.at(j))
				{
					contador++;
				}
			}
			
			if(contador>1)
			{
				todo_ok=false;
				
				#ifdef MOSTRAR_ERROR
				
				cout<<"Caracter "<<caracteres_una_vez.at(j)<<" repetido"<<endl;
				
				#endif
			}
			
		}	
		
		#ifdef MOSTRAR_ERROR
				
		cout<<endl;
		
		#endif
		
	} while(!todo_ok);
	
	return stod(lectura);
}
														
/****************************************************************************/
/****************************************************************************/
int main()
{
	//Declaraci�n de Datos
	
	Punto2D punto1, punto2;
	bool todo_ok;
	
	//Entradas
	
	cout<<"Puntos que definen un rectangulo "
		<<"(puntos de extremos de una diagonal):"<<endl;
	
	
	cout<<"     Punto 1: "<<endl;
	punto1.x=LeeReal ("\tCoordenada X: ");
	punto1.y=LeeReal ("\tCoordenada Y: ");
	
	cout<<"    Punto 2: "<<endl;
	punto2.x=LeeReal ("\tCoordenada X: ");
	punto2.y=LeeReal ("\tCoordenada Y: ");
	
	cout<<"--------------------------------"<<endl;
	cout<<endl;
	
	Rectangulo rect(punto1,punto2);
	Circunferencia circ(rect.Centro());
		
	//C�lculos
	
	/*
		RADIO_INICIAL+SALTO_RADIO*num_circ = Altura/2   ==>
		
		==> SALTO_RADIO*num_circ = Altura/2 - RADIO_INICIAL  ==>
		
		                Altura/2 - RADIO_INICIAL
		==> num_circ = --------------------------
		                      SALTO_RADIO
		                      
		Teniendo en cuenta la circunferencia de radio inicial que ser�a contar
		el num_circ como 0 tendremos que sumarle 1 a este resultado
	*/
	int num_circ=(((rect.Altura()/2)-RADIO_INICIAL)/SALTO_RADIO)+1;
	
	
	//Salidas
	
	if(num_circ>=1)
	{
		cout<<"Hay "<<num_circ<<" posibles circunferencias inscritas"<<endl;
		
		cout<<endl;
		cout<<"--------------------------------"<<endl;
			   
		cout<<endl;
		
		int contador=1;
		
		while(circ.Diametro()<=rect.Altura())
		{
			cout<<"Circunferencia "<<contador<<": "<<endl;
			cout<<circ.ToString()<<endl;
			
			cout<<endl;
			cout<<"................................"<<endl;
			cout<<endl;
			
			circ.Aumenta(SALTO_RADIO);
			contador++;
		}	
	}
	else
	{
		cout<<"No hay ninguna posible circunferencia inscrita"<<endl;
	}
	
	
	return 0;
}
