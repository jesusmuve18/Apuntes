/****************************************************************************/
//	FUNDAMENTOS DE PROGRAMACI�N			RELACI�N_V				EJERCICIO_6
/****************************************************************************/
/*
	Jes�s Mu�oz Velasco 					Grupo:A2
	
	Enunciado:
	
	Para modelar un rect�ngulo se usar� la clase Rectangulo. Un 
	rect�ngulo se caracterizar� por la coordenada superior izquierda y la 
	coordenada inferior derecha (ambos son datos struct de tipo Punto2D).
	
	Para modelar una circunferencia se usar� la clase Circunferencia. Una 
	circunferencia se caracterizar� por la coordenada del centro (un dato 
	struct de tipo Punto2D) y el radio.
	
	Escribir un programa que lea las coordenadas que definen un rect�ngulo 
	y calcule la circunferencia centrada en el punto de corte de las diagonales 
	del rect�ngulo tal que su superficie sea la menor entre todas las 
	circunferencias de �rea mayor que la del rect�ngulo.
	
	Para el c�lculo, considere comenzar con radio=0.5 e ir incrementando su 
	valor 0.25 en cada iteraci�n.
	
	Entradas: Puntos extremos de la diagonal de un rect�ngulo
	
	Salidas: Coordenada del centro y radio cuyo �rea sea la siguiente mayor
			 al �rea del rect�ngulo dado con saltos de 0.25 entre cada 
			 valor del radio.
	
*/
/****************************************************************************/
#include<iostream>
#include<cmath>
using namespace std;

#define DATOS_EXTRA
/****************************************************************************/
//Declaraci�n de constantes globales

const double RADIO_INICIAL=0.5;
const double SALTO_RADIO=0.25;
const double PI=3.14159265359;

/****************************************************************************/
//Declaraci�n de tipos de datos (struct)

struct Punto2D 
{
	double x; //abscisas
	double y; //ordenadas
};

/****************************************************************************/
//Declaraci�n de Clases/Objetos (struct)

class Rectangulo
{
	private:
		
		Punto2D punto_1; //coordenadas de uno de los v�rtices del rect�ngulo
		Punto2D punto_2; //coordenadas del punto opuesto con respecto a la 
					     //diagonal del punto_1
					     
	public:
		
		//Constructor sin par�metros
		//PRE: punto1.x, punto1.y, punto2.x, punto2.y >=0
		Rectangulo(){}; 
		
		//Constructor con par�metros
		//PRE: punto1.x, punto1.y, punto2.x, punto2.y >=0
		Rectangulo(Punto2D punto1, Punto2D punto2):
			punto_1(punto1),
			punto_2(punto2) {};
			
		
		//C�lculo del centro del rect�ngulo (cruce de diagonales)															
		Punto2D Centro()
		{
			Punto2D centro; //Dato que devolver� la funci�n
			
			double base=abs(punto_1.x-punto_2.x);
			double altura=abs(punto_1.y-punto_2.y);
			
			centro.x=min(punto_1.y,punto_2.y)+(base/2);
			centro.y=min(punto_1.x,punto_2.x)+(altura/2);
			
			return centro;
		}

													
		//C�lculo del �rea del rect�ngulo													
		double Area()
		{
			double base=abs(punto_1.x-punto_2.x);
			double altura=abs(punto_1.y-punto_2.y);
			
			return base*altura;
		}
		
		string ToString()
		{
			string str;
			
			str="Punto 1: ("+to_string(punto_1.x)+" , "+to_string(punto_1.y)
				+")\nPunto 2: ("+to_string(punto_2.x)+" , "
				+to_string(punto_2.y)+")";
				
			return str;
		}
};

class Circunferencia
{
	private:
		
		Punto2D centro; //coordenadas del centro de la circunferencia
		double radio;
		
	public:
		
		//Constructor con 1 par�metro
		Circunferencia(Punto2D centro):centro(centro), radio(RADIO_INICIAL){};
		
		//Constructor con 2 par�metros
		Circunferencia(Punto2D centro, double radio):
			centro(centro), 
			radio(radio) {};
		
		//C�lculo del �rea
		double Area()
		{
			return (PI*radio*radio);
		}
		
		//Incremento del radio
		void Aumenta(double incremento)
		{
			radio+=incremento;
		}
		
		string ToString()
		{
			string str;
			str="\tCentro: ("+to_string(centro.x)+" , "+to_string(centro.x)+
				")\n\tRadio: "+to_string(radio)+" unidades";
			return str;
		}
	
};

/****************************************************************************/
/*****************************************************************************
  	Funci�n: Lee real dependiendo de las condiciones que este debe tener
  			 para ser considerado v�lido
	Par�metros: T�tulo o etiqueta a modo de petici�n
	Devuelve: El entero en formato double
............................................................................*/
double LeeReal(string titulo)
{
	//#define MOSTRAR_ERROR
	
	string lectura;
	string caracteres_inicio="+-1234567890.";
	string caracteres_resto="1234567890.";
	string caracteres_una_vez=".";
	
	bool todo_ok;


	do
	{
		do
		{
			cout<<titulo;
			getline(cin,lectura);
			
			string aux;
			
			for(int i=0; i<lectura.length(); i++) //Le quito los espacios
			{
				if(lectura.at(i)!=' ')
				{
					aux+=lectura.at(i);
				}
			}
			
			lectura=aux;	
			
		} while(lectura.empty()); //Mientras no haya caracteres
	
		
		todo_ok=true;
		
		bool caracter_correcto;
		int siguiente_caracter=0;
		
		if(lectura.length()>1) //Si hay mas de un caracter
		{
			//Compruebo el primer caracter

			for(int i=0; i<caracteres_inicio.length(); i++)
			{
				if(lectura.at(0)==caracteres_inicio.at(i))
				{
					caracter_correcto=true;
				}
			}
			
			if(!caracter_correcto)
			{
				todo_ok=false;
				
				#ifdef MOSTRAR_ERROR
					
				cout<<"Caracter inicio incorrecto"<<endl;
				
				#endif
			}	
			
			siguiente_caracter=1;
		}
		
		
		//Compruebo el resto de caracteres

		
		for(int i=siguiente_caracter; i<lectura.length(); i++)
		{
			caracter_correcto=false;
			
			for(int j=0; j<caracteres_resto.length(); j++)
			{
				if(lectura.at(i)==caracteres_resto.at(j))
				{
					caracter_correcto=true;
				}
			}
			
			if(!caracter_correcto)
			{
				todo_ok=false;
				
				#ifdef MOSTRAR_ERROR
				
				cout<<"Caracter "<<i+1<<" incorrecto"<<endl;
				
				#endif
			}
			
		}	
		
		//Compruebo si hay caracteres repetidos que no deber�an
		
		int contador=0;
		
		for(int j=0; j<caracteres_una_vez.length(); j++)
		{
			contador=0;
			
			for(int i=0; i<lectura.length(); i++)
			{
				if(lectura.at(i)==caracteres_resto.at(j))
				{
					contador++;
				}
			}
			
			if(contador>1)
			{
				todo_ok=false;
				
				#ifdef MOSTRAR_ERROR
				
				cout<<"Caracter "<<caracteres_una_vez.at(j)<<" repetido"<<endl;
				
				#endif
			}
			
		}	
		
		#ifdef MOSTRAR_ERROR
				
		cout<<endl;
		
		#endif
		
	} while(!todo_ok);
	
	return stod(lectura);
}
														
/****************************************************************************/
/****************************************************************************/
int main()
{
	//Declaraci�n de Datos
	
	Punto2D punto1, punto2;
	bool todo_ok;
	
	//Entradas
	
	cout<<"Puntos que definen un rectangulo "
		<<"(puntos de extremos de una diagonal):"<<endl;
	
	
	cout<<"     Punto 1: "<<endl;
	punto1.x=LeeReal ("\tCoordenada X: ");
	punto1.y=LeeReal ("\tCoordenada Y: ");
	
	cout<<"    Punto 2: "<<endl;
	punto2.x=LeeReal ("\tCoordenada X: ");
	punto2.y=LeeReal ("\tCoordenada Y: ");
	
	cout<<"--------------------------------"<<endl;
	cout<<endl;
	
	Rectangulo rect(punto1,punto2);
	Circunferencia circ(rect.Centro());
		
	//C�lculos
	
	
	while(circ.Area()<rect.Area())
	{
		circ.Aumenta(SALTO_RADIO);
	}
	
	//Salidas
	
	cout<<"La circunferencia buscada tiene las siguientes caracteristicas:"
		<<endl;
	
	cout<<circ.ToString()<<endl;
	
	#ifdef DATOS_EXTRA
	
	cout<<"\tArea: "<<circ.Area()<<" unidades al cuadrado"<<endl;
	cout<<endl;
	cout<<"(El rectangulo definido tiene un area de "<<rect.Area()
		<<" unidades al cuadrado)"<<endl;
	
	#endif
	
	return 0;
}
