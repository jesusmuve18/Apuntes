/****************************************************************************/
//	FUNDAMENTOS DE PROGRAMACI�N			RELACI�N_IV				EJERCICIO_55
/****************************************************************************/
/*
	Jes�s Mu�oz Velasco 					Grupo:A2

	Enunciado:
	
	Se va a dotar de mayor funcionalidad al robot desarrollado en el ejercicio 
	37 de esta misma Relaci�n de Problemas para que se mueva en un tablero de 
	10 filas y 10 columnas.
	
	Inicialmente, el robot se ubica en la posici�n pos, siendo pos una pareja 
	de enteros positivos (f, c) donde 1 = f = 10 y 1 = c = 10. Luego, el robot 
	ejecuta una serie de �rdenes, indicadas mediante un array ord de tipo 
	char, con longitud lon. Cada orden es una letra 'I', 'D', 'A' o 'B' 
	indicando si el robot se mueve a la izquierda, derecha, arriba o abajo. 
	Las posiciones v�lidas del robot cumplen que para cada posici�n pos sus 
	coordenadas (f, c) son correctas. Se dice que una serie de �rdenes es 
	correcta si el robot nunca se sale de las posiciones v�lidas.
	
	Se pide implementar un programa que lea la posici�n inicial pos (fila y 
	columna, por separado) y la secuencia de �rdenes a ejecutar. Le 
	recomendamos que use un dato string, p.e. cad_ordenes para la lectura. 
	Si el string es correcto, el array ord se rellenar� a partir de 
	cad_ordenes, siendo lon la longitud de cad_ordenes.
	
	Despu�s de la lectura de los datos haga lo siguiente:
	
	� Si la serie de �rdenes es correcta, muestre cu�ntas veces se visit� cada 
		posici�n.Use una representaci�n bidimensional (figura 30).
	� Si la serie de �rdenes NO es correcta, el programa terminar� indicando 
		cu�ntas �rdenes se pudieron ejecutar.
		
	En la figura 30 mostramos el resultado de ejecutar el programa empezando 
	por la posici�n (5, 5) y con la secuencia de �rdenes IIAAAADDBDDDBB

	
	Entradas: Coordenadas iniciales (fila y columna)
			  Serie de �rdenes entre las establecidas
			  Numero de �rdenes a ejecutar
	
	Salidas: N�mero de �rdenes que se pudieron ejecutar
			 Matriz de posiciones del robot
	
*/
/****************************************************************************/
#include<iostream>
#include<iomanip>
using namespace std;
/****************************************************************************/
//Declaraci�n de constantes globales

const int X_MIN=1;
const int X_MAX=10;

const int Y_MIN=1;
const int Y_MAX=10;

const char RELLENO='.';

/****************************************************************************/
//Declaraci�n de tipos de datos

struct Posicion
{
	int x;
	int y;
};

/*****************************************************************************
  	Funci�n: Lee entero dependiendo de las condiciones que este debe tener
  			 para ser considerado v�lido
	Par�metros: T�tulo o etiqueta a modo de petici�n
	Devuelve: El entero en formato int		
............................................................................*/
double LeeEntero(string titulo)
{
	//#define MOSTRAR_ERROR
	
	string lectura;
	string caracteres_inicio="+-1234567890";
	string caracteres_resto="1234567890";
	
	bool todo_ok;


	do
	{
		do
		{
			cout<<titulo;
			getline(cin,lectura);
			
			string aux;
			
			for(int i=0; i<lectura.length(); i++) //Le quito los espacios
			{
				if(lectura.at(i)!=' ')
				{
					aux+=lectura.at(i);
				}
			}
			
			lectura=aux;	
			
		} while(lectura.empty()); //Mientras no haya caracteres
	
		
		todo_ok=true;
		
		bool caracter_correcto;
		int siguiente_caracter=0;
		
		if(lectura.length()>1) //Si hay mas de un caracter
		{
			//Compruebo el primer caracter

			for(int i=0; i<caracteres_inicio.length(); i++)
			{
				if(lectura.at(0)==caracteres_inicio.at(i))
				{
					caracter_correcto=true;
				}
			}
			
			if(!caracter_correcto)
			{
				todo_ok=false;
				
				#ifdef MOSTRAR_ERROR
					
				cout<<"Caracter inicio incorrecto"<<endl;
				
				#endif
			}	
			
			siguiente_caracter=1;
		}
		
		
		//Compruebo el resto de caracteres

		
		for(int i=siguiente_caracter; i<lectura.length(); i++)
		{
			caracter_correcto=false;
			
			for(int j=0; j<caracteres_resto.length(); j++)
			{
				if(lectura.at(i)==caracteres_resto.at(j))
				{
					caracter_correcto=true;
				}
			}
			
			if(!caracter_correcto)
			{
				todo_ok=false;
				
				#ifdef MOSTRAR_ERROR
				
				cout<<"Caracter "<<i+1<<" incorrecto"<<endl;
				
				#endif
			}
			
		}	
		
		#ifdef MOSTRAR_ERROR
				
		cout<<endl;
		
		#endif
		
	} while(!todo_ok);
	
	return stoi(lectura);
}


/*****************************************************************************
  	Funci�n: Comprueba si la string �rdenes contiene instrucciones correctas
	Par�metros: string ordenes
	Devuelve: validez o no de las ordenes en formato booleano
............................................................................*/
bool OrdenesOk(string ordenes)
{
	bool ordenes_ok=true; //Dato que devolver� la funci�n
	string ordenes_permitidas="DIAB";
	bool aux;
	
	for(int i=0; i<ordenes.length(); i++)
	{
		aux=false;
		
		for(int j=0; j<ordenes_permitidas.length(); j++)
		{

			if(toupper(ordenes.at(i))==ordenes_permitidas.at(j))
			{
				aux=true;
			}
			
		}

		if(!aux && ordenes_ok)
		{
			ordenes_ok=false;
		}
	}
	
	return ordenes_ok;
}

/*****************************************************************************
  	Funci�n: Traduce la orden en una coordenada a sumar a la anterior
	Par�metros: caracter orden
	Devuelve: dupla x,y segun la orden puede ser (0,1),(0,-1),(-1,0),(1,0)
............................................................................*/
Posicion Valor(char a)
{
	char b=toupper(a);
	Posicion valor;
	
	valor.x=0;
	valor.y=0;
	
	switch(b)
	{
		case 'D':
			valor.x= 1;
			break;
			
		case 'I':
			valor.x= -1;
			break;
			
		case 'A':
			valor.y= 1;
			break;
			
		case 'B':
			valor.y= -1;
			break;
	}
	
	return valor;
}
/****************************************************************************/
/****************************************************************************/
int main()
{
	//Declaraci�n de Datos
	
	Posicion posicion;
	int longitud;
	string ordenes;
	
	char recorrido[X_MAX-X_MIN+1][Y_MAX-Y_MIN+1]; //recorrido[x][y]
	string serie;

	//Entradas

	do
	{
		cout<<"Posicion inicial: "<<endl;
		posicion.y=LeeEntero("\tFila: ");
		posicion.x=LeeEntero("\tColumna: ");
		
	} while((posicion.x<X_MIN || posicion.x>X_MAX) ||
		   (posicion.y<Y_MIN || posicion.y>Y_MAX));
	
	do
	{
		cout<<"Ordenes: ";
		cin>>ordenes;
		
	} while (!OrdenesOk(ordenes));
	
	cin.ignore(); //vac�o el buffer para evitar errores
	
	do
	{
		longitud=LeeEntero("Numero de ordenes: "); 
		
	} while (longitud<=0 || longitud>ordenes.length());

	//C�lculos
	
	for(int x=0; x<X_MAX-X_MIN+1 ; x++) //Relleno la matriz del recorrido
	{
		for(int y=0; y<X_MAX-X_MIN+1 ; y++)
		{
			recorrido[x][y]=RELLENO;
		}
	}
	
	
	
	Posicion aux=posicion;
	int contador=0;
	
	recorrido[posicion.x-1][posicion.y-1]='1'; //a�ado la posici�n inicial
	
	while((aux.x>=X_MIN && aux.x<=X_MAX)&&(aux.y>=Y_MIN && aux.y<=Y_MAX)
										&&(contador<longitud))
	{
		/*Interpreto cada una de las �rdenes hasta ejecutar el n�mero dado
		  en el n�mero de �rdenes o hasta salirme de la matriz gr�fica */
		  
		aux.x+=Valor(ordenes.at(contador)).x;
		aux.y+=Valor(ordenes.at(contador)).y;
		
		if(recorrido[aux.x-1][aux.y-1]==RELLENO)
		{
			recorrido[aux.x-1][aux.y-1]='1';
		}
		else
		{
			recorrido[aux.x-1][aux.y-1]+=1;
		}
		
		contador++;
		
	}
	
	if(contador==longitud)
	{
		serie="correcta";
	}
	else //si no se han ejecutado todas las �rdenes
	{
		serie="incorrecta";
	}
	
	//Salidas
	
	cout<<endl;
	cout<<"------------------------"<<endl;
	cout<<endl;
	
	cout<<"La Serie de ordenes es: "<<serie<<endl;
	cout<<"Se ejecutaron "<<contador<<" ordenes"<<endl;
	
	cout<<endl;
	
	//Muestro los �ndices superiores y el separador
	
	cout<<"   : ";
	
	for(int i=1; i<=X_MAX-X_MIN+1; i++)
	{
		cout<<setw(2)<<i<<" ";
	}
	cout<<endl;
	
	
	cout<<"   -";
	
	for(int i=0; i<X_MAX-X_MIN+1; i++)
	{
		cout<<"---";
	}
	cout<<"--"<<endl;
	
	
	for(int y=0; y<Y_MAX-Y_MIN+1 ; y++) //Muestro la matriz del recorrido
	{
		cout<<setw(2)<<Y_MAX-Y_MIN+1-y<<" : ";
		
		for(int x=0; x<X_MAX-X_MIN+1 ; x++)
		{
			cout<<recorrido[x][Y_MAX-Y_MIN-y]<<"  ";
		}
		
		cout<<": "<<setw(2)<<Y_MAX-Y_MIN+1-y<<endl;
	}
	
	//Muestro el separador y los �ndices inferiores
	
	cout<<"   -";
	
	for(int i=0; i<X_MAX-X_MIN+1; i++)
	{
		cout<<"---";
	}
	cout<<"--"<<endl;
	
	cout<<"   : ";
	
	for(int i=1; i<=X_MAX-X_MIN+1; i++)
	{
		cout<<setw(2)<<i<<" ";
	}
	cout<<endl;
	
	return 0;
}

