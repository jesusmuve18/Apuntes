/****************************************************************************/
//	FUNDAMENTOS DE PROGRAMACI�N			RELACI�N_II				EJERCICIO_21
/****************************************************************************/
/*
	Jes�s Mu�oz Velasco 					Grupo:A2
	
	Explicaci�n del programa:
	Lee un caracter introducido por teclado y el programa lo clasifica en
	los grupos: May�scula, Min�scula, D�gito y Otro. Adem�s hace las 
	siguientes transformaciones:
	- En caso de may�scula lo pasa a min�scula
	- En caso de min�scula lo pasa a may�scula
	- En cualquier otro caso lo deja igual
	
	
	Entradas: Caracter
	
	Salidas: Tipo de caracter y su transformaci�n si corresponde
	
*/
/****************************************************************************/
#include<iostream>
using namespace std;
/****************************************************************************/
int main()
{
	
	//Declaraci�n de datos
	
	char letra_original, letra_convertida;
	enum class TipoLetra{Mayuscula, Minuscula, Digito, Otro};
	TipoLetra tipo;
	
	//Entradas
	
	cout<<"Caracter: ";
	cin>>letra_original;
	
	//C�lculos
	
	tipo=TipoLetra::Otro; 	//Inicializo el tipo como "Otro" para despu�s 
							//compararlo y a�adirlo a un tipo diferente si
							//corresponde
	
	if('A'<=letra_original && letra_original<='Z')
		tipo=TipoLetra::Mayuscula;
		
	if('a'<=letra_original && letra_original<='z')
		tipo=TipoLetra::Minuscula;
		
	if('0'<=letra_original && letra_original<='9')
		tipo=TipoLetra::Digito;
	
	switch (tipo)	
	{
		case (TipoLetra::Mayuscula):
			letra_convertida=tolower(letra_original);
			break;
		
		case (TipoLetra::Minuscula):
			letra_convertida=toupper(letra_original);
			break;
			
		default:
			letra_convertida=letra_original;
			break;
	}
	
	//Salidas
	
	cout<<endl;
	
	switch (tipo)	
	{
		case (TipoLetra::Mayuscula):
			cout<<"La letra era una mayuscula. Una vez convertida es "
				<<letra_convertida;
			break;
		
		case (TipoLetra::Minuscula):
			cout<<"La letra era una minuscula. Una vez convertida es "
				<<letra_convertida;
			break;
			
		case (TipoLetra::Digito):
			cout<<"El caracter es un digito: "<<letra_convertida;
			break;
			
		case (TipoLetra::Otro):
			cout<<"El caracter no es una letra ni un digito validos: "
				<<letra_convertida;
			break;
	}
	
	
	return 0;
}
