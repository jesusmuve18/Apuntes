/****************************************************************************/
//	FUNDAMENTOS DE PROGRAMACI�N			RELACI�N_II				EJERCICIO_9
/****************************************************************************/
/*
	Jes�s Mu�oz Velasco 					Grupo:A2

	Explicaci�n del programa:
	
	Lee un entero representando la clave y un car�cter en may�cula. El 
	programa codificar� el car�cter seg�n la clave introducida y lo mostrar� 
	por pantalla. (Funciona para todos los caracteres a excepci�n de la '�')
	
	Entradas:  Clave y caracter a codificar
	
	Salidas:	Caracter codificado
	
*/
/****************************************************************************/
#include<iostream>
using namespace std;
/****************************************************************************/
int main()
{
	//Declaraci�n de datos

	const int INTERVALO=('Z'-'A'+1);//le sumo 1 ya que es un intervalo cerrado
		
	int clave;
	char c_inicial,c_cod;  //Caracter a codificar y codificado respectivamente
	
	
	//Entradas
	
	cout<<"Clave: ";
	cin>>clave;
	cout<<"Caracter a codificar: ";
	cin>>c_inicial;
	
	//C�lculos
	
	if('A'<=c_inicial && c_inicial<='Z') //Compruebo q el caracter sea v�lido
	{
		c_cod=c_inicial+clave;
		
		if (c_cod<'A' || 'Z'<c_cod)   //Si el caracter codificado no pertenece 
		{							  //al intervalo
			c_cod=c_cod-(INTERVALO*((int)(clave/INTERVALO)));
		}
	}
	
	/* El caracter codificado ser� el caracter inicial desplazado menos 
	tantas veces el valor del intervalo como est� la clave en el intervalo
	
	Explicaci�n m�s detallada:
	Supongamos que el intervalo es un numero cualquiera i:
	El caracter ya desplazado n posiciones lo denominar� x.
	Si x est� en el intervalo ser� directamente la soluci�n.
	De lo contrario le restar� i tantas veces como la clave contenga al 
	intervalo (n/i) (el entero de esta operaci�n). 
	*/
	
		
	//Salidas
	
	if('A'<=c_inicial && c_inicial<='Z')
	{
		cout<<"Caracter codificado: "<<c_cod;	
	}
	else
		cout<<"El caracter introducido no es valido.";
	
	
	return 0;
}
