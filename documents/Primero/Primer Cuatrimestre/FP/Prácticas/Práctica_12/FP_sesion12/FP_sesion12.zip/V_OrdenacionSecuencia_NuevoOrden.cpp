/****************************************************************************/
//	FUNDAMENTOS DE PROGRAMACI�N			RELACI�N_V				EJERCICIO_48
/****************************************************************************/
/*
	Jes�s Mu�oz Velasco 					Grupo:A2

	Enunciado:

	En el ejercicio 33 de la Relaci�n de Problemas IV definimos un nuevo 
	criterio de orden entre dos n�meros enteros positivos: Un valor entero a 
	ser� mayor que otro b si el n�mero de d�gitos nueve es mayor en a que en
	b. Si el n�mero de nueves es igual en los dos, el mayor ser� el que tiene 
	m�s ochos.
	
	Si hay empate tambi�n con este d�gito, se considera el siete. As� hasta 
	llegar al cero, si fuese necesario. Si la frecuencia de todos los d�gitos 
	es igual en ambos valores, se les considera iguales.
	
	A�ada cuatro nuevos m�todos a la clase SecuenciaEnteros:
	
		void OrdenaSeleccion_NuevoOrden()
		void OrdenaInsercion_NuevoOrden()
		void OrdenaIntercambio_NuevoOrden()
		void OrdenaIntercambioMejorado_NuevoOrden()
		
	Bastar� una ligera modificaci�n en los m�todos implementados en el 
	ejercicio 47).
	
	Escriba un programa que pida el n�mero de elementos de la secuencia 
	(cu�ntas casillas se van a ocupar), rellene esa secuencia con n�meros 
	aleatorios entre 0 y 999, la ordene con los m�todos implementados y 
	muestre el resultado.


	Entradas: casillas a ocupar

	Salidas: numeros aleatorios generados ordenados

*/
/****************************************************************************/
#include<iostream>
#include<cmath>

#include <random>  // para la generaci�n de n�meros pseudoaleatorios
#include <chrono>  // para la semilla

using namespace std;
/****************************************************************************/
//Declaraci�n de constantes globales

/****************************************************************************/
//Declaraci�n de tipos de datos

/****************************************************************************/
//Declaraci�n de Clases/Objetos
class SecuenciaEnteros 
{

private:

    static const int TAMANIO = 50; // N�m.casillas disponibles
    int vector_privado[TAMANIO];

    // PRE: 0<=total_utilizados<TAMANIO

    int total_utilizados; // N�m.casillas ocupadas

public:

    /***********************************************************************/
    // Constructor sin argumentos

    SecuenciaEnteros (void) : total_utilizados (0)
    {}
    
    //Constructor con argumentos 
    
    SecuenciaEnteros(string cadena)
    {
    	total_utilizados=cadena.length();
    	
    	for(int i=0; i<total_utilizados ; i++)
    	{
    		vector_privado[i]=cadena.at(i);
		}
	}
	
	//Constructor con argumentos
	
	SecuenciaEnteros(int entero)
	{
		int aux;
		int cifras=0;
			
		aux=entero;
		
		while(aux>0) //Cuento el n�mero de cifras que tiene el n�mero
		{
			cifras++;
			aux/=10;
		}
		
		total_utilizados=cifras;
		
		aux=entero;
		
		for(int i=0; i<cifras; i++) //Introduzco cada cifra en su posici�n
		{
			vector_privado[i]=(aux/(pow(10,cifras-1-i)));
			aux-=vector_privado[i]*pow(10,cifras-1-i);
		}
	}
	
	/***********************************************************************/
	//Actualiza la secuencia con un numero dado separandolo en cifras
	
	void SetSecuencia(int entero)
	{
		int aux;
		int cifras=0;
			
		aux=entero;
		
		while(aux>0) //Cuento el n�mero de cifras que tiene el n�mero
		{
			cifras++;
			aux/=10;
		}
		
		total_utilizados=cifras;
		
		aux=entero;
		
		for(int i=0; i<cifras; i++) //Introduzco cada cifra en su posici�n
		{
			vector_privado[i]=(aux/(pow(10,cifras-1-i)));
			aux-=vector_privado[i]*pow(10,cifras-1-i);
		}
	}
	
    /***********************************************************************/
    // Devuelve el n�mero de casillas ocupadas

    int TotalUtilizados (void)
    {
        return (total_utilizados);
    }

    /***********************************************************************/
    // Devuelve el n�mero de casillas disponibles

    int Capacidad (void)
    {
        return (TAMANIO);
    }

    /***********************************************************************/
    // "Vac�a" completamente la secuencia

	void EliminaTodos()
	{
		total_utilizados = 0;
	}

    /***********************************************************************/
    // A�ade un elemento ("nuevo") al vector.
    // PRE: total_utilizados < TAMANIO
    // 		La adici�n se realiza si hay alguna casilla disponible.
    // 		El nuevo elemento se coloca al final del vector.
    // 		Si no hay espacio, no se hace nada.

    void Aniade (int nuevo)
    {
        if (total_utilizados < TAMANIO){
            vector_privado[total_utilizados] = nuevo;
            total_utilizados++;
        }
    }

    /***********************************************************************/
    // Devuelve el elemento de la casilla "indice"
    // PRE: 0 <= indice < total_utilizados

    int Elemento (int indice)
    {
        return (vector_privado[indice]);
    }

    /***********************************************************************/
    // Cambia el contenido de la casilla "indice" por el valor "nuevo"
    // PRE: 0 <= indice < total_utilizados

   void Modifica (int indice, int nuevo)
   {
		if ((indice >= 0) && (indice < total_utilizados))
			vector_privado[indice] = nuevo;
   }


    /***********************************************************************/
    // Eliminar el car�cter de la posici�n dada por "indice".
    // Realiza un borrado f�sico (desplazamiento y sustituci�n).
    // PRE: 0 <= indice < total_utilizados

    void Elimina (int indice)
    {
        if ((indice >= 0) && (indice < total_utilizados)) {

            int tope = total_utilizados-1; // posic. del �ltimo

            for (int i = indice ; i < tope ; i++)
                vector_privado[i] = vector_privado[i+1];

            total_utilizados--;
        }
    }
 

    /***********************************************************************/
    // Inserta el car�cter "nuevo" en la posici�n dada por "indice".
    // Desplaza todos los caracteres una posici�n a la derecha antes de 
	// copiar en "indice" en valor "nuevo".
	// PRE: 0 <= indice < total_utilizados
    // PRE: total_utilizados < TAMANIO
    // 		La inseerci�n se realiza si hay alguna casilla disponible.
    // 		Si no hay espacio, no se hace nada.
    
	void Inserta (int indice, int valor_nuevo)
	{
        if ((indice >= 0) && (indice < total_utilizados) 
		    && (total_utilizados < TAMANIO)) {
		
			for (int i = total_utilizados ; i > indice ; i--)
				vector_privado[i] = vector_privado[i-1];
			
			vector_privado[indice] = valor_nuevo;
			total_utilizados++;		
		}
	}
   
    /***********************************************************************/
    // Compone un string con todos los caracteres que est�n
    // almacenados en la secuencia y lo devuelve.
    //Tiene el separador por defecto
    
    string ToString()
    {
        string cadena;

        for (int i=0; i<total_utilizados; i++)
        {
        	cadena += to_string(vector_privado[i]);
        	
        	if(i<total_utilizados-1)
        	{
        		cadena+=" , ";
			}
		}
            

        return (cadena);
    }
    
    /***********************************************************************/
    // Compone un string con todos los caracteres que est�n
    // almacenados en la secuencia y lo devuelve.
    //El separador es introducido como par�metro
    
    string ToString(string separador)
    {
        string cadena;

        for (int i=0; i<total_utilizados; i++)
        {
        	cadena += to_string(vector_privado[i]);
        	
        	if(i<total_utilizados-1)
        	{
        		cadena+=separador;
			}
		}
            

        return (cadena);
    }
	
	/***********************************************************************/
	//Elimina el n�mero dado todas las veces que aparece en la secuencia
	
	void EliminaOcurrencias (int a_borrar)
	{
		int posicion=0;
		while(posicion<total_utilizados)
		{
			if(vector_privado[posicion]==a_borrar)
			{
				Elimina(posicion);
			}
			else
			{
				posicion++;
			}
		}
	}
	
	
	/***********************************************************************/
	//M�todo de ordenaci�n por Selecci�n o Selection Sort
	
	void OrdenaSeleccion()
	{
		for (int izda = 0 ; izda < total_utilizados ; izda++) 
		{
			// Calcular el m�nimo entre "izda" y "total_utilizados"-1
			int minimo = vector_privado[izda]; // Valor del m�nimo
			
			int pos_min = izda; // Posici�n del m�nimo
			
			for (int i = izda + 1; i < total_utilizados ; i++)
			{
				if (vector_privado[i] < minimo) // Nuevo m�nimo
				{
					minimo = vector_privado[i];
					pos_min = i;
				}
				
			}
			
			// Intercambiar los valores guardados en "izda" y "pos_min"
			int intercambia = vector_privado[izda];
			vector_privado[izda] = vector_privado[pos_min];
			vector_privado[pos_min] = intercambia;	
			
		}

	}
	
	/***********************************************************************/
	//M�todo de ordenaci�n por Inserci�n o Insertion Sort
	
	void OrdenaInsercion()
	{
		for (int izda=1; izda<total_utilizados; izda++)
		{
			// "a_insertar" es el valor que se va a insertar en
			// subvector izquierdo. Este subvector est� ordenado y
			// comprende las posiciones entre 0 e "izda"-1
			
			int a_insertar=vector_privado[izda];
			
			// Se busca la posici�n en la zona ordenada y al mismo tiempo
			// se van desplazando hacia la derecha los valores mayores
			
			int i=izda;
			
			while ((i>0) && (a_insertar<vector_privado[i-1])) 
			{
				
				// Desplazar a la derecha los valores mayores que "a_insertar"
				vector_privado[i] = vector_privado[i-1]; 
				i--;
			}
			
			vector_privado[i]=a_insertar; // Copiar -insertar- en el "hueco"
		}

	}
	
	/***********************************************************************/
	//M�todo de ordenaci�n por Intercambio Directo o Burbuja (Bubble Sort)
	//Primera Aproximaci�n: 
	
	void OrdenaIntercambio()
	{
		for (int izquierda = 0; izquierda<total_utilizados; izquierda++) 
		{
			for (int i = total_utilizados-1 ; i > izquierda ; i--)
			{
				if (vector_privado[i] < vector_privado[i-1]) // Intercambiar
				{	
					int intercambia = vector_privado[i];
					vector_privado[i] = vector_privado[i-1];
					vector_privado[i-1] = intercambia;
				}
			}		
		}	
	}
	
	/***********************************************************************/
	//M�todo de ordenaci�n por Intercambio Directo o Burbuja (Bubble Sort)
	//Segunda Aproximaci�n: 
	
	void OrdenaIntercambioMejorado()
	{
		bool cambio=true; // Para obligar a entrar al ciclo
		
		for (int izda=0; izda<total_utilizados && cambio;izda++)
		{
			// En cada pasada iniciamos "cambio" a false.
			// Se pondr� a true si y solo si hay alg�n intercambio
			
			cambio=false;
			
			for(int i=total_utilizados-1; i>izda ;i--)
			{
				if(vector_privado[i]<vector_privado[i-1])	// Intercambiar
				{ 
					int intercambia=vector_privado[i];
					vector_privado[i]=vector_privado[i-1];
					vector_privado[i-1]=intercambia;
					
					// Se ha hecho un intercambio.
					// Se obliga a una nueva iteraci�n del ciclo externo.
					
					cambio=true;
				}	
			}
		}	
	}
	
	/***********************************************************************/
	//M�todo de comparaci�n entre 2 enteros que devuelve el mayor de los 2
	
	int NuevoOrden_Mayor (int a, int b)
	{
		const char NUM_INICIO='9';
		
		string num1=to_string(a);
		string num2=to_string(b);
		
		int mayor;
		
		bool acabar=false;
		char num_a_contar=NUM_INICIO;
		
		int contador1=0;
		int contador2=0;
		
		while(!acabar)
		{
			//Reseteo los contadores para cada numero a contar
			contador1=0;
			contador2=0;
			
			for(int i=0; i<num1.length(); i++) //Cuento las apariciones en num1
			{
				if(num1.at(i)==num_a_contar)
				{
					contador1++;
				}
			}
			
			for(int i=0; i<num2.length(); i++) //Cuento las apariciones en num2
			{
				if(num2.at(i)==num_a_contar)
				{
					contador2++;
				}
			}
			
			if(contador1>contador2)//El mayor ser� el que tenga m�s apariciones
			{
				mayor=stoi(num1);
				acabar=true;
			}
			else
			{
				if(contador1<contador2)
				{
					mayor=stoi(num2);
					acabar=true;
				}
				else
				{
					if(num_a_contar>0)
					{
						num_a_contar--;
					}
					else
					{
						mayor=stoi(num1);
						acabar=true;
					}
				}
			}
		}
		return mayor;
	}
	
	/***********************************************************************/
	//M�todo de ordenaci�n por Selecci�n o Selection Sort
	
	void OrdenaSeleccion_NuevoOrden()
	{
		for (int izda = 0 ; izda < total_utilizados ; izda++) 
		{
			// Calcular el m�nimo entre "izda" y "total_utilizados"-1
			int minimo = vector_privado[izda]; // Valor del m�nimo
			
			int pos_min = izda; // Posici�n del m�nimo
			
			for (int i = izda + 1; i < total_utilizados ; i++)
			{
				if (NuevoOrden_Mayor(vector_privado[i], minimo)==minimo) 
				{											// Nuevo m�nimo
					minimo = vector_privado[i];
					pos_min = i;
				}
				
			}
			
			// Intercambiar los valores guardados en "izda" y "pos_min"
			int intercambia = vector_privado[izda];
			vector_privado[izda] = vector_privado[pos_min];
			vector_privado[pos_min] = intercambia;	
			
		}

	}
	
	/***********************************************************************/
	//M�todo de ordenaci�n por Inserci�n o Insertion Sort
	
	void OrdenaInsercion_NuevoOrden()
	{
		for (int izda=1; izda<total_utilizados; izda++)
		{
			// "a_insertar" es el valor que se va a insertar en
			// subvector izquierdo. Este subvector est� ordenado y
			// comprende las posiciones entre 0 e "izda"-1
			
			int a_insertar=vector_privado[izda];
			
			// Se busca la posici�n en la zona ordenada y al mismo tiempo
			// se van desplazando hacia la derecha los valores mayores
			
			int i=izda;
			
			while ((i>0)&&(NuevoOrden_Mayor(vector_privado[i-1],a_insertar)
														==vector_privado[i-1]))
			{
				
				// Desplazar a la derecha los valores mayores que "a_insertar"
				vector_privado[i] = vector_privado[i-1]; 
				i--;
			}
			
			vector_privado[i]=a_insertar; // Copiar -insertar- en el "hueco"
		}

	}
	
	/***********************************************************************/
	//M�todo de ordenaci�n por Intercambio Directo o Burbuja (Bubble Sort)
	//Primera Aproximaci�n: 
	
	void OrdenaIntercambio_NuevoOrden()
	{
		for (int izquierda = 0; izquierda<total_utilizados; izquierda++) 
		{
			for (int i = total_utilizados-1 ; i > izquierda ; i--)
			{
				if (NuevoOrden_Mayor(vector_privado[i], vector_privado[i-1])
					==vector_privado[i-1]) // Intercambiar
				{	
					int intercambia = vector_privado[i];
					vector_privado[i] = vector_privado[i-1];
					vector_privado[i-1] = intercambia;
				}
			}		
		}	
	}
	
	/***********************************************************************/
	//M�todo de ordenaci�n por Intercambio Directo o Burbuja (Bubble Sort)
	//Segunda Aproximaci�n: 
	
	void OrdenaIntercambioMejorado_NuevoOrden()
	{
		bool cambio=true; // Para obligar a entrar al ciclo
		
		for (int izda=0; izda<total_utilizados && cambio;izda++)
		{
			// En cada pasada iniciamos "cambio" a false.
			// Se pondr� a true si y solo si hay alg�n intercambio
			
			cambio=false;
			
			for(int i=total_utilizados-1; i>izda ;i--)
			{
				if(NuevoOrden_Mayor(vector_privado[i], vector_privado[i-1])
					==vector_privado[i-1])	// Intercambiar
				{ 
					int intercambia=vector_privado[i];
					vector_privado[i]=vector_privado[i-1];
					vector_privado[i-1]=intercambia;
					
					// Se ha hecho un intercambio.
					// Se obliga a una nueva iteraci�n del ciclo externo.
					
					cambio=true;
				}	
			}
		}	
	}
	
};

class GeneradorAleatorioEnteros
{  

private:
	
	mt19937 generador_mersenne;    // Mersenne twister
	uniform_int_distribution<int>  distribucion_uniforme;
	
	/************************************************************************/
	//Calcula el instante en nanosegundos
	long long Nanosec()
	{
		return(chrono::high_resolution_clock::now().time_since_epoch().count());
	}
	
	/************************************************************************/ 
	
public:
	
	/************************************************************************/
	//Constructor sin argumentos
	GeneradorAleatorioEnteros() : GeneradorAleatorioEnteros(0, 1) 
	{ }
	
	/************************************************************************/  
	//Constructor con argumentos
	//PRE: min < max
	GeneradorAleatorioEnteros(int min, int max) 
	{
		const int A_DESCARTAR = 70000;
		// ACM TOMS Volume 32 Issue 1, March 2006
		
		auto semilla = Nanosec();
		generador_mersenne.seed(semilla);
		generador_mersenne.discard(A_DESCARTAR);
		distribucion_uniforme = uniform_int_distribution<int> (min, max);
	}
	
	/************************************************************************/
	
	int Siguiente()
	{
	  return (distribucion_uniforme(generador_mersenne));
	}
	
	/************************************************************************/

};

/****************************************************************************/
/****************************************************************************/
int main()
{
	//Declaraci�n de Datos
	
	#define SELECCION
	//#define INSERCION
	//#define INTERCAMBIO
	//#define INTERCAMBIO_MEJORADO
	
	const int MIN=0;
	const int MAX=999;
	
	int numero;
	int casillas;

	//Entradas

	cout<<"Numero de elementos de la secuencia: ";
	cin>>casillas;
	
	SecuenciaEnteros secuencia;
	GeneradorAleatorioEnteros aleatorio(MIN,MAX);
	
	for(int i=0; i<casillas; i++)
	{
		//numero toma valores auxiliares aleatorios para rellenar la secuencia
		
		numero=aleatorio.Siguiente();
		secuencia.Aniade(numero);
	}
	
	//Salidas
	
	cout<<endl;
	cout<<"Secuencia generada: "<<endl;
	cout<<secuencia.ToString()<<endl;
	
	cout<<"..................."<<endl;
	
	#ifdef SELECCION
	secuencia.OrdenaSeleccion_NuevoOrden();
	cout<<"Secuencia ordenada por seleccion: "<<endl;
	cout<<secuencia.ToString()<<endl;
	#endif
	
	#ifdef INSERCION
	secuencia.OrdenaInsercion_NuevoOrden();
	cout<<"Secuencia ordenada por insercion: "<<endl;
	cout<<secuencia.ToString()<<endl;
	#endif
	
	#ifdef INTERCAMBIO
	secuencia.OrdenaIntercambio_NuevoOrden();
	cout<<"Secuencia ordenada por intercambio: "<<endl;
	cout<<secuencia.ToString()<<endl;
	#endif
	
	#ifdef INTERCAMBIO_MEJORADO
	secuencia.OrdenaIntercambioMejorado_NuevoOrden();
	cout<<"Secuencia ordenada por intercambio mejorado: "<<endl;
	cout<<secuencia.ToString()<<endl;
	#endif

	return 0;
}

