/****************************************************************************/
//	FUNDAMENTOS DE PROGRAMACI�N			RELACI�N_V				EJERCICIO_43
/****************************************************************************/
/*
	Jes�s Mu�oz Velasco 					Grupo:A2

	Enunciado:

	A�adir un m�todo EliminaExcesoBlancos() para eliminar el exceso de 
	caracteres en blanco, es decir, que sustituya todas las secuencias de 
	espacios en blanco por un s�lo espacio. Por ejemplo, si el vector original 
	es {' ','a','h',' ',' ',' ','c'}, que contiene una secuencia de tres 
	espacios consecutivos, el vector resultante debe ser {' ','a','h',' ','c'}.

*/
/****************************************************************************/
#include<iostream>
using namespace std;
/****************************************************************************/
//Declaraci�n de constantes globales

/****************************************************************************/
//Declaraci�n de tipos de datos

/****************************************************************************/
//Declaraci�n de Clases/Objetos

class SecuenciaCaracteres {

private:

    static const int TAMANIO = 50; // N�m.casillas disponibles
    char vector_privado[TAMANIO];

    // PRE: 0<=total_utilizados<TAMANIO

    int total_utilizados; // N�m.casillas ocupadas

public:

    /***********************************************************************/
    // Constructor sin argumentos

    SecuenciaCaracteres (void) : total_utilizados (0)
    {}
    
    //Constructor con argumentos 
    
    SecuenciaCaracteres(string cadena)
    {
    	total_utilizados=cadena.length();
    	
    	for(int i=0; i<total_utilizados ; i++)
    	{
    		vector_privado[i]=cadena.at(i);
		}
	}
	
	/***********************************************************************/
	//Actualiza la secuencia con una cadena dada
	SetSecuencia(string cadena)
	{
		total_utilizados=cadena.length();
    	
    	for(int i=0; i<total_utilizados ; i++)
    	{
    		vector_privado[i]=cadena.at(i);
		}
	}
	
    /***********************************************************************/
    // Devuelve el n�mero de casillas ocupadas

    int TotalUtilizados (void)
    {
        return (total_utilizados);
    }

    /***********************************************************************/
    // Devuelve el n�mero de casillas disponibles

    int Capacidad (void)
    {
        return (TAMANIO);
    }

    /***********************************************************************/
    // "Vac�a" completamente la secuencia

	void EliminaTodos()
	{
		total_utilizados = 0;
	}

    /***********************************************************************/
    // A�ade un elemento ("nuevo") al vector.
    // PRE: total_utilizados < TAMANIO
    // 		La adici�n se realiza si hay alguna casilla disponible.
    // 		El nuevo elemento se coloca al final del vector.
    // 		Si no hay espacio, no se hace nada.

    void Aniade (char nuevo)
    {
        if (total_utilizados < TAMANIO){
            vector_privado[total_utilizados] = nuevo;
            total_utilizados++;
        }
    }

    /***********************************************************************/
    // Devuelve el elemento de la casilla "indice"
    // PRE: 0 <= indice < total_utilizados

    char Elemento (int indice)
    {
        return (vector_privado[indice]);
    }

    /***********************************************************************/
    // Cambia el contenido de la casilla "indice" por el valor "nuevo"
    // PRE: 0 <= indice < total_utilizados

   void Modifica (int indice, char nuevo)
   {
		if ((indice >= 0) && (indice < total_utilizados))
			vector_privado[indice] = nuevo;
   }


    /***********************************************************************/
    // Eliminar el car�cter de la posici�n dada por "indice".
    // Realiza un borrado f�sico (desplazamiento y sustituci�n).
    // PRE: 0 <= indice < total_utilizados

    void Elimina (int indice)
    {
        if ((indice >= 0) && (indice < total_utilizados)) {

            int tope = total_utilizados-1; // posic. del �ltimo

            for (int i = indice ; i < tope ; i++)
                vector_privado[i] = vector_privado[i+1];

            total_utilizados--;
        }
    }
 

    /***********************************************************************/
    // Inserta el car�cter "nuevo" en la posici�n dada por "indice".
    // Desplaza todos los caracteres una posici�n a la derecha antes de 
	// copiar en "indice" en valor "nuevo".
	// PRE: 0 <= indice < total_utilizados
    // PRE: total_utilizados < TAMANIO
    // 		La inseerci�n se realiza si hay alguna casilla disponible.
    // 		Si no hay espacio, no se hace nada.
    
	void Inserta (int indice, char valor_nuevo)
	{
        if ((indice >= 0) && (indice < total_utilizados) 
		    && (total_utilizados < TAMANIO)) {
		
			for (int i = total_utilizados ; i > indice ; i--)
				vector_privado[i] = vector_privado[i-1];
			
			vector_privado[indice] = valor_nuevo;
			total_utilizados++;		
		}
	}
   
    /***********************************************************************/
    // Compone un string con todos los caracteres que est�n
    // almacenados en la secuencia y lo devuelve.

    string ToString()
    {
        string cadena;

        for (int i=0; i<total_utilizados; i++)
            cadena = cadena + vector_privado[i];

        return (cadena);
    }
	
	/***********************************************************************/
	//Elimina un caracter de la secuencia todas las veces que aparezca
	
	void EliminaOcurrencias (char caracter)
	{
		int posicion=0;
		while(posicion<total_utilizados)
		{
			if(vector_privado[posicion]==caracter)
			{
				Elimina(posicion);
			}
			else
			{
				posicion++;
			}
		}
	}
	
	/***********************************************************************/
	//Elimina los espacios en blanco consecutivos hasta dejar uno solo
	
	void EliminaExcesoBlancos()
	{
		bool espacio=false;
		int posicion=0;
		
		while(posicion<total_utilizados)
		{
			if(vector_privado[posicion]==' ')
			{
				if(!espacio) //Si no hab�a espacio antes
				{
					espacio=true; //Ahora s� hay espacio
					posicion++; 
				}
				else //Si hab�a espacio antes
				{
					Elimina(posicion);
				}
			}
			else
			{
				espacio=false;
				posicion++;
			}
		}
	}
	
	
	/***********************************************************************/
};
/*****************************************************************************
  	Funci�n:
	Par�metros:
	Devuelve:
............................................................................*/

/****************************************************************************/
/****************************************************************************/
int main()
{
	//Declaraci�n de Datos

	string cadena_aux;
	
	//Entradas

	cout<<"Introduce cadena de caracteres: ";
	getline(cin,cadena_aux);
	
	SecuenciaCaracteres secuencia(cadena_aux);

	//Salidas

	cout<<"Secuencia generada: "<<secuencia.ToString()<<endl;
	secuencia.EliminaExcesoBlancos();
	cout<<"Secuencia procesada: "<<secuencia.ToString()<<endl;


	return 0;
}

