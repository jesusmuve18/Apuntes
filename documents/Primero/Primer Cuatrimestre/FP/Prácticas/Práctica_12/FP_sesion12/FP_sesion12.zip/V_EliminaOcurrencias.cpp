/****************************************************************************/
//	FUNDAMENTOS DE PROGRAMACI�N			RELACI�N_V				EJERCICIO_40
/****************************************************************************/
/*
	Jes�s Mu�oz Velasco 					Grupo:A2

	Enunciado:

	A�adir el m�todo EliminaOcurrencias para eliminar todas las apariciones que
	hubiese de un determinado car�cter a_borrar en la secuencia.
	
	Por ejemplo, despu�s de eliminar el car�cter 'o' de la secuencia
	
	{'S','o','Y',' ','y','o'} �sta debe quedar: {'S','Y',' ','y'}.
	Para conseguir una buena soluci�n aplicad el algoritmo que emplea dos 
	apuntadores.

*/
/****************************************************************************/
#include<iostream>
using namespace std;
/****************************************************************************/
//Declaraci�n de constantes globales

/****************************************************************************/
//Declaraci�n de tipos de datos

/****************************************************************************/
//Declaraci�n de Clases/Objetos
class SecuenciaCaracteres {

private:

    static const int TAMANIO = 50; // N�m.casillas disponibles
    char vector_privado[TAMANIO];

    // PRE: 0<=total_utilizados<TAMANIO

    int total_utilizados; // N�m.casillas ocupadas

public:

    /***********************************************************************/
    // Constructor sin argumentos

    SecuenciaCaracteres (void) : total_utilizados (0)
    {}
    
    //Constructor con argumentos 
    
    SecuenciaCaracteres(string cadena)
    {
    	total_utilizados=cadena.length();
    	
    	for(int i=0; i<total_utilizados ; i++)
    	{
    		vector_privado[i]=cadena.at(i);
		}
	}
	
	/***********************************************************************/
	//Actualiza la secuencia con una cadena dada
	SetSecuencia(string cadena)
	{
		total_utilizados=cadena.length();
    	
    	for(int i=0; i<total_utilizados ; i++)
    	{
    		vector_privado[i]=cadena.at(i);
		}
	}
	
    /***********************************************************************/
    // Devuelve el n�mero de casillas ocupadas

    int TotalUtilizados (void)
    {
        return (total_utilizados);
    }

    /***********************************************************************/
    // Devuelve el n�mero de casillas disponibles

    int Capacidad (void)
    {
        return (TAMANIO);
    }

    /***********************************************************************/
    // "Vac�a" completamente la secuencia

	void EliminaTodos()
	{
		total_utilizados = 0;
	}

    /***********************************************************************/
    // A�ade un elemento ("nuevo") al vector.
    // PRE: total_utilizados < TAMANIO
    // 		La adici�n se realiza si hay alguna casilla disponible.
    // 		El nuevo elemento se coloca al final del vector.
    // 		Si no hay espacio, no se hace nada.

    void Aniade (char nuevo)
    {
        if (total_utilizados < TAMANIO){
            vector_privado[total_utilizados] = nuevo;
            total_utilizados++;
        }
    }

    /***********************************************************************/
    // Devuelve el elemento de la casilla "indice"
    // PRE: 0 <= indice < total_utilizados

    char Elemento (int indice)
    {
        return (vector_privado[indice]);
    }

    /***********************************************************************/
    // Cambia el contenido de la casilla "indice" por el valor "nuevo"
    // PRE: 0 <= indice < total_utilizados

   void Modifica (int indice, char nuevo)
   {
		if ((indice >= 0) && (indice < total_utilizados))
			vector_privado[indice] = nuevo;
   }


    /***********************************************************************/
    // Eliminar el car�cter de la posici�n dada por "indice".
    // Realiza un borrado f�sico (desplazamiento y sustituci�n).
    // PRE: 0 <= indice < total_utilizados

    void Elimina (int indice)
    {
        if ((indice >= 0) && (indice < total_utilizados)) {

            int tope = total_utilizados-1; // posic. del �ltimo

            for (int i = indice ; i < tope ; i++)
                vector_privado[i] = vector_privado[i+1];

            total_utilizados--;
        }
    }
 

    /***********************************************************************/
    // Inserta el car�cter "nuevo" en la posici�n dada por "indice".
    // Desplaza todos los caracteres una posici�n a la derecha antes de 
	// copiar en "indice" en valor "nuevo".
	// PRE: 0 <= indice < total_utilizados
    // PRE: total_utilizados < TAMANIO
    // 		La inseerci�n se realiza si hay alguna casilla disponible.
    // 		Si no hay espacio, no se hace nada.
    
	void Inserta (int indice, char valor_nuevo)
	{
        if ((indice >= 0) && (indice < total_utilizados) 
		    && (total_utilizados < TAMANIO)) {
		
			for (int i = total_utilizados ; i > indice ; i--)
				vector_privado[i] = vector_privado[i-1];
			
			vector_privado[indice] = valor_nuevo;
			total_utilizados++;		
		}
	}
   
    /***********************************************************************/
    // Compone un string con todos los caracteres que est�n
    // almacenados en la secuencia y lo devuelve.

    string ToString()
    {
        string cadena;

        for (int i=0; i<total_utilizados; i++)
            cadena = cadena + vector_privado[i];

        return (cadena);
    }
	
	/***********************************************************************/
	void EliminaOcurrencias (char caracter)
	{
		int posicion=0;
		while(posicion<total_utilizados)
		{
			if(vector_privado[posicion]==caracter)
			{
				Elimina(posicion);
			}
			else
			{
				posicion++;
			}
		}
	}
	/***********************************************************************/
};
/*****************************************************************************
  	Funci�n:
	Par�metros:
	Devuelve:
............................................................................*/

/****************************************************************************/
/****************************************************************************/
int main()
{
	//Declaraci�n de Datos
	
	string cadena_aux;
	char caracter_a_eliminar;
	
	//Entradas

	cout<<"Introduce cadena de caracteres: ";
	cin>>cadena_aux;
	
	SecuenciaCaracteres secuencia(cadena_aux);
	
	cout<<"Introduce caracter a eliminar: ";
	cin>>caracter_a_eliminar;
	

	//C�lculos
	
	cout<<"Secuencia generada:"<<secuencia.ToString()<<endl;
	secuencia.EliminaOcurrencias(caracter_a_eliminar);
	cout<<"Secuencia procesada: "<<secuencia.ToString()<<endl;

	//Salidas



	return 0;
}

