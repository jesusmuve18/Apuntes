/****************************************************************************/
//	FUNDAMENTOS DE PROGRAMACI�N			RELACI�N_III			EJERCICIO_9
/****************************************************************************/
/*
	Jes�s Mu�oz Velasco 					Grupo:A2
	
	Enunciado:
	
	Un n�mero entero de n d�gitos se dice que es narcisista si se puede obtener 
	como la suma de las potencias n-�simas de cada uno de sus d�gitos. Por 
	ejemplo 153 y 8208 son n�meros narcisistas porque 153 = 1^3 + 5^3 + 3^3
	y 8208 = 8^4 + 2^4 + 0^4 + 8^4

	Construir un programa que nos indique si un entero positivo es narcisista
	
	Reescribid el programa construido para implementar la soluci�n al 
	ejercicio anterior modularizando con funciones.

	
	Entradas: Un numero
	
	Salidas: Si es narcisista o no
	
*/
/****************************************************************************/
#include<iostream>
#include<cmath>
using namespace std;
/****************************************************************************/

bool EsNarcisista(int numero)
{
	
	//Declaraci�n de Datos
	
	string num = to_string(numero);
	int sumatorio=0, contador=0, potencia=0;
	
	bool es_narcisista; //Dato que devolver� la funci�n
	
	
	//C�lculos
	
	/*El algoritmo consiste en variar las potencias a las que se eleva cada uno
	de las cifras del n�mero empezando en 0 (Por ejemplo: 1= 1^0). En cada paso 
	se pueden dar 3 casos:
	
	a) El sumatorio calculado es menor que el n�mero original:
			Aumento la potencia y vuelvo a realizar el sumatorio
			
	b) El sumatorio calculado es mayor que el n�mero original:
			Detengo el bucle ya que al aumentar la potencia aumentar� el 
			sumatorio siendo imposible que se iguale con el n�mero original
			y llego a la conclusi�n de que el n�mero no es narcisita
	
	c) El sumatorio calculado es igual que el n�mero original:
			Detengo el bucle ya que he confirmado que el n�mero es narcisista
	*/
	
	while(sumatorio<numero) //Mientras no supere al n�mero (Caso a)
	{
		sumatorio=0;
		for(int i=0;i<num.length();i++)
		{
			sumatorio+=pow(((int)(num.at(i)-'0')),potencia);
		}
		potencia++;
	} //Salgo del bucle ya que se da el caso b) o el c)
	
	
	if(sumatorio==numero) //Se da el caso c)-> Es narcisista
	{
		es_narcisista=true;
	}
	else //Se da el caso b)-> No es narcisista
	{
		es_narcisista=false;
	}
	
	
	return es_narcisista;	//Salida de la funci�n
}

/****************************************************************************/
int main()
{
	
	//Programa para probar la funci�n
	
	//Declaraci�n de datos
	
	int numero;
	
	
	//Entradas
	
	do //Filtro para n�mero (que tiene que ser >=0)
	{
		cout<<"Introduce un numero: ";
		cin>>numero;
		
	} while (numero<0);
	
	
	
	//Salidas
	
	if(EsNarcisista(numero))
	{
		cout<<"Es narcisista"<<endl;
	}
	else
	{
		cout<<"No es narcisista"<<endl;
	}
	
	
	return 0;
}
