/****************************************************************************/
//	FUNDAMENTOS DE PROGRAMACI�N			RELACI�N_III			EJERCICIO_22
/****************************************************************************/
/*
	Jes�s Mu�oz Velasco 					Grupo:A2
	
	
	Enunciado:
	
	Escriba la funci�n LeeOpcion2Alternativas que realiza las siguientes 
	tareas:
	
		a) imprime en pantalla un mensaje
		b) lee una opci�n de forma que s�lo admita los caracteres �s�, �S�, �n� 
			� �N�
		c) devuelve la opci�n escogida. Piense: �qu� deber�a devolver la 
			funci�n, el car�cter le�do o un valor bool?.
			
	Aplique esta funci�n en la soluci�n del ejercicio 85 de la Relaci�n de 
	Problemas II (adivinar un n�mero repetidamente) para volver (o no) a jugar. 
	Modularice con funciones cuantas tareas cree oportunas en ese programa.


	Entradas: N�meros (intentando adivinar el n�mero secreto)
	
	Salidas: -Si el n�mero introducido es mayor o menor que la inc�gnita
			 -Si se ha ganado o no
	
*/
/****************************************************************************/
#include<iostream>
#include<ctime>
#include<cstdlib>
using namespace std;
/****************************************************************************/
//Declaraci�n de constantes globales

const int TERMINADOR=0;	
const int MIN = 1;
const int MAX = 100;
const int NUM_VALORES = MAX-MIN + 1; // N�m. de valores posibles
/****************************************************************************/
bool GanaPartida (int incognita ) 	//Funci�n que indica si se ha ganado la 
{									//partida
	
	//Declaraci�n de Datos
	
	int numero;	//Intento de adivinar la inc�gnita
	bool victoria=false; //Dato que devuelve la funci�n
	bool num_ok; //Indica si el n�mero es v�lido
	
	do	//while(numero!=incognita && numero!=TERMINADOR);
	{

		do  //Filtro de n�mero
		{
			cout<<">";
			cin>>numero;
			num_ok=((MIN<=numero && numero<=MAX)|| numero==TERMINADOR);	
			
		} while (!num_ok);
		
		
		if(numero!=TERMINADOR)
		{
					
			if(numero<incognita)
			{
				cout<<"La incognita es mayor"<<endl;
			}
			else
			{
				
				if(numero>incognita)
				{
					cout<<"La incognita es menor"<<endl;
				}
				else //numero==incognita
				{
					victoria=true;
				}
				
			}
			
		} // if(numero!=TERMINADOR)
		
		cout<<endl;
		
	} while(numero!=incognita && numero!=TERMINADOR);
	
		
	//Salida de la funci�n
	return victoria;	
}
		
/****************************************************************************/

char LeeOpcion2Alternativas (string titulo)
{
	char respuesta; //Dato que devuelve la funci�n
	
	do
	{
		cout<<titulo;
		cin>>respuesta;
		
		respuesta=toupper(respuesta); //Paso a may�scula para reducir casos
		
	} while(respuesta!='S' && respuesta !='N');
	
	
	//Salida de la funci�n
	return respuesta;
}
/****************************************************************************/
/****************************************************************************/
int main()
{
	
	//Declaraci�n de datos

	time_t t;
	srand(time(&t)); 	// Inicializa generador de n�ms. aleatorios
						// con el reloj del sistema (hora actual)
						
	int incognita; 	// N�mero aleatorio que se genera
	
	bool victoria=false;	//Indica si se ha adivinado la inc�gnita
	bool volver_a_jugar=true;	//Indica si se va a volver a jugar
	int juegos=0, abandonos=0;	//Estad�sticas finales
	
	
	
	//Entradas y c�lculos
	
	while(volver_a_jugar)
	{
		incognita = (rand() % NUM_VALORES) + MIN;
		juegos++;
		cout<<"Intenta adivinar el numero secreto: "<<endl;
		cout<<"Si quieres dejar de jugar pulsa el "<<TERMINADOR<<endl;
		
		victoria=GanaPartida(incognita);
				
		
		//Salidas
		
		if(victoria==true)
		{
			cout<<"Enhorabuena has acertado la incognita"<<endl;
		}
		else
		{
			cout<<"Vaya, parece que te has rendido"<<endl;
			abandonos++;
		}
		
		char respuesta;
		
		respuesta=LeeOpcion2Alternativas("Quieres volver a jugar? (S/N): ");
		
		if(respuesta=='S')
		{
			cout<<"Ha elegido volver a jugar"<<endl;
			cout<<endl;
		}
		else
		{
			cout<<endl;
			cout<<"Juegos realizados: "<<juegos<<endl;
			cout<<"Abandonos: "<<abandonos<<endl;
			
			volver_a_jugar=false; //Finaliza el juego
		}
			
	} //while(volver_a_jugar)
	
	return 0;
}

