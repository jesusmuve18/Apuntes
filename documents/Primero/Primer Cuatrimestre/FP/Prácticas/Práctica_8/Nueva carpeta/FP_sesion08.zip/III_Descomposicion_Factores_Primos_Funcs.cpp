/****************************************************************************/
//	FUNDAMENTOS DE PROGRAMACI�N			RELACI�N_III			EJERCICIO_42
/****************************************************************************/
/*
	Jes�s Mu�oz Velasco 					Grupo:A2
	
	Enunciado:
	
	Reescriba la soluci�n del ejercicio 47 de la Relaci�n de Problemas II 
	usando funciones. En dicho ejercicio se ped�a leer un n�mero entero 
	positivo y calcular y mostrar su descomposici�n en factores primos de dos 
	maneras diferentes.
	
	Escriba ahora dos funciones void para calcular y mostrar la descomposici�n 
	en factores primos de n, con las cabeceras:
	
			void CalculaMuestra_DescFactPrimos_1 (int n);
			void CalculaMuestra_DescFactPrimos_2 (int n);
			
	y otras dos para calcular la descomposici�n en factores primos de n 
	devolviendo la expresi�n textual en un string. Las cabeceras ser�n:
	
			string Calcula_DescFactPrimos_1 (int n);
			string Calcula_DescFactPrimos_2 (int n);

	
	Entradas: N�mero
	
	Salidas: Divisores primos calculados con 4 funciones diferentes
	
*/
/****************************************************************************/
#include<iostream>
using namespace std;
/****************************************************************************/
void CalculaMuestra_DescFactPrimos_1 (int numero)
{
	
	//Declaraci�n de Datos
	
	int resto=numero; //Copia para no modificar el dato original
	
	int contador=2; //Posibles divisores del n�mero dado
	
	bool primer_divisor=true; //Indicador para mostrar el signo '*'
							  //a partir del segundo divisor
	
	
	//C�lculos y Salidas
	
	while(resto>1)
	{
		if(resto%contador==0) //Si el contador es un divisor del resto
		{
			if(primer_divisor) //El primer divisor encontrado
			{
				//Cambio el par�metro para ejecutar la condici�n opuesta el 
				//resto de veces que se ejecute el bucle
				primer_divisor=false;
			}
			else //A partir del segundo divisor encontrado
			{
				cout<<" * "; //Muestro por pantalla el caracter '*'
			}
			
			cout<<contador; //Muestro por pantalla el divisor confirmado
			
			resto/=contador; //Actualizo el valor del resto
			
		} //if(resto%contador==0)
		else
		{
			
			contador++; //No es un divisor del resto por lo que pruebo el 
						//siguiente natural
		}
		
	} //while(resto>1)
	
}//void CalculaMuestra_DescFactPrimos_1 (int numero)

/****************************************************************************/

void CalculaMuestra_DescFactPrimos_2 (int numero)
{
	
	//Declaraci�n de Datos
	
	int resto=numero; //Copia para no modificar el dato original
	
	int contador=2; //Posibles divisores del n�mero dado
	
	bool primer_divisor=true; //Indicador para mostrar el signo '*'
							  //a partir del segundo divisor
							  
	int potencia; //Almacena el numero de veces que se repite un divisor
	
	
	
	//C�lculos y salidas
	
	while(resto>1)
	{
		potencia=0; //Reseteo el valor de la potencia
		
		while(resto%contador==0) //Si el contador es un divisor del resto
		{
			resto/=contador; //Actualizo el valor del resto
			potencia++; //Actualizo el valor de la potencia
			
		}
		
		if(potencia>0) //Si al menos puedo dividir una vez entre el contador
		{
			
			if(primer_divisor) //El primer divisor encontrado
			{
				//Cambio el par�metro para ejecutar la condici�n opuesta el 
				//resto de veces que se ejecute el bucle
				primer_divisor=false;
			}
			else //A partir del segundo divisor encontrado
			{
				cout<<" * ";
			}
			
			
			//Muestro por pantalla el divisor confirmado
			cout<<contador;
			
			
			//Muestro por pantalla la potencia solo en el caso de que sea 
			//mayor que 1
			if(potencia>1)
			{
				cout<<"^"<<potencia; 
			}
			
			
		} //if(potencia>0)
			
			
		contador++; //No es un divisor del resto por lo que pruebo el 
					//siguiente natural

	} //while(resto>1)
	
} // void CalculaMuestra_DescFactPrimos_2 (int numero)

/****************************************************************************/

string Calcula_DescFactPrimos_1 (int numero)
{
	
	//Declaraci�n de Datos
	
	string divisores=""; //Cadena que devolver� la funci�n
	
	int resto=numero; //Copia para no modificar el dato original
	
	int contador=2; //Posibles divisores del n�mero dado
	
	bool primer_divisor=true; //Indicador para mostrar el signo '*'
							  //a partir del segundo divisor
	
	
	//C�lculos
	
	while(resto>1)
	{
		
		if(resto%contador==0) //Si el contador es un divisor del resto
		{
			
			if(primer_divisor) //El primer divisor encontrado
			{
				//Cambio el par�metro para ejecutar la condici�n opuesta el 
				//resto de veces que se ejecute el bucle
				primer_divisor=false;
			}
			else //A partir del segundo divisor encontrado
			{
				divisores+=" * "; //A�ado al string el caracter '*'
			}
			
			
			//A�ado al string el divisor confirmado convertido a texto
			divisores+=to_string(contador); 
			
			
			resto/=contador; //Actualizo el valor del resto
			
		} //if(resto%contador==0)
		else
		{
			
			contador++; //No es un divisor del resto por lo que pruebo el 
						//siguiente natural
						
		}
		
	}//while(resto>1)
	
	
	return divisores; //Salida de la funci�n
	
	
} //string Calcula_DescFactPrimos_1 (int numero)

string Calcula_DescFactPrimos_2 (int numero)
{
	
	//Declaraci�n de Datos
	
	string divisores=""; //Cadena que devolver� la funci�n
	
	int resto=numero; //Copia para no modificar el dato original
	
	int contador=2; //Posibles divisores del n�mero dado
	
	bool primer_divisor=true; //Indicador para mostrar el signo '*'
							  //a partir del segundo divisor
							  
	int potencia; //Almacena el numero de veces que se repite un divisor
	
	
	
	//C�lculos
	
	while(resto>1)
	{
		potencia=0; //Reseteo el valor de la potencia
		
		while(resto%contador==0) //Si el contador es un divisor del resto
		{
			resto/=contador; //Actualizo el valor del resto
			potencia++; //Actualizo el valor de la potencia
			
		}
		
		if(potencia>0) //Si al menos puedo dividir una vez entre el contador
		{
			
			if(primer_divisor) //El primer divisor encontrado
			{
				//Cambio el par�metro para ejecutar la condici�n opuesta el 
				//resto de veces que se ejecute el bucle
				primer_divisor=false;
			}
			else //A partir del segundo divisor encontrado
			{
				divisores+=" * "; //A�ado a la cadena el caracter '*'
			}
			
			
			//A�ado a la cadena el divisor confirmado como texto
			divisores+=to_string(contador); 
			
			
			//A�ado a la cadena la potencia como texto solo en el caso de que  
			//sea mayor que 1
			if(potencia>1)
			{
				divisores+="^"+to_string(potencia); 
			}
			
			
		} //if(potencia>0)
			
			
		contador++; //No es un divisor del resto por lo que pruebo el 
					//siguiente natural

	} //while(resto>1)
	
	
	return divisores;	//Salida de la funci�n
	
}//string Calcula_DescFactPrimos_2 (int numero)

/****************************************************************************/

int main()
{
	
	//Declaraci�n de datos
	
	int numero;
	
	
	//Entradas
	
	do //Filtro del entero "numero" que deber� ser >0
	{
		cout<<"Numero: ";
		cin>>numero;
	} while (numero<=0);
	
	
	
	//Salidas
	
	cout<<endl;
	
		//Pruebo las funciones de tipo void
	cout<<"Divisores primos ( void 1 ): ";
	CalculaMuestra_DescFactPrimos_1(numero);
	
	cout<<endl;
	
	cout<<"Divisores primos ( void 2 ): ";
	CalculaMuestra_DescFactPrimos_2(numero);
	
	
	cout<<endl;
	cout<<endl;
	
	
		//Pruebo las funciones de tipo string y las muestro por pantalla
	cout<<"Divisores primos (string 1): ";
	cout<<Calcula_DescFactPrimos_1(numero)<<endl;
	cout<<"Divisores primos (string 2): ";
	cout<<Calcula_DescFactPrimos_2(numero)<<endl;
		
	
	return 0;
}
