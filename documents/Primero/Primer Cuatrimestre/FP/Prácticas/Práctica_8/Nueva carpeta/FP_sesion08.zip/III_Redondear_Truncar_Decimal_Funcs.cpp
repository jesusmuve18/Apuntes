/****************************************************************************/
//	FUNDAMENTOS DE PROGRAMACI�N			RELACI�N_III			EJERCICIO_13
/****************************************************************************/
/*
	Jes�s Mu�oz Velasco 					Grupo:A2
	
	Enunciado:
	
	En cmath est� definida la funci�n round que permite redondear un real al 
	entero m�s pr�ximo. Por ejemplo: round(3.6) devuelve 4, round(3.5) 
	devuelve 4, round(3.1) devuelve 3 y round(3.49) devuelve 3.
	
	Nuestro inter�s es hacer algo similar pero para permitir el redondeo de la 
	parte decimal, especificando el n�mero de cifras decimales que nos 
	interese. Por ejemplo:
	
		� El resultado de redondear 3.49 a la primera cifra decimal es 3.5
		� El resultado de redondear 3.49 a la segunda cifra decimal es 3.49
		� El resultado de redondear 3.496 a la segunda cifra decimal es 3.5
		
	Defina la funci�n Redondea para calcular un n�mero real aproximado a un 
	n�mero de cifras decimales dado.
	
	En el ejercicio 36 se ped�a truncar la parte decimal de un n�mero real 
	usando un n�mero dado de cifras decimales. Por ejemplo:
	
		� El resultado de truncar 3.49 a una cifra decimal es 3.4
		� El resultado de truncar 3.496 a la segunda cifra decimal es 3.49
		� El resultado de truncar 3.496 sin decimales es 3 (3.0)
		
	Defina la funci�n Trunca para truncar un n�mero real usando un n�mero de 
	cifras decimales dado.
	
	En la implementaci�n de estas funciones, necesitar� calcular potencias 
	enteras (potencias de 10 en este caso). Para ello, use la funci�n Potencia 
	del ejercicio 2.

	
	Entradas: N�mero real y cifra a la que redondear
	
	Salidas: N�mero redondeado a la cifra-�sima cifra
	
*/
/****************************************************************************/
#include<iostream>
using namespace std;

#define VALORES_VARIABLES				//Activar o desactivar para distintas 
//#define VALORES_FIJOS					//pruebas de la funcion

const int BASE=10;	//Para desplazar la coma multiplicando o dividiendo 

/****************************************************************************/

double Potencia(int base, int exponente)	//Funci�n para calcular potencias
{											//La defino double para obtener
	int potencia=1;							//resultados reales al operar con 
	for(int i=0; i<exponente; i++)			//ella
	{
		potencia*=base;
	}
	return potencia;
}

double Trunca(double n, int cifras) //Funci�n para truncar
{
	double r_trunc=((int)(n*(Potencia(BASE, cifras))))
					/((Potencia(BASE, cifras)));
	return r_trunc;
}

double Redondea(double n, int cifras)
{
	int cifra_significativa= ((Trunca(n,(cifras+1))-Trunca(n,cifras))
								*(Potencia(BASE, (cifras+1))));
					
	/*Esta cifra es la que indica en el redondeo a la i-�sima posici�n 
	  decimal si debe o no sumarse uno a la cifra q se est� redondeando, es 
	  decir a la (i-1)-�sima cifra decimal. Por ejemplo: 
	  
	  La cifra que indica el redondeo a la 2� cifra decimal del 3.4472 es el 7.
	  Para obtener dicho n�mero trunco el n�mero dado a la 3� cifra decimal
	  (a la dada +1) y tambi�n calculo el n�mero truncado a la cifra que se 
	  pide redondear. Obtengo:
	  			primer n�mero: 3.447
	  			segundo n�mero: 3.44
	  Si ahora desplazo la coma 3 posiciones (al n�mero de cifras decimales
	  que se pide redondear +1), es decir multiplicar por 10^3 obtendr�a.
	  			primer n�mero: 3447
	  			segundo n�mero: 3440
	  La cifra que busco es la diferencia entre el primero y el segundo 
	  n�mero:
	  			cifra_significativa: 3447-3440= 7
	    
	Si dicha cifra es mayor o igual que 5 le sumo uno a la cifra anterior*/
	
	
	if(cifra_significativa>=5)
	{
		n+=(1.0/(Potencia(BASE, cifras)));
	}
	
	//Finalmente trunco el numero redondeado a la cifra dada
	double redondeo=Trunca(n,cifras);
	
	return redondeo;
}

/****************************************************************************/
int main()
{
	#ifdef VALORES_VARIABLES
	
	//Programa para probar la funci�n con valores variables
	
	//Declaraci�n de datos
	
	double numero, resultado;
	int cifras;
		
		
	//Entradas
	
	cout<<"Numero real: ";
	cin>>numero;
	
	do //Filtro el n�mero de cifras a las que redondear (tienen que ser >=0)
	{
		cout<<"Cifras decimales a las que redondear: ";
		cin>>cifras;	
	} while (cifras<0);
	
	
	//C�lculos
	
	resultado=Redondea(numero, cifras);
	
	
	//Salidas
	
	cout<<endl;
	cout<<"El numero "<<numero<<" redondeado a la cifra decimal "<<cifras
		<<" es "<<resultado;
	
	#endif

	//........................................................................
	
	#ifdef VALORES_FIJOS
	
	//Programa para probar la funci�n con valores fijos
	cout<<Redondea(3.141592,4)<<endl;
	
	#endif
	return 0;
}
