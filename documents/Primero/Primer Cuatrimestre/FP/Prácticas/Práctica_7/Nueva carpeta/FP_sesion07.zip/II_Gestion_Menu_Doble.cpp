/****************************************************************************/
//	FUNDAMENTOS DE PROGRAMACI�N			RELACI�N_II				EJERCICIO_1
/****************************************************************************/
/*
	Jes�s Mu�oz Velasco 					Grupo:A2
	
	Enunciado:
	
	Escribir un programa en el que se presente un men� principal para que el 
	usuario	pueda elegir entre las siguientes opciones:
	
							A�>Calcular adici�n.
							P�>Calcular producto.
							X�>Salir.
							
	Si el usuario elige en el men� principal:
	a) Salir, el programa terminar� su ejecuci�n.
	b) Calcular adici�n se presenta un men� (secundario) para que el usuario
	   pueda elegir entre las siguientes opciones:
	   
							S�>Calcular suma.
							R�>Calcular resta.
							X�>Salir.
							
	c) Calcular producto se presenta un men� (secundario) para que el usuario 
	pueda elegir entre las siguientes opciones:
	
							M�>Calcular multiplicaci�n.
							D�>Calcular divisi�n entera.
							R�>Calcula resto.
							X�>Salir.
							
	MUY IMPORTANTE: Para implementar las operaciones de producto no es posible 
	utilizar los operadores de multiplicaci�n (*) ni divisi�n (/). Deber� 
	emplear	sumas (+) y restas (-).
	
	En las operaciones seleccionadas desde los men�s secundarios el programa 
	pedir� dos n�meros enteros, realizar� la operaci�n seleccionada, mostrar� 
	el resultado y	volver� a mostrar el men� secundario seleccionado 
	anteriormente.
	
	En los dos men�s secundarios la selecci�n de Salir hace que el programa 
	vuelva a mostrar el men� principal.

	
	Entradas: 
	
	Salidas: 
	
*/
/****************************************************************************/
#include<iostream>
using namespace std;
/****************************************************************************/
int main()
{
	
	//Declaraci�n de datos
	
	char eleccion_1, eleccion_2;
	int num1, num2;
	int resultado;
	bool acabar=false;
	int aux, contador;

	//Proceso
	while(!acabar)
	{
		//Entradas
		
		cout<<endl;
		cout<<"Menu Principal: "<<endl;
		cout<<"\tA: Calcular adicion"<<endl;
		cout<<"\tP: Calcular producto"<<endl;
		cout<<"\tX: Salir"<<endl;
		cout<<">";
		cin>>eleccion_1;
	
		
		//C�lculos
		
		eleccion_1=toupper(eleccion_1);
		
		switch(eleccion_1)
		{
			case 'A':
				
				//Entradas de la elecci�n para el men� adici�n
				cout<<endl;
				cout<<"Menu Secundario: "<<endl;
				cout<<"\tS: Calcular suma"<<endl;
				cout<<"\tR: Calcular resta"<<endl;
				cout<<"\tX: Salir"<<endl;
				cout<<">";
				cin>>eleccion_2;
				
				
				eleccion_2=toupper(eleccion_2);
				
				//Filtro de la entrada
				switch (eleccion_2)
				{
					case 'S':
						
						//Entradas de la suma
						cout<<"Ha elegido la suma:"<<endl;
						cout<<endl;
						cout<<"Numero 1: ";
						cin>>num1;
						cout<<"Numero 2: ";
						cin>>num2;
						
						//C�lculo de la suma
						resultado=num1+num2;
						
						//Salida de la suma
						cout<<endl;
						cout<<num1<<" + "<<num2<<" = "<<resultado<<endl;
						
						break;
					
					case 'R':
						
						//Entradas de la resta
						cout<<endl;
						cout<<"Ha elegido la resta:"<<endl;
						cout<<"Numero 1: ";
						cin>>num1;
						cout<<"Numero 2: ";
						cin>>num2;
						
						//C�lculo de la resta
						resultado=num1-num2;
						
						//Salida de la resta
						cout<<endl;
						cout<<num1<<" - "<<num2<<" = "<<resultado<<endl;
						
						break;
					
					case 'X':	//X del men� secundario adici�n
						break;	//Con esto vuelvo al men� principal
						
					default:
						cout<<"No ha introducido un valor valido"<<endl;
				}
				
				break;
				
			case 'P':
				
				//Entrada de la elecci�n sobre el men� producto
				cout<<endl;
				cout<<"Menu Secundario: "<<endl;
				cout<<"\tM: Calcular multiplicacion"<<endl;
				cout<<"\tD: Calcular division entera"<<endl;
				cout<<"\tR: Calcular resto"<<endl;
				cout<<"\tX: Salir"<<endl;
				cout<<">";
				cin>>eleccion_2;
				
				eleccion_2=toupper(eleccion_2);
				
				switch (eleccion_2)
				{					
					case 'M':
						
						//Entradas de la multiplicaci�n
						cout<<endl;
						cout<<"Ha elegido la multiplicacion:"<<endl;
						cout<<"Numero 1: ";
						cin>>num1;
						cout<<"Numero 2: ";
						cin>>num2;
						
						//C�lculo del producto
						
						resultado=0;	//Neutro de la suma
						
						for(int i=0; i<num1; i++)
							resultado+=num2; //Desarrollo el producto como
											 //suma
											 
						//Salida del producto
						cout<<endl;
						cout<<num1<<" * "<<num2<<" = "<<resultado<<endl;
						
						break;
						
						
					case 'D':
						
						//Entradas de la divisi�n
						cout<<endl;
						cout<<"Ha elegido la division:"<<endl;
						cout<<"Numero 1: ";
						cin>>num1;
						cout<<"Numero 2: ";
						cin>>num2;
						
						//C�lculo de la divisi�n
						
						aux=num1;			//Para no modificar el num1
						
						
						while(aux>=num2)
						{
							aux-=num2; 	//Desarrollo el cociente como resta
							contador++;		
						}
							
						resultado=contador;
						
						//Salida de la divisi�n
						cout<<endl;
						cout<<num1<<" / "<<num2<<" = "<<resultado<<endl;
						
						break;
						
						
					case 'R':
						
						//Entradas del resto
						cout<<endl;
						cout<<"Ha elegido el resto:"<<endl;
						cout<<"Numero 1: ";
						cin>>num1;	//Dividendo
						cout<<"Numero 2: ";
						cin>>num2;	//Divisor
						
						//C�lculos del resto
						
						//Aplicar� resto=dividendo-(divisor*cociente)
						
						//Dividendo entre divisor para calcular el cociente
						resultado=0;
						aux=num1;
												 
						while(aux>=num2)
						{
							aux-=num2; 	//Desarrollo el cociente como resta
							contador++;
						}
						
						//El contador en este punto servir� de cociente 
						
						aux=0; //reseteo para volver a usarlo
						
						//Calculo divisor*cociente y lo guardo en aux
						for(int i=0; i<contador; i++)
						{
							aux+=num2; 	//Desarrollo el producto como suma
						}
							
						resultado=num1-aux;
						
						//Salida del resto	
						cout<<endl;
						cout<<num1<<" % "<<num2<<" = "<<resultado<<endl;
						
						break;
					
					
					case 'X':	//X del menu secundario producto
						break;	//Con esto vuelvo al men� principal
						
					default:
						cout<<"No ha introducido un valor valido"<<endl;
				}
				
				break;
				
			case 'X':		//X del men� principal
				acabar=true; //Indico que se debe acabar el proceso
				break;
			
			default:
				cout<<"No ha introducido un valor valido"<<endl;
		}	
	}	
	
	return 0;
}
