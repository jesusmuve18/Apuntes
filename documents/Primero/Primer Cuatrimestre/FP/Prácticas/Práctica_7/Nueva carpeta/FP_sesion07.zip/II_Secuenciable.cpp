/****************************************************************************/
//	FUNDAMENTOS DE PROGRAMACI�N			RELACI�N_II				EJERCICIO_76
/****************************************************************************/
/*
	Jes�s Mu�oz Velasco 					Grupo:A2
	
	Enunciado:
	
	Diremos que un n�mero entero positivo es secuenciable si se puede generar 
	como suma de n�meros consecutivos. Por ejemplo, 6 = 1 + 2 + 3, 15 = 7 + 8.
	Esta descomposici�n no tiene por qu� ser �nica. Por ejemplo, 
	15 = 7 + 8 = 4 + 5 + 6 = 1 + 2 + 3 + 4 + 5.
	
	Escribir un programa que lea un entero n y nos diga cu�ntas 
	descomposiciones posibles tiene. Por ejemplo:
	
						15 -> 3 descomposiciones
						94 -> 1 descomposici�n
						108 -> 3 descomposiciones
						
	Curiosidad: los �nicos n�meros con 0 descomposiciones son las potencias 
	de 2.
	
	Entradas: Numero 
	
	Salidas: Numero de descomposiciones posibles y cuales son
	
*/
/****************************************************************************/
#include<iostream>
#include<string>
using namespace std;
/****************************************************************************/
int main()
{
	
	//Declaraci�n de datos
	
	int n, sumatoria, descomposiciones=0;
	string s="", str_desc="";
	
	//Entradas
	
	do
	{
		cout<<"Numero: ";
		cin>>n;
		if(n<=0)
			cout<<"El numero introducido debe ser mayor que 0"<<endl;
	} while(n<=0);
	
	
	//C�lculos
	
	for(int i=2; i<=n;i++) 
	{								
		for(int j=1; j<((n/i)+1) ; j++)
		{
			for(int k=0; k<i; k++)
			{
				sumatoria+=j+k;
				
				if(k!=0)
				{
					s+=" + "+(to_string(j+k));	
				}
				else
				{
					s+=(to_string(j+k));
				}
			}
			
			if(sumatoria==n)
			{
				descomposiciones++;
				str_desc+="\t"+(to_string(n))+" = "+s+"\n";
			}
				
			sumatoria=0;
			s="";
		}	
	}
	
	//Salidas
	
	cout<<endl;
	
	if(descomposiciones==1)
	{
		cout<<n<<" -> "<<descomposiciones<<" descomposicion"<<endl;
	}
	else
	{
		cout<<n<<" -> "<<descomposiciones<<" descomposiciones"<<endl;
	}
	
	cout<<endl;
	cout<<str_desc;
	
	return 0;
}
/*	EXPLICACION DEL PROGRAMA:
	Mi programa se basa en buscar secuencias cada vez m�s largas y ver 
	cuanto suman. Para ello empiezo en 2, es decir voy a ver si existen 2
	n�meros consecutivos cuya suma sea igual al n�mero dado. L�gicamente
	tan solo tendr� que buscar hasta ((numero/2)+1) ya que 2 numeros 
	consecutivos mayores a la mitad del n�mero siempre van a ser mayores que 
	el n�mero.
	
	Ahora este proceso lo ir� haciendo pero en lugar de con 2 con i, cuyos 
	valores van desde el 2 hasta el n�mero. Cuando i valga por ejemplo 4 
	empezar� a sumar los primeros 4 n�meros (1+2+3+4) y comprobar� el 
	resultado. Despu�s de los siguientes 4 (2+3+4+5) y as�. 
	
	En general, compruebo si existen i numeros consecutivos cuya suma sea 
	igual al n�mero dado. Lo har� desde el 1 hasta ((numero/i)+1) (por la 
	raz�n explicada anteriormente). 
	
	Si en este proceso encuentro alguna secuencia que verifique la igualdad
	sumar� 1 al contador de descomposiciones y adem�s guardar� en una string
	el equivalente a:
	
		numero = primera descomposici�n
		numero = segunda descomposici�n
		......
		
	para mostrarlo al final del programa
*/
