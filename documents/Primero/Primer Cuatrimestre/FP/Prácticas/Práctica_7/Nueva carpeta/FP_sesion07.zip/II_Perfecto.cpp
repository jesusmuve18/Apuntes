/****************************************************************************/
//	FUNDAMENTOS DE PROGRAMACI�N			RELACI�N_II				EJERCICIO_71
/****************************************************************************/
/*
	Jes�s Mu�oz Velasco 					Grupo:A2
	
	Enunciado:
	
	Un n�mero perfecto es aquel que es igual a la suma de todos sus divisores 
	positivos excepto �l mismo. El primer n�mero perfecto es el 6 ya que sus 
	divisores son 1, 2 y 3 y 6=1+2+3. Escribir un programa que muestre el mayor 
	n�mero perfecto que sea menor a un n�mero dado por el usuario.
	
	Entradas: N�mero tope 
	
	Salidas: M�ximo n�mero perfecto menor al tope
	
*/
/****************************************************************************/
#include<iostream>
using namespace std;
/****************************************************************************/
int main()
{
	
	//Declaraci�n de datos
	
	int tope, max_n_perfecto, acumulador;
	
	//Entradas
	
	cout<<"Introduce un numero: ";
	cin>>tope;
	
	//C�lculos
	
	for(int numero=1; numero<=tope;numero++) //recorro el bucle "tope" veces
	{
		acumulador=0; //reseteo el acumulador

		for (int i=1; i<numero; i++) //recorro el bucle "numero" veces
		{
			if(numero%i==0)
			{
				acumulador+=i; //Si es divisible exacto lo sumo
			}
		}
		
		if(acumulador==numero) 	//Compruebo si la suma de los divisores es 
		{						//igual al n�mero
		
			max_n_perfecto=numero;
		}	
	}
	
	//Salidas
	
	cout<<"El mayor numero perfecto menor a "<<tope<<" es "<<max_n_perfecto;
	
	return 0;
}
