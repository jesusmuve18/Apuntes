/****************************************************************************/
//	FUNDAMENTOS DE PROGRAMACI�N			RELACI�N_II				EJERCICIO_72
/****************************************************************************/
/*
	Jes�s Mu�oz Velasco 					Grupo:A2
	
	Enunciado:
	
	Escribir un programa que encuentre dos enteros n y m mayores que 1 que 
	verifiquen lo siguiente:
	
									 m
									 __
									\
									/__ i^2 = n^2
									i=1

	
	Salidas: Soluci�n para n y m
	
*/
/****************************************************************************/
#include<iostream>
#include<cmath>
using namespace std;
/****************************************************************************/
int main()
{
	
	//Declaraci�n de datos
	
	int n,m, resultado;
	int sumatorio;
	bool solucion=false;	
	
	
	//C�lculos
	
	m=2; //Los inicializo con el primer entero mayor de 1
	
	
	while(!solucion) //Mientras no se encuentre un valor de n y m 
	{
		sumatorio=0;
		cout<<"Para m = "<<m<<": ";
		for(int i=1; i<=m ; i++) //realizaci�n de la sumatoria;
		{
			sumatorio+=(i*i);
			if(i>1)
			{
				cout<<" + "<<(i*i);
			}
			else
			{
				cout<<(i*i);
			}
			
		}

		if(((int)(sqrt(sumatorio)))==sqrt(sumatorio))
		{
			solucion=true;
			n=sqrt(sumatorio);
		}
		else
		{
			m++;
		}	
		cout<<" = "<<sumatorio<<" == ("<<((int)(sqrt(sumatorio)))<<"^2 = "
			<<pow(((int)(sqrt(sumatorio))),2)<<boolalpha<<") "<<solucion;
		cout<<endl;	
	}
		
	
	//Salidas
	
	cout<<endl;
	cout<<"Solucion: "<<endl;
	cout<<"\tm = "<<m<<endl;
	cout<<"\tn = "<<n<<endl;
	
	return 0;
}
/*El planteamiento de este ejercicio es el siguiente:
	Dado que no puedo resolver una ecuaci�n de dos inc�gnitas he decidido 
	actualizarlo para que solo tenga una de forma que:
	
			 m
			 __
			\
			/__ i^2 = n^2
			i=1
			
	Es lo mismo que buscar el n�mero m para el que al sumar el cuadrado de 
	todos los n�meros anteriores a �l resulte un n�mero con ra�z cuadrada 
	exacta (que ser�a n). De este modo solo tengo que ir variando m.
	
	Para comprobar si el resultado de la sumatoria es un cuadrado de enteros
	compruebo si:
			((int)(sqrt(sumatorio)))==sqrt(sumatorio)
			
	Es decir si la truncaci�n a la parte entera de la ra�z de la sumatoria
	coincide con la ra�z de la sumatoria (compruebo si no tiene decimales).
	En ese caso habr� encontrado el valor de m y n ser� la ra�z cuadrada del 
	sumatorio (que obviamente es exacta).
	
*/

