/****************************************************************************/
//	FUNDAMENTOS DE PROGRAMACI�N			RELACI�N_IV				EJERCICIO_39
/****************************************************************************/
/*
	Jes�s Mu�oz Velasco 					Grupo:A2
	
	Enunciado:
	
	En el ejercicio 87 de la Relaci�n de Problemas II plante�bamos una 
	heur�stica sencilla para adivinar un valor aleatorio comprendido ente 
	MIN y MAX basado en la b�squeda dicot�mica.
		
	Queremos saber cu�ntos intentos se realizan para localizar cada uno de los 
	valores comprendidos entre MIN y MAX. Para cada valor i (MIN = i =MAX) 
	calcule y guarde el n�mero de intentos. A continuaci�n muestre una tabla 
	que indique los valores de i y el n�mero de intentos realizados para 
	localizarlo.
	
	Deber� separar los procesos de c�lculo y presentaci�n de resultados.
	
	Nota: no necesita generar n�meros aleatorios.
	
	Salidas: Tabla de los n�meros a adivinar y el n�mero de intentos que se 
			 necesitan para adivinar cada uno de ellos
	
*/
/****************************************************************************/
#include<iostream>
using namespace std;
/****************************************************************************/
//Declaraci�n de constantes globales

const int MIN=-1000, MAX=1000;

/*****************************************************************************
  	Funci�n: Calcula cuantos intentos se necesitan para calcular la inc�gnita
  			 con Heure�stica
	Par�metros: Inc�gnita a adivinar
	Devuelve: N�mero de intentos requeridos para acertarla	
............................................................................*/
int IntentosJuego(int incognita)
{
	int intentos=0; //Dato que devolver� la funci�n
	
	int min_tmp=MIN-1; //Cabe la posibilidad de que el minimo sea la incognita
	int max_tmp=MAX+1;	//Cabe la posibilidad de que el maximo sea la incognita
	
	int numero; //Numero que se genera para comparar con la incognita
	
	do
	{
		numero=(int)(((min_tmp+max_tmp)/2)); //generaci�n del n�mero
		
		if(numero!=incognita) //comparo el n�mero con la inc�gnita
		{
			if(numero>incognita)
			{
				max_tmp=numero;
			}
			else
			{
				min_tmp=numero;
			}
		}
		
		intentos++;
		
	} while(numero!=incognita);

	
	return intentos;
	
}
/****************************************************************************/
/****************************************************************************/
int main()
{
	//Declaraci�n de Datos
	
	int intentos[MAX-MIN+1]; //array que almacenar� el n�mero de intentos
							 //requeridos para acertar cada n�mero
	
	//C�lculos
	
	for(int i=0; i<=(MAX-MIN); i++) 	
	{								
		intentos[i]=IntentosJuego(i+MIN);
	}
	
	//Salidas
	
	cout<<" ------------------------------- "<<endl; //Cabecera de la tabla
	cout<<"|   Incognita   |    Intentos   |"<<endl;
	cout<<"|---------------|---------------|"<<endl;
	
	for(int i=0; i<=(MAX-MIN); i++) 	
	{								
		cout<<"|      "<<(i+MIN)<<"\t|\t"<<intentos[i]<<"\t|"<<endl;
	}
	cout<<" ------------------------------- "<<endl;
	
	
	return 0;
}
