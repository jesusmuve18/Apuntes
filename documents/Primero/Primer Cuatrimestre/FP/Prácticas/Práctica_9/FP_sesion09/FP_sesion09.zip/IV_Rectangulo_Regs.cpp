/****************************************************************************/
//	FUNDAMENTOS DE PROGRAMACI�N			RELACI�N_IV				EJERCICIO_4
/****************************************************************************/
/*
	Jes�s Mu�oz Velasco 					Grupo:A2
	
	Enunciado:
	
	Para modelar un rect�ngulo se usar� el tipo de dato Rectangulo. Un 
	rect�ngulo se caracterizar� por la coordenada superior izquierda y la 
	coordenada inferior derecha (ambos son datos de tipo Punto2D).
	
	Escribir un programa que lea las coordenadas que definen un rect�ngulo 
	y calcule la circunferencia centrada en el punto de corte de las diagonales 
	del rect�ngulo tal que su superficie sea la menor entre todas las 
	circunferencias de �rea mayor que la del rect�ngulo.
	
	Use datos de tipo Rectangulo, Circunferencia y Punto2D para la resoluci�n 
	de este problema.
	
	Para el c�lculo, considere comenzar con radio=0.5 e ir incrementando su 
	valor 0.25 en cada iteraci�n.
	
	Entradas: Puntos extremos de la diagonal de un rect�ngulo
	
	Salidas: Coordenada del centro y radio cuyo �rea sea la siguiente mayor
			 al �rea del rect�ngulo dado con saltos de 0.25 entre cada 
			 valor del radio.
	
*/
/****************************************************************************/
#include<iostream>
#include<cmath>
using namespace std;

//#define DATOS_EXTRA
/****************************************************************************/
//Declaraci�n de constantes globales

const double RADIO_INICIAL=0.5;
const double SALTO_RADIO=0.25;
const double PI=3.14159265359;

/****************************************************************************/
//Declaraci�n de tipos de datos (struct)

struct Punto2D 
{
	double x; //abscisas
	double y; //ordenadas
};

struct Rectangulo
{
	Punto2D punto_1; //coordenadas de uno de los v�rtices del rect�ngulo
	Punto2D punto_2; //coordenadas del punto opuesto con respecto a la diagonal
					 //del punto_1
};

struct Circunferencia
{
	Punto2D centro; //coordenadas del centro de la circunferencia
	double radio;
};

/****************************************************************************/
/* 	Funci�n: Lee la coordenada x de un dato
	Par�metros: Petici�n
	Devuelve: Coordenada x de un dato											*/
//............................................................................																
double LeeCoordenadaX (string titulo)
{
	double x; //Dato que devolver� la funci�n
	cout<<titulo;
	cin>>x;
	
	return x;
}

/****************************************************************************/
/* 	Funci�n: Lee la coordenada y de un dato
	Par�metros: Petici�n
	Devuelve: Coordenada y de un dato											*/
//............................................................................																
double LeeCoordenadaY (string titulo)
{
	double y; //Dato que devolver� la funci�n
	cout<<titulo;
	cin>>y;
	
	return y;
}

/****************************************************************************/
/* 	Funci�n: Devuelve el �rea de un rect�ngulo
	Par�metros: Dato de tipo rect�ngulo
	Devuelve: �rea del rect�ngulo											*/
//............................................................................																
double AreaRectangulo(Rectangulo rect)
{
	double base=abs(rect.punto_1.x-rect.punto_2.x);
	double altura=abs(rect.punto_1.y-rect.punto_2.y);
	
	return base*altura;
}

/****************************************************************************/
/* 	Funci�n: Devuelve el �rea de una circunferencia
	Par�metros: Dato de tipo circunferencia
	Devuelve: �rea de la circunferencia										*/
//............................................................................																
double AreaCircunferencia(Circunferencia circ)
{
	return (PI*circ.radio*circ.radio);
}

/****************************************************************************/
/* 	Funci�n: Devuelve la posici�n del centro del rect�ngulo (cruce de 
			 diagonales)
	Par�metros: Dato de tipo rect�ngulo
	Devuelve: Coordenadas del punto del centro del rect�ngulo				*/
//............................................................................																
Punto2D CentroRectangulo(Rectangulo rect)
{
	Punto2D centro; //Dato que devolver� la funci�n
	
	double base=abs(rect.punto_1.x-rect.punto_2.x);
	double altura=abs(rect.punto_1.y-rect.punto_2.y);
	
	centro.x=min(rect.punto_1.y,rect.punto_2.y)+(base/2);
	centro.y=min(rect.punto_1.x,rect.punto_2.x)+(altura/2);
	
	return centro;
}

/****************************************************************************/
/****************************************************************************/
int main()
{
	//Declaraci�n de Datos
	
	Rectangulo rect;
	double area_rect;
	
	Circunferencia circ;
	double area_circ;
	
	//Entradas
	
	cout<<"Puntos que definen un rectangulo "
		<<"(puntos de extremos de una diagonal):"<<endl;
	do
	{
		cout<<"     Punto 1: "<<endl;
		rect.punto_1.x=LeeCoordenadaX ("\tCoordenada X: ");
		rect.punto_1.y=LeeCoordenadaY ("\tCoordenada Y: ");
		
		cout<<"    Punto 2: "<<endl;
		rect.punto_2.x=LeeCoordenadaX ("\tCoordenada X: ");
		rect.punto_2.y=LeeCoordenadaY ("\tCoordenada Y: ");
		
		cout<<"--------------------------------"<<endl;
		
	}while(AreaRectangulo(rect)<=0);
	
		
	//C�lculos
	
	area_rect=AreaRectangulo(rect);
	circ.centro=CentroRectangulo(rect);
	circ.radio=RADIO_INICIAL;
	area_circ=AreaCircunferencia(circ);
	
	while(area_circ<area_rect)
	{
		circ.radio+=SALTO_RADIO;
		area_circ=AreaCircunferencia(circ);
	}
	
	//Salidas
	
	cout<<"La circunferencia buscada tiene las siguientes caracteristicas:"
		<<endl;
	cout<<"\tCentro: Coordenada ("<<circ.centro.x<<" , "<<circ.centro.y<<")"
		<<endl;
	cout<<"\tRadio: "<<circ.radio<<endl;
	
	#ifdef DATOS_EXTRA
	
	cout<<"\tArea: "<<area_circ<<endl;
	cout<<endl;
	cout<<"(El rectangulo definido tiene un area de "<<area_rect<<" unidades)"
		<<endl;
	
	#endif
	return 0;
}
